<?php
/**
 * Resolve share-page URLs (MediaFire, Google Drive, Dropbox, pixeldrain,
 * Gofile, direct links, etc.) to a downloadable file URL, then download
 * into dumps/{kind}/{version}.cs for permanent storage.
 *
 * Every host-specific resolver here is "best effort, then fall through" —
 * if a page's markup doesn't match a known pattern (share sites change
 * their HTML over time), we still hand the original URL to curl with
 * redirect-following on, since plenty of "share" links actually redirect
 * straight to the real file without needing any scraping at all.
 */

/** Normalize a path string (collapse .. and .). */
function yush_norm_path(string $dir): string {
  $dir = str_replace('\\', '/', $dir);
  $parts = [];
  $abs = strlen($dir) > 0 && $dir[0] === '/';
  foreach (explode('/', $dir) as $p) {
    if ($p === '' || $p === '.') continue;
    if ($p === '..') { array_pop($parts); continue; }
    $parts[] = $p;
  }
  return ($abs ? '/' : '') . implode('/', $parts);
}

/**
 * All known dump storage candidates (for merge/list). Order = preference.
 */
function yush_data_root_candidates(): array {
  $site = realpath(__DIR__ . '/..');
  if ($site === false) $site = dirname(__DIR__);
  $out = [];
  $parent = dirname($site);
  if ($parent && $parent !== $site) $out[] = $parent . '/yush_data/dumps';
  if (!empty($_SERVER['HOME'])) $out[] = rtrim((string)$_SERVER['HOME'], '/\\') . '/yush_data/dumps';
  if (preg_match('#^(/home/[^/]+)#', $site, $m)) $out[] = $m[1] . '/yush_data/dumps';
  $out[] = $site . '/../yush_data/dumps';
  $out[] = $site . '/dumps';
  $normed = [];
  foreach ($out as $d) {
    $n = yush_norm_path($d);
    if ($n !== '' && !in_array($n, $normed, true)) $normed[] = $n;
  }
  return $normed;
}

/**
 * Permanent data root that SURVIVES website redeploys.
 * Path is PINNED in site/dumps/.storage_path so every request uses the
 * same folder — prevents dumps "vanishing" when a different candidate
 * wins the write-probe on a later request.
 */
function yush_data_root(): string {
  static $root = null;
  if ($root !== null) return $root;

  $site = realpath(__DIR__ . '/..');
  if ($site === false) $site = dirname(__DIR__);
  $pinFile = $site . '/dumps/.storage_path';

  // 1) Honor pinned path if still writable
  if (is_file($pinFile)) {
    $pinned = trim((string)@file_get_contents($pinFile));
    $pinned = yush_norm_path($pinned);
    if ($pinned !== '') {
      if (!is_dir($pinned)) {
        @mkdir($pinned, 0777, true);
        @chmod($pinned, 0777);
      }
      if (is_dir($pinned)) {
        $probe = $pinned . '/.yush_ok';
        if (@file_put_contents($probe, '1') !== false) {
          @unlink($probe);
          $root = $pinned;
          return $root;
        }
      }
    }
  }

  // 2) Pick first writable candidate and pin it
  foreach (yush_data_root_candidates() as $dir) {
    if (!is_dir($dir)) {
      @mkdir($dir, 0777, true);
      @chmod($dir, 0777);
    }
    if (!is_dir($dir)) continue;
    $probe = $dir . '/.yush_persist_' . getmypid();
    if (@file_put_contents($probe, '1') !== false) {
      @unlink($probe);
      // Ensure site/dumps exists so we can store the pin file
      $siteDumps = $site . '/dumps';
      if (!is_dir($siteDumps)) {
        @mkdir($siteDumps, 0777, true);
        @chmod($siteDumps, 0777);
      }
      @file_put_contents($pinFile, $dir . "\n");
      $root = $dir;
      return $root;
    }
  }

  $root = $site . '/dumps';
  if (!is_dir($root)) @mkdir($root, 0777, true);
  return $root;
}

function yush_dump_dir(string $kind): string {
  $kind = ($kind === 'new') ? 'new' : 'old';
  $dir = yush_data_root() . '/' . $kind;
  if (!is_dir($dir)) {
    @mkdir($dir, 0777, true);
    @chmod($dir, 0777);
  }
  return $dir;
}

function yush_http_get(string $url, int $timeout = 60, bool $body = true): array {
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => $body,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_CONNECTTIMEOUT => 20,
      CURLOPT_TIMEOUT => $timeout,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      CURLOPT_HTTPHEADER => [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
      ],
    ]);
    $data = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $err = curl_error($ch);
    curl_close($ch);
    return [
      'ok' => $data !== false && $code > 0 && $code < 400,
      'code' => $code,
      'body' => $body ? (string)$data : '',
      'url' => $final ?: $url,
      'ctype' => $ctype,
      'error' => $err,
    ];
  }

  // curl disabled on this host — fall back to a stream-context GET.
  $ctx = stream_context_create(['http' => [
    'method' => 'GET',
    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\nAccept: text/html,*/*;q=0.8\r\n",
    'timeout' => $timeout,
    'follow_location' => 1,
    'max_redirects' => 10,
    'ignore_errors' => true,
  ]]);
  $data = @file_get_contents($url, false, $ctx);
  $status = 0;
  $final = $url;
  if (isset($http_response_header) && is_array($http_response_header)) {
    foreach ($http_response_header as $h) {
      if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $status = (int)$m[1];
      if (preg_match('#^Location:\s*(\S+)#i', $h, $m)) $final = trim($m[1]);
    }
  }
  return [
    'ok' => $data !== false && $status > 0 && $status < 400,
    'code' => $status,
    'body' => $body ? (string)$data : '',
    'url' => $final,
    'ctype' => '',
    'error' => $data === false ? 'file_get_contents failed (curl unavailable on this host)' : '',
  ];
}

function yush_is_direct_file_url(string $url): bool {
  $path = parse_url($url, PHP_URL_PATH) ?: '';
  if (preg_match('/\.(cs|txt|zip|rar|7z|bin|dat)$/i', $path)) return true;
  if (preg_match('#^https?://download\d*\.mediafire\.com/#i', $url)) return true;
  if (preg_match('#^https?://[^/]*gofile\.io/download/#i', $url)) return true;
  if (preg_match('#^https?://(?:[^/]*\.)?pixeldrain\.com/api/file/#i', $url)) return true;
  if (preg_match('#^https?://[^/]*\.googleusercontent\.com/#i', $url)) return true;
  return false;
}

/** MediaFire's newer pages ship the download link "scrambled" (base64
 * then reversed) inside a data-scrambled-url attribute, unscrambled by a
 * tiny bit of inline JS in the browser. We just reverse that in PHP. */
function yush_mediafire_unscramble(string $scrambled): ?string {
  $reversed = strrev($scrambled);
  $decoded = base64_decode($reversed, true);
  if ($decoded && preg_match('#^https?://#i', $decoded)) return $decoded;
  return null;
}

function yush_resolve_mediafire(string $pageUrl): ?string {
  $res = yush_http_get($pageUrl, 45, true);
  if (!$res['ok'] || $res['body'] === '') return null;
  $html = $res['body'];

  // Scrambled download URL (current MediaFire markup, most reliable).
  if (preg_match('#data-scrambled-url="([^"]+)"#i', $html, $m)) {
    $direct = yush_mediafire_unscramble(html_entity_decode($m[1], ENT_QUOTES));
    if ($direct) return $direct;
  }
  // Direct CDN links anywhere in the page.
  if (preg_match('#https?://download\d*\.mediafire\.com/[^"\'\s<>\\\\]+#i', $html, $m)) {
    return html_entity_decode($m[0], ENT_QUOTES);
  }
  // href on the download button.
  if (preg_match('#href="(https?://download\d*\.mediafire\.com/[^"]+)"#i', $html, $m)) {
    return html_entity_decode($m[1], ENT_QUOTES);
  }
  // Escaped-slash variant sometimes seen in embedded JSON blobs.
  if (preg_match('#"(https?:\\\\/\\\\/download\d*\\.mediafire\\.com[^"]+)"#i', $html, $m)) {
    return html_entity_decode(stripslashes($m[1]), ENT_QUOTES);
  }
  if (preg_match('#id="download_link"[^>]*href="([^"]+)"#i', $html, $m)) {
    $u = html_entity_decode($m[1], ENT_QUOTES);
    if (strpos($u, 'http') === 0) return $u;
  }
  if (preg_match('#href="(https?://www\.mediafire\.com/download/[^"]+)"#i', $html, $m)) {
    return html_entity_decode($m[1], ENT_QUOTES);
  }
  return null;
}

function yush_resolve_google_drive(string $url): ?string {
  $id = null;
  if (preg_match('#drive\.google\.com/file/d/([\w-]+)#', $url, $m)) $id = $m[1];
  elseif (preg_match('#[?&]id=([\w-]+)#', $url, $m)) $id = $m[1];
  if (!$id) return null;
  return 'https://drive.google.com/uc?export=download&id=' . $id . '&confirm=t';
}

function yush_resolve_dropbox(string $url): string {
  // ?dl=0 shows the preview page; ?dl=1 forces the raw file.
  if (strpos($url, 'dl=0') !== false) return str_replace('dl=0', 'dl=1', $url);
  if (strpos($url, 'dl=1') === false) {
    $sep = (strpos($url, '?') !== false) ? '&' : '?';
    return $url . $sep . 'dl=1';
  }
  return $url;
}

function yush_resolve_gofile_page(string $url): ?string {
  // Gofile's content API needs a page token; without one we can only try
  // the page itself and hope curl's redirect-following gets us the file.
  // We don't fail here — the generic fall-through below still tries it.
  return null;
}

function yush_resolve_download_url(string $url): array {
  $url = trim($url);
  if ($url === '' || !preg_match('#^https?://#i', $url)) {
    return ['ok' => false, 'error' => 'Invalid URL', 'url' => ''];
  }
  if (yush_is_direct_file_url($url)) {
    return ['ok' => true, 'url' => $url];
  }

  $host = strtolower(parse_url($url, PHP_URL_HOST) ?: '');

  if (strpos($host, 'mediafire.com') !== false) {
    $direct = yush_resolve_mediafire($url);
    if ($direct) return ['ok' => true, 'url' => $direct];
    // Markup didn't match any known pattern — still let curl try the
    // page directly (redirect-following sometimes gets there anyway)
    // rather than giving up outright.
    return ['ok' => true, 'url' => $url, 'warning' => 'Could not scrape a MediaFire direct link; trying the page URL directly.'];
  }
  if (strpos($host, 'drive.google.com') !== false) {
    $direct = yush_resolve_google_drive($url);
    if ($direct) return ['ok' => true, 'url' => $direct];
  }
  if (strpos($host, 'dropbox.com') !== false) {
    return ['ok' => true, 'url' => yush_resolve_dropbox($url)];
  }

  // Any other host (Gofile, SFile, pixeldrain, a plain web server, etc.):
  // hand it to curl as-is. CURLOPT_FOLLOWLOCATION handles most share
  // sites that simply redirect to the real file.
  return ['ok' => true, 'url' => $url];
}

/**
 * Download remote dump into dumps/{kind}/{version}.cs
 *
 * $onProgress, if given, is called periodically as
 *   $onProgress(int $downloadedBytes, int $totalBytesOrZero)
 * so the caller can stream live progress (speed + size) back to the
 * browser while the transfer is still in flight, instead of the client
 * only finding out once the whole download has finished.
 *
 * Returns ['ok'=>bool, 'path'=>..., 'size'=>..., 'error'=>...]
 */
function yush_download_dump_to_disk(string $kind, string $version, string $sourceUrl, ?callable $onProgress = null): array {
  @set_time_limit(600);
  @ini_set('max_execution_time', '600');
  @ini_set('memory_limit', '512M');

  $resolved = yush_resolve_download_url($sourceUrl);
  if (!$resolved['ok']) {
    return ['ok' => false, 'error' => $resolved['error'] ?? 'Resolve failed', 'path' => '', 'size' => 0];
  }
  $dlUrl = $resolved['url'];
  $dir = yush_dump_dir($kind);
  $dest = $dir . '/' . $version . '.cs';
  $tmp = $dest . '.part';

  $fp = @fopen($tmp, 'wb');
  if (!$fp) {
    return ['ok' => false, 'error' => 'Cannot write to dumps folder (permissions?)', 'path' => '', 'size' => 0];
  }

  if (function_exists('curl_init')) {
    $ch = curl_init($dlUrl);
    $opts = [
      CURLOPT_FILE => $fp,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_MAXREDIRS => 12,
      CURLOPT_CONNECTTIMEOUT => 30,
      CURLOPT_TIMEOUT => 560,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      CURLOPT_HTTPHEADER => [
        'Accept: */*',
        'Referer: https://www.mediafire.com/',
      ],
    ];
    if ($onProgress) {
      $opts[CURLOPT_NOPROGRESS] = false;
      $opts[CURLOPT_XFERINFOFUNCTION] = function ($resource, $downloadTotal, $downloadedNow) use ($onProgress) {
        $onProgress((int) $downloadedNow, (int) $downloadTotal);
        return 0; // non-zero would abort the transfer
      };
    }
    curl_setopt_array($ch, $opts);
    $ok = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    fclose($fp);
  } else {
    // curl is disabled on this host — stream the download manually via a
    // stream-context GET so we still get real (not simulated) progress.
    $ctx = stream_context_create(['http' => [
      'method' => 'GET',
      'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\nAccept: */*\r\nReferer: https://www.mediafire.com/\r\n",
      'timeout' => 560,
      'follow_location' => 1,
      'max_redirects' => 12,
      'ignore_errors' => true,
    ]]);
    $in = @fopen($dlUrl, 'rb', false, $ctx);
    $code = 0;
    $err = '';
    if (!$in) {
      $ok = false;
      $err = 'Could not open remote URL (curl unavailable, stream wrapper failed)';
      fclose($fp);
    } else {
      if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $h) {
          if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $code = (int) $m[1];
        }
      }
      $total = 0;
      $meta = stream_get_meta_data($in);
      if (isset($meta['wrapper_data']) && is_array($meta['wrapper_data'])) {
        foreach ($meta['wrapper_data'] as $h) {
          if (preg_match('#^Content-Length:\s*(\d+)#i', $h, $m)) $total = (int) $m[1];
        }
      }
      $downloaded = 0;
      while (!feof($in)) {
        $chunk = fread($in, 65536);
        if ($chunk === false) break;
        fwrite($fp, $chunk);
        $downloaded += strlen($chunk);
        if ($onProgress) $onProgress($downloaded, $total);
      }
      fclose($in);
      fclose($fp);
      $ok = $downloaded > 0 && ($code === 0 || $code < 400);
    }
  }

  if ($ok === false || $code >= 400) {
    @unlink($tmp);
    return ['ok' => false, 'error' => 'Download failed (HTTP ' . $code . '). ' . ($err ?: ''), 'path' => '', 'size' => 0];
  }

  $size = @filesize($tmp);
  if ($size === false || $size < 1024) {
    @unlink($tmp);
    return ['ok' => false, 'error' => 'Downloaded file too small — likely HTML, not dump.cs', 'path' => '', 'size' => 0];
  }

  // Reject HTML landing pages saved as .cs
  $fh = @fopen($tmp, 'rb');
  $head = $fh ? (string)fread($fh, 512) : '';
  if ($fh) fclose($fh);
  $hl = strtolower($head);
  if (strpos($hl, '<html') !== false || strpos($hl, '<!doctype') !== false) {
    @unlink($tmp);
    return ['ok' => false, 'error' => 'Got HTML page instead of dump file. MediaFire link could not be resolved to direct file.', 'path' => '', 'size' => 0];
  }

  if (!@rename($tmp, $dest)) {
    if (!@copy($tmp, $dest)) {
      @unlink($tmp);
      return ['ok' => false, 'error' => 'Could not finalize dump file on disk', 'path' => '', 'size' => 0];
    }
    @unlink($tmp);
  }

  return ['ok' => true, 'path' => $dest, 'size' => (int)filesize($dest), 'error' => '', 'resolved' => $dlUrl];
}

/**
 * ---------------------------------------------------------------------
 * Time-sliced / resumable download (job + chunk model)
 * ---------------------------------------------------------------------
 * Free/shared hosting (LiteSpeed, x10hosting, etc.) frequently kills any
 * single request that runs longer than ~20-30s, no matter what
 * set_time_limit() says — that's what produced the "connection ended
 * before the server confirmed the download finished" error: one big
 * blocking curl_exec() download inside one HTTP request got killed by
 * the host mid-transfer.
 *
 * The fix is to never hold one request open for the whole download.
 * Instead: start a job, then repeatedly ask the server for a short
 * (~20s) slice of the download; each slice is its own fast HTTP
 * request, well under any host's hard timeout, and the partial file on
 * disk (plus a small job record) is what carries progress from one
 * request to the next. The browser just keeps calling the chunk
 * endpoint back-to-back until the job reports done=true.
 */

/**
 * Find a directory we can actually write job JSON + .part files into.
 * Prefer system temp FIRST — shared hosts (x10, etc.) often make
 * public_html/dumps unwritable or quota-limited while /tmp still works.
 * Final dumps still land in dumps/{old|new}/ after download completes.
 */
/**
 * Job + .part storage. Prefer the permanent dump folders that already
 * hold saved .cs files (proven writable on this host). Session is used
 * as a metadata fallback when every disk path rejects writes.
 */
function yush_jobs_dir(): string {
  static $resolved = null;
  if ($resolved !== null) return $resolved;

  $base = realpath(__DIR__ . '/..');
  if ($base === false) $base = dirname(__DIR__);
  $hash = substr(md5($base), 0, 10);

  $candidates = [];

  // 1) Permanent data root (same place .cs dumps land — usually writable)
  try {
    $dataRoot = yush_data_root();
    if ($dataRoot !== '') {
      $candidates[] = $dataRoot . '/.jobs';
      $candidates[] = $dataRoot . '/old';
      $candidates[] = $dataRoot . '/new';
      $candidates[] = $dataRoot;
    }
  } catch (\Throwable $e) {}

  // 2) Site dumps folders (admin can chmod these)
  $candidates[] = $base . '/dumps/old';
  $candidates[] = $base . '/dumps/new';
  $candidates[] = $base . '/dumps/tmp/jobs';
  $candidates[] = $base . '/dumps/tmp';
  $candidates[] = $base . '/dumps';

  // 3) PHP upload + session paths
  $uploadTmp = rtrim((string)ini_get('upload_tmp_dir'), '/\\');
  if ($uploadTmp !== '') $candidates[] = $uploadTmp . '/yush_jobs_' . $hash;
  $sessPath = rtrim((string)@session_save_path(), '/\\');
  if ($sessPath !== '' && $sessPath[0] !== '/') {
    // relative session path
    $sessPath = $base . '/' . $sessPath;
  }
  if ($sessPath !== '' && is_dir($sessPath)) $candidates[] = $sessPath . '/yush_jobs_' . $hash;

  // 4) System temp
  $sys = rtrim((string)sys_get_temp_dir(), '/\\');
  if ($sys !== '') {
    $candidates[] = $sys . '/yush_jobs_' . $hash;
    $candidates[] = $sys;
  }

  foreach ($candidates as $dir) {
    if ($dir === '') continue;
    $dir = function_exists('yush_norm_path') ? yush_norm_path($dir) : $dir;
    if (!is_dir($dir)) {
      @mkdir($dir, 0777, true);
      @chmod($dir, 0777);
    }
    if (!is_dir($dir)) continue;

    // Light probe only (1KB) — quota may be tight
    $probe = $dir . '/.yush_w_' . getmypid() . '_' . mt_rand(1000, 9999);
    $n = @file_put_contents($probe, 'ok');
    if ($n === false || !is_file($probe)) {
      @unlink($probe);
      continue;
    }
    $got = @file_get_contents($probe);
    @unlink($probe);
    if ($got !== 'ok') continue;

    $resolved = $dir;
    return $resolved;
  }

  $resolved = $base . '/dumps';
  if (!is_dir($resolved)) {
    @mkdir($resolved, 0777, true);
    @chmod($resolved, 0777);
  }
  return $resolved;
}

/** Ensure a directory exists and is usable for a .part / job write. */
function yush_ensure_dir(string $dir): bool {
  if ($dir === '') return false;
  if (!is_dir($dir)) {
    @mkdir($dir, 0777, true);
    @chmod($dir, 0777);
  }
  if (!is_dir($dir)) return false;
  $probe = $dir . '/.yush_e_' . mt_rand(1000, 9999);
  $ok = @file_put_contents($probe, '1');
  @unlink($probe);
  return $ok !== false;
}

/**
 * Best directory for a download job of $kind (old|new).
 * Prefer the folder that already stores that kind's .cs files.
 */
function yush_job_home(string $kind = ''): string {
  $kind = ($kind === 'new') ? 'new' : (($kind === 'old') ? 'old' : '');
  $tries = [];
  if ($kind !== '') {
    try { $tries[] = yush_dump_dir($kind); } catch (\Throwable $e) {}
  }
  try {
    $root = yush_data_root();
    $tries[] = $root . '/.jobs';
    $tries[] = $root;
  } catch (\Throwable $e) {}
  $tries[] = yush_jobs_dir();
  $base = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
  $tries[] = $base . '/dumps/' . ($kind ?: 'tmp');
  $tries[] = $base . '/dumps';

  foreach ($tries as $dir) {
    if ($dir && yush_ensure_dir($dir)) return $dir;
  }
  return yush_jobs_dir();
}

function yush_job_file(string $jobId): string {
  return yush_jobs_dir() . '/' . $jobId . '.json';
}

function yush_session_jobs_boot(): void {
  if (session_status() === PHP_SESSION_NONE) {
    @session_start();
  }
  if (!isset($_SESSION['yush_jobs']) || !is_array($_SESSION['yush_jobs'])) {
    $_SESSION['yush_jobs'] = [];
  }
}

function yush_job_read(string $jobId): ?array {
  if ($jobId === '' || !preg_match('/^[a-f0-9]{8,40}$/', $jobId)) return null;

  $dirs = [];
  try { $dirs[] = yush_data_root() . '/.jobs'; } catch (\Throwable $e) {}
  try { $dirs[] = yush_data_root() . '/old'; } catch (\Throwable $e) {}
  try { $dirs[] = yush_data_root() . '/new'; } catch (\Throwable $e) {}
  $dirs[] = yush_jobs_dir();
  $base = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
  $dirs[] = $base . '/dumps/tmp/jobs';
  $dirs[] = $base . '/dumps/old';
  $dirs[] = $base . '/dumps/new';
  $dirs[] = $base . '/dumps';

  $seen = [];
  foreach ($dirs as $dir) {
    if ($dir === '' || isset($seen[$dir])) continue;
    $seen[$dir] = true;
    $f = $dir . '/' . $jobId . '.json';
    if (!is_file($f)) continue;
    $data = json_decode((string)@file_get_contents($f), true);
    if (is_array($data)) return $data;
  }

  // Session fallback (metadata only — .part still on disk)
  yush_session_jobs_boot();
  if (!empty($_SESSION['yush_jobs'][$jobId]) && is_array($_SESSION['yush_jobs'][$jobId])) {
    return $_SESSION['yush_jobs'][$jobId];
  }
  return null;
}

function yush_job_write(string $jobId, array $data): bool {
  $data['updatedAt'] = time();
  $json = json_encode($data, JSON_UNESCAPED_SLASHES);
  if ($json === false) return false;

  $kind = isset($data['kind']) ? (string)$data['kind'] : '';
  $dirs = [];
  $dirs[] = yush_job_home($kind);
  try { $dirs[] = yush_data_root() . '/.jobs'; } catch (\Throwable $e) {}
  try { $dirs[] = yush_dump_dir($kind === 'new' ? 'new' : 'old'); } catch (\Throwable $e) {}
  $dirs[] = yush_jobs_dir();
  $base = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
  $dirs[] = $base . '/dumps/old';
  $dirs[] = $base . '/dumps/new';
  $dirs[] = $base . '/dumps';

  $written = false;
  $seen = [];
  foreach ($dirs as $dir) {
    if ($dir === '' || isset($seen[$dir])) continue;
    $seen[$dir] = true;
    if (!yush_ensure_dir($dir)) continue;
    $path = $dir . '/' . $jobId . '.json';
    // No LOCK_EX — some shared hosts fail locked writes even when free
    $bytes = @file_put_contents($path, $json);
    if ($bytes === false) {
      @chmod($dir, 0777);
      $bytes = @file_put_contents($path, $json);
    }
    if ($bytes !== false && is_file($path)) {
      $written = true;
      // Keep tmp path inside a writable dir
      if (empty($data['tmp']) || !is_dir(dirname((string)$data['tmp']))) {
        // leave as-is; start.php sets tmp
      }
      break;
    }
  }

  // Always mirror into session so reads succeed even if disk is flaky
  yush_session_jobs_boot();
  $_SESSION['yush_jobs'][$jobId] = $data;
  // Cap session job map
  if (count($_SESSION['yush_jobs']) > 30) {
    $keys = array_keys($_SESSION['yush_jobs']);
    foreach (array_slice($keys, 0, -20) as $k) unset($_SESSION['yush_jobs'][$k]);
  }

  return $written || isset($_SESSION['yush_jobs'][$jobId]);
}

/** Delete job records (and their partial download files) older than $maxAgeSeconds. */
function yush_job_gc(int $maxAgeSeconds = 7200): void {
  $dir = yush_jobs_dir();
  $files = @glob($dir . '/*.json') ?: [];
  $now = time();
  foreach ($files as $f) {
    $age = $now - (int)@filemtime($f);
    if ($age > $maxAgeSeconds) {
      $data = json_decode((string)@file_get_contents($f), true);
      if (is_array($data) && !empty($data['tmp']) && is_file($data['tmp'])) @unlink($data['tmp']);
      @unlink($f);
    }
  }
}

/**
 * Validate a completed download and move it into its permanent home,
 * updating dumps/{kind}/index.json. Shared by the job/chunk flow.
 */
function yush_finalize_dump(string $kind, string $version, string $label, string $region, string $sourceUrl, string $resolvedUrl, string $tmpPath): array {
  $size = @filesize($tmpPath);
  if ($size === false || $size < 1024) {
    @unlink($tmpPath);
    return ['ok' => false, 'error' => 'Downloaded file too small — likely HTML, not dump.cs'];
  }

  $fh = @fopen($tmpPath, 'rb');
  $head = $fh ? (string)fread($fh, 512) : '';
  if ($fh) fclose($fh);
  if (strpos(strtolower($head), '<html') !== false || strpos(strtolower($head), '<!doctype') !== false) {
    @unlink($tmpPath);
    return ['ok' => false, 'error' => 'Got HTML page instead of dump file. Link could not be resolved to a direct file.'];
  }

  $dir = yush_dump_dir($kind);
  $dest = $dir . '/' . $version . '.cs';
  if (!@rename($tmpPath, $dest)) {
    if (!@copy($tmpPath, $dest)) {
      return ['ok' => false, 'error' => 'Could not finalize dump file on disk'];
    }
    @unlink($tmpPath);
  }

  $metaFile = $dir . '/index.json';
  $meta = [];
  if (is_file($metaFile)) $meta = json_decode((string)@file_get_contents($metaFile), true) ?: [];
  $meta[$version] = [
    'version' => $version,
    'label' => $label ?: $version,
    'region' => $region ?: 'GARENA',
    'file' => $version . '.cs',
    'url' => $sourceUrl,
    'size' => (int)@filesize($dest),
    'uploadedAt' => (int)round(microtime(true) * 1000),
    'source' => 'cached',
    'resolvedUrl' => $resolvedUrl,
  ];
  @file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

  return ['ok' => true, 'size' => (int)@filesize($dest)];
}

/**
 * Download one bounded time-slice of $url into $tmpPath, resuming from
 * byte $already if the remote host honors Range requests (it falls back
 * to a clean full restart if it doesn't — see the header callback).
 *
 * Returns:
 *   ok        - false only on a real, unrecoverable transfer error
 *   complete  - true once the whole remote file has been received
 *               (false just means "ran out of time this slice, call
 *               again to continue")
 *   downloaded/total - current known progress, straight off disk
 */
function yush_download_chunk(string $tmpPath, string $url, int $already, int $sliceSeconds): array {
  if (!function_exists('curl_init')) {
    return ['ok' => false, 'complete' => true, 'downloaded' => $already, 'total' => 0, 'error' => 'curl extension is not available on this server'];
  }

  $dir = dirname($tmpPath);
  if (!is_dir($dir)) {
    @mkdir($dir, 0777, true);
    @chmod($dir, 0777);
  }

  $mode = ($already > 0 && is_file($tmpPath)) ? 'ab' : 'wb';
  $fp = @fopen($tmpPath, $mode);
  if (!$fp) {
    // Try jobs dir fallback path if original open failed
    $alt = yush_jobs_dir() . '/' . basename($tmpPath);
    if ($alt !== $tmpPath) {
      $fp = @fopen($alt, $mode);
      if ($fp) $tmpPath = $alt;
    }
  }
  if (!$fp) {
    return ['ok' => false, 'complete' => true, 'downloaded' => $already, 'total' => 0,
      'error' => 'Cannot write temp file. Free disk quota or chmod 777 dumps/tmp. Tried: ' . $tmpPath];
  }

  $rangeRequested = $already > 0;
  $truncated = false;
  $contentLength = 0;
  $writeFailed = false;
  $headers = ['Accept: */*', 'Referer: https://www.mediafire.com/'];
  if ($rangeRequested) $headers[] = 'Range: bytes=' . $already . '-';

  $ch = curl_init($url);
  if ($ch === false) {
    fclose($fp);
    return ['ok' => false, 'complete' => true, 'downloaded' => $already, 'total' => 0, 'error' => 'curl_init failed for this URL'];
  }

  $headerFn = function ($handle, $line) use (&$truncated, &$contentLength, $fp, $rangeRequested) {
    if (!$truncated && $rangeRequested && preg_match('#^HTTP/\S+\s+200\b#', $line)) {
      @ftruncate($fp, 0);
      @rewind($fp);
      $truncated = true;
    }
    if (preg_match('#^Content-Length:\s*(\d+)#i', $line, $m)) {
      $contentLength = (int)$m[1];
    }
    return strlen($line);
  };

  // WRITEFUNCTION is more reliable than CURLOPT_FILE on hosts that
  // intermittently fail mid-write ("passed 16384 returned 8192").
  $writeFn = function ($ch, $data) use ($fp, &$writeFailed) {
    if ($writeFailed) return 0;
    $len = strlen($data);
    $written = @fwrite($fp, $data);
    if ($written === false || $written < $len) {
      // Retry once
      $written2 = @fwrite($fp, ($written === false) ? $data : substr($data, (int)$written));
      if ($written2 === false || ((int)$written + (int)$written2) < $len) {
        $writeFailed = true;
        return 0; // abort curl
      }
      return $len;
    }
    return $len;
  };

  curl_setopt_array($ch, [
    CURLOPT_WRITEFUNCTION => $writeFn,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 12,
    CURLOPT_CONNECTTIMEOUT => 12,
    CURLOPT_TIMEOUT => max(2, (int)$sliceSeconds),
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_HEADERFUNCTION => $headerFn,
    CURLOPT_BUFFERSIZE => 16384,
  ]);

  curl_exec($ch);
  $errno = curl_errno($ch);
  $err = curl_error($ch);
  $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  @fflush($fp);
  fclose($fp);

  $onDiskSize = @filesize($tmpPath);
  $downloaded = $onDiskSize !== false ? $onDiskSize : $already;
  $totalKnown = $contentLength > 0 ? (($truncated ? 0 : $already) + $contentLength) : 0;

  if ($writeFailed) {
    return [
      'ok' => false,
      'complete' => true,
      'downloaded' => $downloaded,
      'total' => $totalKnown,
      'error' => 'Disk write failed mid-download (quota full or permission). Free space on the host, then try again. Partial: ' . $downloaded . ' bytes.',
    ];
  }

  // CURLE_OPERATION_TIMEDOUT (28) == our own slice length ran out — expected.
  if ($errno === 28 || $errno === CURLE_OPERATION_TIMEDOUT) {
    return ['ok' => true, 'complete' => false, 'downloaded' => $downloaded, 'total' => $totalKnown, 'error' => null];
  }
  // CURLE_WRITE_ERROR (23) — we already handled via $writeFailed; soft-continue if we got bytes
  if ($errno === 23 && $downloaded > $already) {
    return ['ok' => true, 'complete' => false, 'downloaded' => $downloaded, 'total' => $totalKnown, 'error' => null];
  }
  if ($errno !== 0) {
    return ['ok' => false, 'complete' => true, 'downloaded' => $downloaded, 'total' => $totalKnown, 'error' => 'Download error: ' . $err . ' (code ' . $errno . ')'];
  }
  if ($httpCode === 416) {
    return ['ok' => true, 'complete' => true, 'downloaded' => $downloaded, 'total' => $downloaded, 'error' => null];
  }
  if ($httpCode >= 400) {
    return ['ok' => false, 'complete' => true, 'downloaded' => $downloaded, 'total' => $totalKnown, 'error' => 'Download failed (HTTP ' . $httpCode . ')'];
  }
  return ['ok' => true, 'complete' => true, 'downloaded' => $downloaded, 'total' => $totalKnown ?: $downloaded, 'error' => null];
}

/**
 * Quick HEAD (or GET with Range 0-0) to discover Content-Length without
 * downloading the body. Returns 0 if unknown.
 */
function yush_probe_content_length(string $url): int {
  if (!function_exists('curl_init')) return 0;
  $ch = curl_init($url);
  if ($ch === false) return 0;
  curl_setopt_array($ch, [
    CURLOPT_NOBODY => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 12,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 12,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_HTTPHEADER => ['Accept: */*', 'Referer: https://www.mediafire.com/'],
  ]);
  curl_exec($ch);
  $len = (int)curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($len > 0 && $code > 0 && $code < 400) return $len;
  // Fallback: some hosts ignore HEAD — try a tiny Range GET
  $ch = curl_init($url);
  if ($ch === false) return 0;
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 12,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 12,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_HTTPHEADER => ['Accept: */*', 'Referer: https://www.mediafire.com/', 'Range: bytes=0-0'],
  ]);
  curl_exec($ch);
  $len = (int)curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
  // For 206, Content-Length is the range size (1); total is in Content-Range
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($code === 206) {
    // We don't parse Content-Range here for simplicity; leave 0
    return 0;
  }
  return ($len > 1 && $code > 0 && $code < 400) ? $len : 0;
}
