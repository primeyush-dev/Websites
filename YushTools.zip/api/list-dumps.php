<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/_dump_resolve.php';

$kind = isset($_GET['kind']) ? $_GET['kind'] : 'old';
if (!in_array($kind, ['old', 'new'], true)) $kind = 'old';

/**
 * Merge index.json + .cs files from one directory into $meta (by version).
 * Newer / larger entries win when versions collide.
 */
function yush_merge_dump_dir(string $dir, array &$meta): void {
  if (!is_dir($dir)) return;
  $metaFile = $dir . '/index.json';
  if (is_file($metaFile)) {
    $rows = json_decode((string)@file_get_contents($metaFile), true) ?: [];
    foreach ($rows as $ver => $row) {
      if (!is_array($row)) continue;
      $ver = (string)($row['version'] ?? $ver);
      if ($ver === '') continue;
      $row['version'] = $ver;
      if (!isset($meta[$ver])) {
        $meta[$ver] = $row;
        continue;
      }
      // Prefer entry that has a real size / newer upload
      $oldSize = (int)($meta[$ver]['size'] ?? 0);
      $newSize = (int)($row['size'] ?? 0);
      $oldAt = (int)($meta[$ver]['uploadedAt'] ?? 0);
      $newAt = (int)($row['uploadedAt'] ?? 0);
      if ($newSize > $oldSize || $newAt > $oldAt) {
        $meta[$ver] = array_merge($meta[$ver], $row);
      }
    }
  }
  foreach (scandir($dir) as $f) {
    if (!preg_match('/^([0-9A-Za-z._-]+)\.cs$/', $f, $m)) continue;
    $ver = $m[1];
    $path = $dir . '/' . $f;
    $size = (int)@filesize($path);
    $mtime = (int)(@filemtime($path) * 1000);
    if (!isset($meta[$ver])) {
      $meta[$ver] = [
        'version' => $ver,
        'label' => $ver,
        'region' => 'GARENA',
        'file' => $f,
        'size' => $size,
        'uploadedAt' => $mtime,
        'source' => 'file',
      ];
    } else {
      if (empty($meta[$ver]['file'])) $meta[$ver]['file'] = $f;
      if (empty($meta[$ver]['size']) || (int)$meta[$ver]['size'] < $size) $meta[$ver]['size'] = $size;
      if (empty($meta[$ver]['uploadedAt'])) $meta[$ver]['uploadedAt'] = $mtime;
    }
  }
}

$meta = [];

// Always include the active permanent root first
$primary = yush_dump_dir($kind);
yush_merge_dump_dir($primary, $meta);

// Merge every other candidate so dumps never "vanish" if path switched
foreach (yush_data_root_candidates() as $root) {
  $dir = $root . '/' . $kind;
  if (realpath($dir) && realpath($primary) && realpath($dir) === realpath($primary)) continue;
  yush_merge_dump_dir($dir, $meta);
}

foreach ($meta as $ver => &$row) {
  if (!empty($row['url']) && empty($row['size'])) $row['size'] = 1;
  if (!empty($row['url']) && empty($row['file'])) $row['file'] = $ver . '.cs';
}
unset($row);

echo json_encode([
  'ok' => true,
  'dumps' => array_values($meta),
  'storage' => $primary,
]);
