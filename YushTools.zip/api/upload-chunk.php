<?php
/**
 * Chunked dump upload — works around tiny PHP upload_max_filesize (often 2M).
 * Client sends ~512KB chunks; server reassembles into dumps/{old|new}/{version}.cs
 * Idempotent: re-sending the same chunkIndex is safe (overwrites).
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Avoid PHP killing long assemble on last chunk
@set_time_limit(180);
@ini_set('max_execution_time', '180');
@ini_set('memory_limit', '256M');

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
  http_response_code(204);
  exit;
}

require_once __DIR__ . '/_dump_resolve.php';

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'POST only']);
  exit;
}

$kind = isset($_POST['kind']) ? $_POST['kind'] : '';
$version = isset($_POST['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$_POST['version']) : '';
$chunkIndex = isset($_POST['chunkIndex']) ? (int)$_POST['chunkIndex'] : -1;
$totalChunks = isset($_POST['totalChunks']) ? (int)$_POST['totalChunks'] : 0;
$label = isset($_POST['label']) ? substr(preg_replace('/[^\w\s.\-]/', '', (string)$_POST['label']), 0, 64) : $version;
$region = isset($_POST['region']) ? strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$_POST['region'])) : 'GARENA';

if (!in_array($kind, ['old', 'new'], true) || $version === '' || $chunkIndex < 0 || $totalChunks < 1 || $chunkIndex >= $totalChunks) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid chunk parameters']);
  exit;
}
if ($totalChunks > 800) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Too many chunks']);
  exit;
}

if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
  $ferr = isset($_FILES['chunk']) ? (int)$_FILES['chunk']['error'] : -1;
  $map = [
    UPLOAD_ERR_INI_SIZE => 'Chunk exceeds PHP upload_max_filesize',
    UPLOAD_ERR_FORM_SIZE => 'Chunk exceeds form size limit',
    UPLOAD_ERR_PARTIAL => 'Chunk upload was interrupted',
    UPLOAD_ERR_NO_FILE => 'No chunk file received',
    UPLOAD_ERR_NO_TMP_DIR => 'Server missing temp folder',
    UPLOAD_ERR_CANT_WRITE => 'Server cannot write temp file',
    UPLOAD_ERR_EXTENSION => 'Upload blocked by PHP extension',
  ];
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => $map[$ferr] ?? ('Chunk upload error code ' . $ferr)]);
  exit;
}

$finalDir = yush_dump_dir($kind);
$tmpRoot = yush_jobs_dir();
$sessionDir = $tmpRoot . '/' . $kind . '_' . $version;

foreach ([$tmpRoot, $sessionDir, $finalDir] as $d) {
  if (!is_dir($d) && !mkdir($d, 0777, true) && !is_dir($d)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Cannot create folder: ' . $d]);
    exit;
  }
  @chmod($d, 0777);
}

$chunkPath = $sessionDir . '/chunk_' . str_pad((string)$chunkIndex, 5, '0', STR_PAD_LEFT);
$moved = @move_uploaded_file($_FILES['chunk']['tmp_name'], $chunkPath);
if (!$moved) {
  if (!@copy($_FILES['chunk']['tmp_name'], $chunkPath)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Could not save chunk (disk full or permissions?)']);
    exit;
  }
}

// Sanity: chunk must be non-empty for all but possibly last
$csize = @filesize($chunkPath);
if ($csize === false || $csize < 1) {
  @unlink($chunkPath);
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Empty chunk received']);
  exit;
}

// Not last chunk — acknowledge (idempotent overwrite is fine)
if ($chunkIndex < $totalChunks - 1) {
  echo json_encode([
    'ok' => true,
    'done' => false,
    'chunkIndex' => $chunkIndex,
    'totalChunks' => $totalChunks,
    'bytes' => $csize,
  ]);
  exit;
}

// Last chunk — assemble all parts
$finalPath = $finalDir . '/' . $version . '.cs';
$tmpFinal = $finalPath . '.assembling';

$out = @fopen($tmpFinal, 'wb');
if (!$out) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Cannot write final dump file']);
  exit;
}

for ($i = 0; $i < $totalChunks; $i++) {
  $cp = $sessionDir . '/chunk_' . str_pad((string)$i, 5, '0', STR_PAD_LEFT);
  if (!is_file($cp)) {
    fclose($out);
    @unlink($tmpFinal);
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Missing chunk ' . $i . ' of ' . $totalChunks . ' — re-upload from start']);
    exit;
  }
  $in = @fopen($cp, 'rb');
  if (!$in) {
    fclose($out);
    @unlink($tmpFinal);
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Cannot read chunk ' . $i]);
    exit;
  }
  stream_copy_to_stream($in, $out);
  fclose($in);
}
fclose($out);

// Atomic replace
if (!@rename($tmpFinal, $finalPath)) {
  // fallback copy+unlink
  if (!@copy($tmpFinal, $finalPath)) {
    @unlink($tmpFinal);
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Could not finalize dump file']);
    exit;
  }
  @unlink($tmpFinal);
}

// Cleanup session chunks
for ($i = 0; $i < $totalChunks; $i++) {
  $cp = $sessionDir . '/chunk_' . str_pad((string)$i, 5, '0', STR_PAD_LEFT);
  @unlink($cp);
}
@rmdir($sessionDir);

$size = @filesize($finalPath);
if ($size === false) $size = 0;

$metaFile = $finalDir . '/index.json';
$meta = [];
if (is_file($metaFile)) {
  $meta = json_decode((string)@file_get_contents($metaFile), true) ?: [];
}
$meta[$version] = [
  'version' => $version,
  'label' => $label ?: $version,
  'region' => $region ?: 'GARENA',
  'file' => $version . '.cs',
  'size' => $size,
  'uploadedAt' => (int)round(microtime(true) * 1000),
];
@file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo json_encode([
  'ok' => true,
  'done' => true,
  'version' => $version,
  'kind' => $kind,
  'size' => $size,
]);
