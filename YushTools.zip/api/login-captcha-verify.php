<?php
/**
 * Server-side verification for the login CAPTCHA (Cloudflare Turnstile).
 *
 * The browser only ever holds Turnstile's public site key. The token it
 * produces is meaningless on its own — it must be replayed to Cloudflare's
 * siteverify endpoint from the server, using the secret key, before the
 * login attempt is allowed to proceed. This file is the only place that
 * secret key is used.
 */
declare(strict_types=1);

require_once __DIR__ . '/../protection/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if (yush_method() !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'method_not_allowed']);
    exit;
}

$raw = yush_raw_body(65536);
$data = json_decode($raw, true);
$token = is_array($data) ? trim((string)($data['token'] ?? '')) : '';
$honeypot = is_array($data) ? (string)($data['website'] ?? '') : '';

if (yush_honeypot_tripped($honeypot)) {
    yush_log('login_honeypot_tripped');
    // Reply as if it were a normal captcha failure — don't tip off the bot.
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'captcha_failed']);
    exit;
}

if ($token === '' || strlen($token) > 2048) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'missing_token']);
    exit;
}

$result = yush_turnstile_verify($token, yush_ip());

if (empty($result['success'])) {
    yush_log('login_captcha_failed', ['codes' => implode(',', $result['error-codes'] ?? [])]);
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'captcha_failed']);
    exit;
}

echo json_encode(['success' => true]);
