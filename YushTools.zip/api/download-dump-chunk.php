<?php
/**
 * Step 2 of the job/chunk dump-download flow: download roughly one
 * time-slice (~20s) worth of bytes for an existing job and report
 * progress. The client (js/main.js saveDumpLink) calls this in a tight
 * loop until the response has done:true — each individual call stays
 * comfortably under any shared host's execution-time cap, so nothing
 * kills a single long-lived connection mid-transfer anymore.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

@set_time_limit(35);
@ini_set('max_execution_time', '35');
@ini_set('memory_limit', '256M');

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'done' => true, 'error' => 'POST only']);
    exit;
}

require_once __DIR__ . '/_dump_resolve.php';

// Same belt-and-suspenders as download-dump-start.php: never let an
// uncaught runtime error fall through to a blank HTTP 500 — always
// answer with JSON the client can actually show to the user.
try {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw ?: '', true);
    if (!is_array($json)) $json = $_POST;
    $jobId = isset($json['jobId']) ? preg_replace('/[^a-f0-9]/', '', (string)$json['jobId']) : '';

    if ($jobId === '') {
        echo json_encode(['ok' => false, 'done' => true, 'error' => 'Missing jobId']);
        exit;
    }

    $job = yush_job_read($jobId);
    // Client may re-send job fields if disk/session was cleared between polls
    if (!$job && is_array($json) && !empty($json['resolvedUrl']) && !empty($json['tmp'])) {
        $job = [
            'id' => $jobId,
            'kind' => isset($json['kind']) && in_array($json['kind'], ['old','new'], true) ? $json['kind'] : 'old',
            'version' => isset($json['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$json['version']) : '',
            'label' => isset($json['label']) ? (string)$json['label'] : '',
            'region' => isset($json['region']) ? (string)$json['region'] : 'GARENA',
            'sourceUrl' => isset($json['sourceUrl']) ? (string)$json['sourceUrl'] : '',
            'resolvedUrl' => (string)$json['resolvedUrl'],
            'tmp' => (string)$json['tmp'],
            'downloaded' => isset($json['downloaded']) ? (int)$json['downloaded'] : 0,
            'total' => isset($json['total']) ? (int)$json['total'] : 0,
            'done' => false,
            'ok' => null,
            'error' => null,
            'size' => 0,
            'chunks' => isset($json['chunks']) ? (int)$json['chunks'] : 0,
            'createdAt' => time(),
        ];
        if ($job['version'] === '' || $job['tmp'] === '') {
            $job = null;
        } else {
            yush_job_write($jobId, $job);
        }
    }
    if (!$job) {
        echo json_encode(['ok' => false, 'done' => true, 'error' => 'Download session expired or not found. Please try again.']);
        exit;
    }

    // Idempotent: if this job already finished (e.g. a duplicate/retried
    // poll landed after completion), just report the stored result again.
    if (!empty($job['done'])) {
        echo json_encode([
            'ok' => !empty($job['ok']),
            'done' => true,
            'downloaded' => $job['downloaded'],
            'total' => $job['total'],
            'size' => $job['size'] ?? 0,
            'error' => $job['error'],
            'version' => $job['version'],
            'kind' => $job['kind'],
        ]);
        exit;
    }

    // Safety net against a link that's alive but glacially slow / stuck
    // looping forever: ~400 slices at ~18s each is well over an hour.
    if ((int)($job['chunks'] ?? 0) > 400) {
        $job['done'] = true;
        $job['ok'] = false;
        $job['error'] = 'Download timed out after many retries — the link may be too slow or unreachable.';
        if (!empty($job['tmp']) && is_file($job['tmp'])) @unlink($job['tmp']);
        yush_job_write($jobId, $job);
        echo json_encode(['ok' => false, 'done' => true, 'error' => $job['error']]);
        exit;
    }

    $result = yush_download_chunk($job['tmp'], $job['resolvedUrl'], (int)$job['downloaded'], 2);

    $job['downloaded'] = $result['downloaded'];
    if ($result['total'] > 0) $job['total'] = $result['total'];
    $job['chunks'] = (int)($job['chunks'] ?? 0) + 1;

    if (!$result['complete']) {
        // Ran out of time this slice only — progress is saved on disk +
        // in the job file, client just calls this endpoint again to continue.
        yush_job_write($jobId, $job);
        echo json_encode([
            'ok' => true,
            'done' => false,
            'downloaded' => $job['downloaded'],
            'total' => $job['total'],
        ]);
        exit;
    }

    if (!$result['ok']) {
        $job['done'] = true;
        $job['ok'] = false;
        $job['error'] = $result['error'];
        yush_job_write($jobId, $job);
        echo json_encode(['ok' => false, 'done' => true, 'error' => $job['error']]);
        exit;
    }

    // Whole file received this slice — validate + move into dumps/{kind}/{version}.cs
    $fin = yush_finalize_dump($job['kind'], $job['version'], $job['label'], $job['region'], $job['sourceUrl'], $job['resolvedUrl'], $job['tmp']);

    $job['done'] = true;
    $job['ok'] = $fin['ok'];
    $job['error'] = $fin['ok'] ? null : $fin['error'];
    $job['size'] = $fin['ok'] ? $fin['size'] : 0;
    yush_job_write($jobId, $job);

    echo json_encode([
        'ok' => $fin['ok'],
        'done' => true,
        'downloaded' => $job['downloaded'],
        'total' => $job['total'],
        'size' => $job['size'],
        'error' => $job['error'],
        'version' => $job['version'],
        'kind' => $job['kind'],
    ]);
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'done' => true, 'error' => 'Server error: ' . $e->getMessage()]);
}
