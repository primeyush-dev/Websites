<?php
/**
 * Step 1: resolve share link + create a download job.
 * Job metadata is stored on disk when possible, and always mirrored in
 * the PHP session so shared-host write failures cannot block downloads.
 * The .part file is written next to permanent dumps (proven writable).
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

@set_time_limit(30);
@ini_set('max_execution_time', '30');

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']);
    exit;
}

require_once __DIR__ . '/_dump_resolve.php';

try {
    yush_job_gc();

    $raw = file_get_contents('php://input');
    $json = json_decode($raw ?: '', true);
    if (!is_array($json)) $json = $_POST;

    $kind = isset($json['kind']) ? $json['kind'] : '';
    $version = isset($json['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$json['version']) : '';
    $label = isset($json['label']) ? substr(preg_replace('/[^\w\s.\-]/', '', (string)$json['label']), 0, 64) : $version;
    $region = isset($json['region']) ? strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$json['region'])) : 'GARENA';
    $url = isset($json['url']) ? trim((string)$json['url']) : '';

    if (!in_array($kind, ['old', 'new'], true) || $version === '') {
        echo json_encode(['ok' => false, 'error' => 'Invalid kind or version']);
        exit;
    }
    if ($url === '' || !preg_match('#^https?://#i', $url)) {
        echo json_encode(['ok' => false, 'error' => 'Paste a valid http(s) download / share link']);
        exit;
    }

    $resolved = yush_resolve_download_url($url);
    if (!$resolved['ok']) {
        echo json_encode(['ok' => false, 'error' => $resolved['error'] ?? 'Could not resolve that link']);
        exit;
    }

    $jobId = bin2hex(random_bytes(10));

    // .part lives in the same folder as final .cs for this kind (already holds dumps)
    $home = yush_job_home($kind);
    if (!yush_ensure_dir($home)) {
        // Last try: permanent dump dir
        try { $home = yush_dump_dir($kind); } catch (\Throwable $e) {
            $home = yush_jobs_dir();
        }
        yush_ensure_dir($home);
    }
    $tmpPath = rtrim($home, '/\\') . '/' . $version . '_' . $jobId . '.part';

    // Touch the .part file now so we know the path is writable before
    // telling the client to poll.
    $touch = @file_put_contents($tmpPath, '');
    if ($touch === false) {
        // Fall back to jobs dir
        $home = yush_jobs_dir();
        yush_ensure_dir($home);
        $tmpPath = rtrim($home, '/\\') . '/' . $version . '_' . $jobId . '.part';
        $touch = @file_put_contents($tmpPath, '');
    }
    if ($touch === false) {
        echo json_encode([
            'ok' => false,
            'error' => 'Cannot create temp download file. Disk quota may be full, or dumps/ is not writable. Free space in hosting panel and set chmod 777 on dumps/ then retry. Path: ' . $tmpPath,
        ]);
        exit;
    }

    $probedTotal = 0;
    try {
        $probedTotal = yush_probe_content_length($resolved['url']);
    } catch (\Throwable $e) {
        $probedTotal = 0;
    }

    $jobPayload = [
        'id' => $jobId,
        'kind' => $kind,
        'version' => $version,
        'label' => $label ?: $version,
        'region' => $region ?: 'GARENA',
        'sourceUrl' => $url,
        'resolvedUrl' => $resolved['url'],
        'tmp' => $tmpPath,
        'downloaded' => 0,
        'total' => $probedTotal,
        'done' => false,
        'ok' => null,
        'error' => null,
        'size' => 0,
        'chunks' => 0,
        'createdAt' => time(),
    ];

    $wrote = yush_job_write($jobId, $jobPayload);
    $readBack = yush_job_read($jobId);

    if (!$wrote || $readBack === null) {
        echo json_encode([
            'ok' => false,
            'error' => 'Could not store download job. Free disk quota and set chmod 777 on dumps/. Jobs home: ' . $home,
        ]);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'jobId' => $jobId,
        'total' => $probedTotal,
        'warning' => $resolved['warning'] ?? null,
        'storage' => $home,
        // Client echoes these on each chunk poll so downloads survive
        // even if the host cannot keep job JSON on disk between requests.
        'job' => [
            'kind' => $kind,
            'version' => $version,
            'label' => $label ?: $version,
            'region' => $region ?: 'GARENA',
            'sourceUrl' => $url,
            'resolvedUrl' => $resolved['url'],
            'tmp' => $tmpPath,
            'downloaded' => 0,
            'total' => $probedTotal,
            'chunks' => 0,
        ],
    ]);
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
