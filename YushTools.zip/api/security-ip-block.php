<?php
/**
 * Admin Panel "IP Ban List" card — add or remove an IP from the manual
 * blocklist (protection/data/blocked-ips.json), enforced on every request
 * by protection/security.php's yush_run_security_guard().
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../protection/security.php';

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']);
    exit;
}

try {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw ?: '', true);
    if (!is_array($json)) $json = $_POST;

    $action = isset($json['action']) ? (string)$json['action'] : '';
    $ip = isset($json['ip']) ? trim((string)$json['ip']) : '';
    $reason = isset($json['reason']) ? (string)$json['reason'] : '';

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        echo json_encode(['ok' => false, 'error' => 'Enter a valid IP address']);
        exit;
    }

    if ($action === 'add') {
        $ok = yush_add_block_ip($ip, $reason);
        echo json_encode(['ok' => $ok, 'error' => $ok ? null : 'Could not write blocklist file (check protection/data is writable)']);
    } elseif ($action === 'remove') {
        $ok = yush_remove_block_ip($ip);
        echo json_encode(['ok' => $ok, 'error' => $ok ? null : 'Could not write blocklist file']);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Unknown action']);
    }
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
