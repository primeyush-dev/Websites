<?php
/**
 * Permanently delete a cached dump (file + index entry).
 * POST JSON: { kind: "old"|"new", version: "1.6.56" }
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']);
    exit;
}

require_once __DIR__ . '/_dump_resolve.php';

try {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw ?: '', true);
    if (!is_array($json)) $json = $_POST;

    $kind = isset($json['kind']) ? $json['kind'] : '';
    $version = isset($json['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$json['version']) : '';

    if (!in_array($kind, ['old', 'new'], true) || $version === '') {
        echo json_encode(['ok' => false, 'error' => 'Invalid kind or version']);
        exit;
    }

    $dir = yush_dump_dir($kind);
    $path = $dir . '/' . $version . '.cs';
    $metaFile = $dir . '/index.json';

    $deletedFile = false;
    if (is_file($path)) {
        $deletedFile = @unlink($path);
    }

    $meta = [];
    if (is_file($metaFile)) {
        $meta = json_decode((string)@file_get_contents($metaFile), true) ?: [];
    }
    $hadMeta = isset($meta[$version]);
    if ($hadMeta) {
        unset($meta[$version]);
        @file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    if (!$deletedFile && !$hadMeta) {
        echo json_encode(['ok' => false, 'error' => 'Dump not found']);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'version' => $version,
        'kind' => $kind,
        'message' => 'Deleted ' . $kind . ' dump ' . $version
    ]);
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
