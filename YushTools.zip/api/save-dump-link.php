<?php
/**
 * Save dump link + download file permanently into dumps/{old|new}/{version}.cs
 *
 * Streams progress back to the browser as newline-delimited JSON (NDJSON)
 * while the server downloads the linked file, so the admin sees a real
 * progress bar (bytes received / total size, live speed) instead of just
 * staring at a spinner until the whole transfer finishes.
 */
header('Content-Type: application/x-ndjson; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');
header('X-Accel-Buffering: no'); // hint for any reverse proxy: don't buffer this

@set_time_limit(600);
@ini_set('max_execution_time', '600');
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', '0');
while (ob_get_level() > 0) { @ob_end_flush(); }
if (function_exists('apache_setenv')) { @apache_setenv('no-gzip', '1'); }

function yush_ndjson_emit(array $data): void {
    echo json_encode($data, JSON_UNESCAPED_SLASHES) . "\n";
    if (ob_get_level() > 0) @ob_flush();
    @flush();
}

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    yush_ndjson_emit(['type' => 'error', 'error' => 'POST only']);
    exit;
}

require_once __DIR__ . '/_dump_resolve.php';

$raw = file_get_contents('php://input');
$json = json_decode($raw ?: '', true);
if (!is_array($json)) $json = $_POST;

$kind = isset($json['kind']) ? $json['kind'] : '';
$version = isset($json['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$json['version']) : '';
$label = isset($json['label']) ? substr(preg_replace('/[^\w\s.\-]/', '', (string)$json['label']), 0, 64) : $version;
$region = isset($json['region']) ? strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$json['region'])) : 'GARENA';
$url = isset($json['url']) ? trim((string)$json['url']) : '';

if (!in_array($kind, ['old', 'new'], true) || $version === '') {
    yush_ndjson_emit(['type' => 'error', 'error' => 'Invalid kind or version']);
    exit;
}
if ($url === '' || !preg_match('#^https?://#i', $url)) {
    yush_ndjson_emit(['type' => 'error', 'error' => 'Paste a valid http(s) download / share link']);
    exit;
}

yush_ndjson_emit(['type' => 'start', 'kind' => $kind, 'version' => $version]);

$dir = yush_dump_dir($kind);
$metaFile = $dir . '/index.json';
$meta = [];
if (is_file($metaFile)) {
    $meta = json_decode((string)@file_get_contents($metaFile), true) ?: [];
}

$lastEmit = 0.0;
$onProgress = function (int $downloaded, int $total) use (&$lastEmit) {
    $now = microtime(true);
    // Throttle to ~6 updates/sec so the response stream isn't spammed.
    if ($now - $lastEmit < 0.15 && $downloaded !== $total) return;
    $lastEmit = $now;
    yush_ndjson_emit([
        'type' => 'progress',
        'downloaded' => $downloaded,
        'total' => $total, // 0 if the remote server didn't send Content-Length
    ]);
};

$dl = yush_download_dump_to_disk($kind, $version, $url, $onProgress);

if (!$dl['ok']) {
    // Still save the URL so admin can retry / fix link, but mark unavailable size 0
    $meta[$version] = [
        'version' => $version,
        'label' => $label ?: $version,
        'region' => $region ?: 'GARENA',
        'file' => $version . '.cs',
        'url' => $url,
        'size' => 0,
        'uploadedAt' => (int)round(microtime(true) * 1000),
        'source' => 'link',
        'error' => $dl['error'],
    ];
    @file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    yush_ndjson_emit(['type' => 'done', 'ok' => false, 'error' => $dl['error'], 'savedUrl' => true]);
    exit;
}

$meta[$version] = [
    'version' => $version,
    'label' => $label ?: $version,
    'region' => $region ?: 'GARENA',
    'file' => $version . '.cs',
    'url' => $url,
    'size' => $dl['size'],
    'uploadedAt' => (int)round(microtime(true) * 1000),
    'source' => 'cached',
    'resolvedUrl' => $dl['resolved'] ?? '',
];
@file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

yush_ndjson_emit([
    'type' => 'done',
    'ok' => true,
    'version' => $version,
    'kind' => $kind,
    'url' => $url,
    'size' => $dl['size'],
    'cached' => true,
]);
