<?php
/**
 * Admin Panel "Suspicious Activity" dashboard feed.
 *
 * Reads the tail of protection/logs/security.log (written by
 * protection/security.php's yush_log()/yush_block()) and returns the
 * blocked/suspicious entries plus the current IP ban lists, so the admin
 * panel can show real WAF/honeypot activity without a separate service.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../protection/security.php';

/**
 * Buckets a raw block reason into one of a small set of dashboard
 * categories, so the UI can show a meaningful icon/color and roll up
 * "Honeypot Caught" / "Scripted Bots" style summary counts instead of a
 * long tail of internal reason codes.
 */
function yush_event_category(?string $reason): string {
    $reason = (string)($reason ?? '');
    switch ($reason) {
        case 'sensitive-path':
        case 'known-bad-bot':
        case 'path-normalization':
            return 'honeypot'; // hit a fake/forbidden path or a known bad-bot signature
        case 'scripted-client':
        case 'bot-score':
            return 'bot'; // python-requests / curl / scrapy / headless-browser style client
        case 'attack-payload':
            return 'payload'; // request body/query matched an injection/XSS/traversal pattern
        case 'ip-block':
            return 'blocked-ip'; // already on the ban list
        case 'ddos-burst':
        case 'rate-limit':
        case 'crawl-guard':
            return 'flood'; // too many requests / distinct paths too fast
        default:
            return 'other';
    }
}

/** Reads the last $maxLines non-empty lines of $file without loading the whole thing into memory. */
function yush_tail_lines(string $file, int $maxLines): array {
    if (!is_file($file)) return [];
    $fh = @fopen($file, 'r');
    if (!$fh) return [];

    $chunkSize = 8192;
    $pos = filesize($file);
    $buffer = '';
    $lines = [];

    while ($pos > 0) {
        $read = min($chunkSize, $pos);
        $pos -= $read;
        fseek($fh, $pos);
        $buffer = fread($fh, $read) . $buffer;
        $lines = preg_split('/\r\n|\r|\n/', $buffer) ?: [];
        if (count($lines) > $maxLines + 1) break;
    }
    fclose($fh);

    $lines = array_values(array_filter($lines, function ($l) { return trim($l) !== ''; }));
    return array_slice($lines, -$maxLines);
}

try {
    $cfg = yush_cfg();
    $logFile = (string)($cfg['logging']['file'] ?? (__DIR__ . '/../protection/logs/security.log'));

    $rawLines = yush_tail_lines($logFile, 600);

    $events = [];
    foreach (array_reverse($rawLines) as $line) {
        $line = trim($line);
        $prefix = '[YUSH-SECURITY]';
        if (strpos($line, $prefix) === 0) $line = trim(substr($line, strlen($prefix)));
        $row = json_decode($line, true);
        if (!is_array($row) || empty($row['event'])) continue;
        if (!in_array($row['event'], ['blocked', 'temporary_block'], true)) continue;
        $reason = $row['reason'] ?? null;
        $events[] = [
            'event' => $row['event'],
            'reason' => $reason,
            'category' => yush_event_category($reason),
            'ip' => $row['ip'] ?? null,
            'path' => $row['path'] ?? null,
            'method' => $row['method'] ?? null,
            'ua' => $row['ua'] ?? null,
            'status' => $row['status'] ?? null,
            'ts' => $row['ts'] ?? null,
        ];
        if (count($events) >= 200) break;
    }

    $dayAgo = time() - 86400;
    $uniqueIps = [];
    $uniquePaths = [];
    $reasonCounts = [];
    $categoryCounts = [];
    $last24h = 0;
    foreach ($events as $e) {
        $tsUnix = $e['ts'] ? strtotime((string)$e['ts']) : false;
        if ($tsUnix !== false && $tsUnix >= $dayAgo) $last24h++;
        if (!empty($e['ip'])) $uniqueIps[$e['ip']] = true;
        if (!empty($e['path'])) $uniquePaths[$e['path']] = true;
        if (!empty($e['reason'])) $reasonCounts[$e['reason']] = ($reasonCounts[$e['reason']] ?? 0) + 1;
        $categoryCounts[$e['category']] = ($categoryCounts[$e['category']] ?? 0) + 1;
    }
    arsort($reasonCounts);
    $topReason = $reasonCounts ? array_key_first($reasonCounts) : null;

    echo json_encode([
        'ok' => true,
        'events' => $events,
        'summary' => [
            'total' => count($events),
            'last24h' => $last24h,
            'uniqueIps' => count($uniqueIps),
            'uniquePaths' => count($uniquePaths),
            'topReason' => $topReason,
            'honeypotCaught' => $categoryCounts['honeypot'] ?? 0,
            'scriptedBots' => $categoryCounts['bot'] ?? 0,
            'attackPayloads' => $categoryCounts['payload'] ?? 0,
            'floodBlocks' => $categoryCounts['flood'] ?? 0,
        ],
        'blockedIps' => array_values(yush_dynamic_block_ips()),
        'staticBlockedIps' => array_values($cfg['block_ips'] ?? []),
    ]);
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
