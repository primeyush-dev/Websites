<?php
/**
 * Admin dump upload — stores permanent version packages under dumps/{old|new}/
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// Soft bootstrap only — never blank the response on shared-host glitches
try {
  $boot = __DIR__ . '/../protection/bootstrap.php';
  if (is_file($boot)) {
    // Avoid blocking large multipart uploads via body scanners
    if (!defined('YUSH_SKIP_BODY_SCAN')) define('YUSH_SKIP_BODY_SCAN', true);
    require_once $boot;
  }
} catch (Throwable $e) {
  error_log('upload-dump bootstrap: ' . $e->getMessage());
}

require_once __DIR__ . '/_dump_resolve.php';

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'POST only']);
  exit;
}

$kind = isset($_POST['kind']) ? $_POST['kind'] : '';
$version = isset($_POST['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$_POST['version']) : '';
$label = isset($_POST['label']) ? substr(preg_replace('/[^\w\s.\-]/', '', (string)$_POST['label']), 0, 64) : $version;
$region = isset($_POST['region']) ? strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$_POST['region'])) : 'GARENA';

if (!in_array($kind, ['old', 'new'], true) || $version === '') {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid kind or version']);
  exit;
}

if (!isset($_FILES['file'])) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'No file received. Host may block large uploads (raise upload_max_filesize / post_max_size).']);
  exit;
}

$ferr = (int)$_FILES['file']['error'];
if ($ferr !== UPLOAD_ERR_OK) {
  $map = [
    UPLOAD_ERR_INI_SIZE => 'File exceeds PHP upload_max_filesize. Ask host to raise it (dumps are often 50–100MB).',
    UPLOAD_ERR_FORM_SIZE => 'File exceeds form size limit.',
    UPLOAD_ERR_PARTIAL => 'Upload was interrupted. Try again.',
    UPLOAD_ERR_NO_FILE => 'No file chosen.',
    UPLOAD_ERR_NO_TMP_DIR => 'Server missing temp folder.',
    UPLOAD_ERR_CANT_WRITE => 'Server cannot write file.',
    UPLOAD_ERR_EXTENSION => 'Upload blocked by PHP extension.',
  ];
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => $map[$ferr] ?? ('Upload error code ' . $ferr)]);
  exit;
}

$dir = yush_dump_dir($kind);
if (!is_dir($dir)) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Cannot create permanent dumps folder: ' . $dir]);
  exit;
}

$safeName = $version . '.cs';
$dest = $dir . '/' . $safeName;
if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Could not save file (permissions?)']);
  exit;
}

$size = filesize($dest);
$metaFile = $dir . '/index.json';
$meta = [];
if (is_file($metaFile)) {
  $meta = json_decode((string)file_get_contents($metaFile), true) ?: [];
}
$meta[$version] = [
  'version' => $version,
  'label' => $label ?: $version,
  'region' => $region ?: 'GARENA',
  'file' => $safeName,
  'size' => $size,
  'uploadedAt' => (int)round(microtime(true) * 1000),
];
file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo json_encode(['ok' => true, 'version' => $version, 'size' => $size, 'kind' => $kind]);
