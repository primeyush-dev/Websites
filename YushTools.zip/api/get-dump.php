<?php
/**
 * Serve a dump.cs to the Offset Updater.
 * 1) Local disk cache — served instantly, no external request
 * 2) Stream from registered share link + save to disk cache for next time
 */
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
@set_time_limit(600);
@ini_set('max_execution_time', '600');
@ini_set('memory_limit', '512M');

require_once __DIR__ . '/_dump_resolve.php';

$kind    = isset($_GET['kind'])    ? $_GET['kind']    : '';
$version = isset($_GET['version']) ? preg_replace('/[^0-9A-Za-z._-]/', '', (string)$_GET['version']) : '';
if (!in_array($kind, ['old', 'new'], true) || $version === '') {
  http_response_code(400);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' => 'bad request']);
  exit;
}

/* ── Locate metadata (URL + cached .cs path) ──────────────────────────── */
function yush_find_dump_meta(string $kind, string $version): array {
  $url  = '';
  $path = '';
  $base = realpath(__DIR__ . '/..') ?: dirname(__DIR__);

  $pathsToCheck = [];
  try {
    $dir = yush_dump_dir($kind);
    $pathsToCheck[] = $dir . '/' . $version . '.cs';
    $pathsToCheck[] = $dir . '/index.json';
  } catch (\Throwable $e) {}

  if (function_exists('yush_data_root_candidates')) {
    foreach (yush_data_root_candidates() as $root) {
      $pathsToCheck[] = $root . '/' . $kind . '/' . $version . '.cs';
      $pathsToCheck[] = $root . '/' . $kind . '/index.json';
    }
  }
  $pathsToCheck[] = $base . '/dumps/' . $kind . '/' . $version . '.cs';
  $pathsToCheck[] = $base . '/dumps/' . $kind . '/index.json';
  $pathsToCheck[] = $base . '/protection/data/dumps-' . $kind . '.json';

  foreach ($pathsToCheck as $p) {
    if (!is_file($p)) continue;
    if (substr($p, -3) === '.cs' && filesize($p) > 1024) {
      if ($path === '') $path = $p;
    } elseif (substr($p, -5) === '.json') {
      $meta = json_decode((string)@file_get_contents($p), true) ?: [];
      if (isset($meta[$version]['url']) && $url === '') {
        $url = trim((string)$meta[$version]['url']);
      }
      if (!empty($meta[$version]['file'])) {
        $maybe = dirname($p) . '/' . $meta[$version]['file'];
        if (is_file($maybe) && filesize($maybe) > 1024 && $path === '') $path = $maybe;
      }
    }
  }
  return ['url' => $url, 'path' => $path];
}

/* ── Helper: serve a local file directly ─────────────────────────────── */
function yush_serve_file(string $path): void {
  header('Content-Type: text/plain; charset=utf-8');
  header('Content-Length: ' . filesize($path));
  header('Cache-Control: private, max-age=300');
  header('X-Dump-Source: cache');
  readfile($path);
  exit;
}

/* ── Helper: save downloaded bytes to disk cache ─────────────────────── */
function yush_save_cache(string $kind, string $version, string $body): void {
  try {
    $dir  = yush_dump_dir($kind);
    $dest = $dir . '/' . $version . '.cs';
    @file_put_contents($dest, $body);

    // Update index.json size entry so list-dumps picks it up
    $metaFile = $dir . '/index.json';
    $meta = [];
    if (is_file($metaFile)) $meta = json_decode((string)@file_get_contents($metaFile), true) ?: [];
    if (!isset($meta[$version])) $meta[$version] = ['version' => $version];
    $meta[$version]['file']       = $version . '.cs';
    $meta[$version]['size']       = strlen($body);
    $meta[$version]['uploadedAt'] = (int)round(microtime(true) * 1000);
    $meta[$version]['source']     = 'auto-cached';
    @file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
  } catch (\Throwable $e) { /* non-fatal */ }
}

/* ── 1. Serve from disk cache if available (instant) ─────────────────── */
$found = yush_find_dump_meta($kind, $version);
$path  = $found['path'];
$url   = $found['url'];

if ($path !== '' && is_file($path) && filesize($path) > 1024) {
  $fh   = @fopen($path, 'rb');
  $head = $fh ? (string)fread($fh, 256) : '';
  if ($fh) fclose($fh);
  $hl = strtolower($head);
  if (strpos($hl, '<html') === false && strpos($hl, '<!doctype') === false) {
    yush_serve_file($path);
  }
}

/* ── 2. No cache — need to download from share link ─────────────────── */
if ($url === '') {
  http_response_code(404);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' =>
    'Dump ' . $kind . ' ' . $version . ' not found. Admin must Save Dump Link for this version first.']);
  exit;
}

$resolved = yush_resolve_download_url($url);
if (empty($resolved['ok']) || empty($resolved['url'])) {
  http_response_code(502);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' => $resolved['error'] ?? 'Could not resolve dump download link']);
  exit;
}
$direct = $resolved['url'];

if (!function_exists('curl_init')) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' => 'curl not available on server']);
  exit;
}

/* ── Download into memory buffer, then cache + serve ─────────────────── */
$ch = curl_init($direct);
$buffer = '';
curl_setopt_array($ch, [
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_MAXREDIRS      => 12,
  CURLOPT_CONNECTTIMEOUT => 30,
  CURLOPT_TIMEOUT        => 560,
  CURLOPT_SSL_VERIFYPEER => true,
  CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  CURLOPT_HTTPHEADER     => ['Accept: text/plain,*/*', 'Accept-Language: en-US,en;q=0.9'],
  CURLOPT_WRITEFUNCTION  => function ($ch, $data) use (&$buffer) {
    $buffer .= $data;
    return strlen($data);
  },
]);

$ok   = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err  = curl_error($ch);
curl_close($ch);

if ($ok === false || $code >= 400 || strlen($buffer) < 256) {
  http_response_code(502);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' =>
    'Failed to download dump (HTTP ' . $code . '). ' . ($err ?: 'Check the share link.')]);
  exit;
}

/* Reject HTML responses (share-page instead of raw file) */
$sampleLower = strtolower(substr($buffer, 0, 512));
if (strpos($sampleLower, '<html') !== false || strpos($sampleLower, '<!doctype') !== false) {
  http_response_code(502);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' =>
    'Dump link returned an HTML page instead of the .cs file. Re-save the dump link in Admin Panel.']);
  exit;
}

/* ── Save to disk so next request is instant ─────────────────────────── */
yush_save_cache($kind, $version, $buffer);

/* ── Serve the downloaded content directly ───────────────────────────── */
header('Content-Type: text/plain; charset=utf-8');
header('Content-Length: ' . strlen($buffer));
header('Cache-Control: private, max-age=300');
header('X-Dump-Source: stream-then-cached');
echo $buffer;
