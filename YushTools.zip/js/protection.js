/*
 * YUSH TOOLS — client defensive layer
 * Reduces casual cloning / scraping. Not a substitute for server WAF.
 */
(function () {
  'use strict';

  // Rate-limit expensive actions (update runs)
  var ACTION_WINDOW_MS = 10000;
  var MAX_ACTIONS = 8;
  var timestamps = [];
  function allowed() {
    var now = Date.now();
    timestamps = timestamps.filter(function (t) { return now - t < ACTION_WINDOW_MS; });
    if (timestamps.length >= MAX_ACTIONS) return false;
    timestamps.push(now);
    return true;
  }
  window.__yushGuardAction = allowed;

  // Discourage casual save-as / print cloning of the shell UI
  document.addEventListener('keydown', function (e) {
    var key = (e.key || '').toLowerCase();
    var ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && (key === 's' || key === 'u' || key === 'p')) {
      e.preventDefault();
      return false;
    }
    if (e.key === 'F12') {
      // allow for owner debugging — only soft-discourage
    }
  }, true);

  // Block drag-out of images
  document.addEventListener('dragstart', function (e) {
    if (e.target && e.target.tagName === 'IMG') e.preventDefault();
  }, true);

  // Clear selection of large code blocks on copy spam is not needed

  // Detect headless-ish automation (lightweight)
  try {
    if (navigator.webdriver) {
      console.warn('[YUSH] automated browser detected');
    }
  } catch (e) {}
})();
