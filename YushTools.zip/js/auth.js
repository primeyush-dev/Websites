/**
 * YUSH UPDATOR — Auth System
 * - Hard-coded owner: primeyush@gmail.com / pamplona0618
 * - Free users require owner approval (stored in localStorage)
 * - Remember-me is opt-in
 * - No bot / Telegram approval system
 */
(function () {
  'use strict';

  var OWNER_EMAIL = 'primeyush@gmail.com';
  var OWNER_PASS  = 'pamplona0618';

  var DB_KEY          = '__yush_users_v2__';
  var PENDING_KEY     = '__yush_pending_v2__';
  var SESSION_KEY     = '__yush_session_v2__';
  var REMEMBER_EMAIL  = '__yush_remembered_email__';
  var REMEMBER_PASS   = '__yush_remembered_password__';
  var ATTACKS_KEY     = '__yush_attacks_v2__';
  var NOTIFS_KEY      = '__yush_notifs_v2__';
  /** Session stays valid for 1 day across reloads / website restarts */
  var SESSION_MAX_MS  = 24 * 60 * 60 * 1000;

  /* ── storage helpers ── */
  function load(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch (e) { return fallback; }
  }
  function save(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }

  function usersDB() { return load(DB_KEY, {}); }
  function saveUsers(db) { save(DB_KEY, db); }
  function pendingDB() { return load(PENDING_KEY, {}); }
  function savePending(db) { save(PENDING_KEY, db); }
  function attacksDB() { return load(ATTACKS_KEY, []); }
  function saveAttacks(arr) { save(ATTACKS_KEY, arr); }
  function notifsDB() { return load(NOTIFS_KEY, []); }
  function saveNotifs(arr) { save(NOTIFS_KEY, arr); }

  function getSession() {
    try {
      var raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || !obj.email) return null;
      var loginAt = obj.loginAt || 0;
      var expiresAt = obj.expiresAt || (loginAt + SESSION_MAX_MS);
      if (Date.now() > expiresAt) {
        clearSession();
        return null;
      }
      return obj;
    } catch (e) { return null; }
  }
  function setSession(obj) {
    try {
      if (obj && !obj.expiresAt) {
        obj.expiresAt = (obj.loginAt || Date.now()) + SESSION_MAX_MS;
      }
      localStorage.setItem(SESSION_KEY, JSON.stringify(obj));
      // Clear legacy sessionStorage key if present
      try { sessionStorage.removeItem(SESSION_KEY); } catch (e2) {}
    } catch (e) {}
  }
  function clearSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (e) {}
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
  }

  /* ── profile helpers ── */
  function nameFromEmail(email) {
    if (!email) return 'User';
    var local = email.split('@')[0] || 'User';
    // Capitalize first letter of each segment
    return local.replace(/[._-]+/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); }).replace(/\s+/g, '') || 'User';
  }
  function initialFromEmail(email) {
    var n = nameFromEmail(email);
    return (n.charAt(0) || 'U').toUpperCase();
  }

  /* ── public API ── */
  window.Auth = window.YushAuth = {
    OWNER_EMAIL: OWNER_EMAIL,

    isOwner: function (email) {
      return (email || '').toLowerCase().trim() === OWNER_EMAIL;
    },

    getCurrentUser: function () {
      return getSession();
    },

    nameFromEmail: nameFromEmail,
    initialFromEmail: initialFromEmail,

    login: function (email, password, remember) {
      email = (email || '').toLowerCase().trim();
      password = password || '';

      if (!email || !password) return { ok: false, error: 'Email and password are required.' };

      // Owner hard access — no registration needed
      if (email === OWNER_EMAIL && password === OWNER_PASS) {
        var now = Date.now();
        var ownerSession = {
          email: OWNER_EMAIL,
          role: 'admin',
          status: 'active',
          name: nameFromEmail(OWNER_EMAIL),
          expiry: null,
          loginAt: now,
          expiresAt: now + SESSION_MAX_MS
        };
        setSession(ownerSession);
        if (remember) {
          localStorage.setItem(REMEMBER_EMAIL, email);
          localStorage.setItem(REMEMBER_PASS, password);
        } else {
          localStorage.removeItem(REMEMBER_EMAIL);
          localStorage.removeItem(REMEMBER_PASS);
        }
        return { ok: true, user: ownerSession };
      }

      // Check banned
      var db = usersDB();
      var user = db[email];
      if (user && user.status === 'banned') {
        this._logAttack('banned_login', email);
        return { ok: false, error: 'This account has been banned.' };
      }

      if (!user) {
        // Maybe still pending?
        var pend = pendingDB();
        if (pend[email]) {
          return { ok: false, error: 'Your account is still awaiting approval.', pending: true };
        }
        this._logAttack('unknown_login', email);
        return { ok: false, error: 'Invalid email or password.' };
      }

      if (user.password !== password) {
        this._logAttack('wrong_password', email);
        return { ok: false, error: 'Invalid email or password.' };
      }

      if (user.status !== 'active') {
        return { ok: false, error: 'Account is not active (status: ' + user.status + ').' };
      }

      var now = Date.now();
      var session = {
        email: email,
        role: user.role || 'user',
        status: 'active',
        name: user.name || nameFromEmail(email),
        expiry: user.expiry || null,
        loginAt: now,
        expiresAt: now + SESSION_MAX_MS
      };
      setSession(session);
      if (remember) {
        localStorage.setItem(REMEMBER_EMAIL, email);
        localStorage.setItem(REMEMBER_PASS, password);
      } else {
        localStorage.removeItem(REMEMBER_EMAIL);
        localStorage.removeItem(REMEMBER_PASS);
      }
      return { ok: true, user: session };
    },

    register: function (email, password) {
      email = (email || '').toLowerCase().trim();
      password = password || '';

      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return { ok: false, error: 'Please enter a valid email address.' };
      }
      if (password.length < 6) {
        return { ok: false, error: 'Password must be at least 6 characters.' };
      }
      if (email === OWNER_EMAIL) {
        return { ok: false, error: 'This email is reserved.' };
      }

      var db = usersDB();
      if (db[email]) return { ok: false, error: 'An account with this email already exists.' };

      var pend = pendingDB();
      if (pend[email]) return { ok: false, error: 'A registration request is already pending for this email.' };

      pend[email] = {
        email: email,
        password: password,
        requestedAt: Date.now(),
        ip: 'client', // client-side demo
        ua: navigator.userAgent || ''
      };
      savePending(pend);

      // Notify owner
      var notifs = notifsDB();
      notifs.unshift({
        id: Date.now(),
        type: 'pending',
        message: 'New registration request: ' + email,
        time: Date.now(),
        read: false
      });
      saveNotifs(notifs);

      return { ok: true, pending: true };
    },

    cancelPending: function (email) {
      email = (email || '').toLowerCase().trim();
      var pend = pendingDB();
      delete pend[email];
      savePending(pend);
    },

    logout: function () {
      clearSession();
    },

    /* ── Admin actions ── */
    getPending: function () {
      return pendingDB();
    },

    approveUser: function (email) {
      email = (email || '').toLowerCase().trim();
      var pend = pendingDB();
      var req = pend[email];
      if (!req) return { ok: false, error: 'Request not found.' };

      var db = usersDB();
      db[email] = {
        email: email,
        password: req.password,
        role: 'user',
        status: 'active',
        name: nameFromEmail(email),
        createdAt: Date.now(),
        approvedAt: Date.now(),
        expiry: null
      };
      saveUsers(db);
      delete pend[email];
      savePending(pend);

      var notifs = notifsDB();
      notifs.unshift({ id: Date.now(), type: 'approved', message: 'Approved: ' + email, time: Date.now(), read: false });
      saveNotifs(notifs);

      return { ok: true };
    },

    rejectUser: function (email) {
      email = (email || '').toLowerCase().trim();
      var pend = pendingDB();
      delete pend[email];
      savePending(pend);
      return { ok: true };
    },

    getUsers: function () {
      return usersDB();
    },

    banUser: function (email) {
      email = (email || '').toLowerCase().trim();
      if (email === OWNER_EMAIL) return { ok: false, error: 'Cannot ban owner.' };
      var db = usersDB();
      if (!db[email]) return { ok: false, error: 'User not found.' };
      db[email].status = 'banned';
      saveUsers(db);
      return { ok: true };
    },

    unbanUser: function (email) {
      email = (email || '').toLowerCase().trim();
      var db = usersDB();
      if (!db[email]) return { ok: false, error: 'User not found.' };
      db[email].status = 'active';
      saveUsers(db);
      return { ok: true };
    },

    deleteUser: function (email) {
      email = (email || '').toLowerCase().trim();
      if (email === OWNER_EMAIL) return { ok: false, error: 'Cannot delete owner.' };
      var db = usersDB();
      delete db[email];
      saveUsers(db);
      return { ok: true };
    },

    promoteUser: function (email) {
      email = (email || '').toLowerCase().trim();
      var db = usersDB();
      if (!db[email]) return { ok: false, error: 'User not found.' };
      db[email].role = 'admin';
      saveUsers(db);
      return { ok: true };
    },

    demoteUser: function (email) {
      email = (email || '').toLowerCase().trim();
      var db = usersDB();
      if (!db[email]) return { ok: false, error: 'User not found.' };
      db[email].role = 'user';
      saveUsers(db);
      return { ok: true };
    },

    changePassword: function (email, currentPass, newPass) {
      email = (email || '').toLowerCase().trim();
      if (email === OWNER_EMAIL) {
        // Owner password is hardcoded — cannot change via UI in this version
        return { ok: false, error: 'Owner password is managed server-side and cannot be changed here.' };
      }
      var db = usersDB();
      var user = db[email];
      if (!user) return { ok: false, error: 'User not found.' };
      if (user.password !== currentPass) return { ok: false, error: 'Current password is incorrect.' };
      if (newPass.length < 6) return { ok: false, error: 'New password must be at least 6 characters.' };
      user.password = newPass;
      saveUsers(db);
      return { ok: true };
    },

    updateName: function (email, name) {
      email = (email || '').toLowerCase().trim();
      if (email === OWNER_EMAIL) {
        // Update session only for owner
        var s = getSession();
        if (s) { s.name = name || nameFromEmail(email); setSession(s); }
        return { ok: true };
      }
      var db = usersDB();
      if (!db[email]) return { ok: false, error: 'User not found.' };
      db[email].name = name || nameFromEmail(email);
      saveUsers(db);
      var s = getSession();
      if (s && s.email === email) { s.name = db[email].name; setSession(s); }
      return { ok: true };
    },

    getAttacks: function () { return attacksDB(); },

    getNotifications: function () { return notifsDB(); },

    markNotifsRead: function () {
      var n = notifsDB();
      n.forEach(function (x) { x.read = true; });
      saveNotifs(n);
    },

    _logAttack: function (type, email) {
      var arr = attacksDB();
      arr.unshift({
        type: type,
        email: email || '',
        ip: 'client',
        ua: (navigator.userAgent || '').slice(0, 120),
        time: Date.now()
      });
      if (arr.length > 100) arr = arr.slice(0, 100);
      saveAttacks(arr);
    },

    loadRemembered: function () {
      try {
        return {
          email: localStorage.getItem(REMEMBER_EMAIL) || '',
          password: localStorage.getItem(REMEMBER_PASS) || ''
        };
      } catch (e) { return { email: '', password: '' }; }
    }
  };


  /* ── Global UI helpers (always available) ── */
  window.togglePwd = function (inputId, btn) {
    var inp = document.getElementById(inputId);
    if (!inp) return;
    var show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    if (btn) {
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.classList.toggle('is-visible', !!show);
      var eye = btn.querySelector('.eye-open');
      var eyeOff = btn.querySelector('.eye-off');
      if (eye && eyeOff) {
        eye.style.setProperty('display', show ? 'none' : 'block', 'important');
        eyeOff.style.setProperty('display', show ? 'block' : 'none', 'important');
      }
    }
  };

  window.showLogin = function () {
    var a = document.getElementById('authLoginView');
    var b = document.getElementById('authRegisterView');
    var c = document.getElementById('authPendingView');
    if (a) a.style.display = '';
    if (b) b.style.display = 'none';
    if (c) c.style.display = 'none';
    var e1 = document.getElementById('loginError'); if (e1) e1.textContent = '';
    var e2 = document.getElementById('regError'); if (e2) e2.textContent = '';
  };

  window.showRegister = function () {
    var a = document.getElementById('authLoginView');
    var b = document.getElementById('authRegisterView');
    var c = document.getElementById('authPendingView');
    if (a) a.style.display = 'none';
    if (b) b.style.display = '';
    if (c) c.style.display = 'none';
    var e1 = document.getElementById('loginError'); if (e1) e1.textContent = '';
    var e2 = document.getElementById('regError'); if (e2) e2.textContent = '';
  };

  window.showPending = function (email) {
    var a = document.getElementById('authLoginView');
    var b = document.getElementById('authRegisterView');
    var c = document.getElementById('authPendingView');
    if (a) a.style.display = 'none';
    if (b) b.style.display = 'none';
    if (c) c.style.display = '';
    var pe = document.getElementById('pendingEmailDisplay');
    if (pe) pe.textContent = email || '';
  };

  window.cancelPending = function () {
    try {
      var pe = document.getElementById('pendingEmailDisplay');
      var email = pe ? pe.textContent : '';
      if (window.Auth && email) Auth.cancelPending(email);
    } catch (e) {}
    window.showLogin();
  };

})();
