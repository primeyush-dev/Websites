/**
 * YUSH TOOLS — Main Application Logic
 */
(function () {
  'use strict';
  if (typeof window.Auth === 'undefined' && typeof window.YushAuth !== 'undefined') {
    window.Auth = window.YushAuth;
  }
  if (typeof window.Auth === 'undefined') {
    console.error('YUSH TOOLS: Auth module failed to load — check js/auth.js path');
  }
  var Auth = window.Auth || window.YushAuth || null;

  /* Prefixes every api/*.php call with window.YUSH_API_BASE (set near the
     top of index.html). Needed because Netlify (and similar static-only
     hosts) can't execute PHP — pointing this at a real PHP host is the
     fix for "Bad server response (HTTP 404)" on the upload/admin calls. */
  function yushApi(path) {
    var base = (window.YUSH_API_BASE || '').replace(/\/+$/, '');
    return base ? (base + '/' + String(path).replace(/^\/+/, '')) : path;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  var currentTab = 'updater';
  var S = { old: null, 'new': null, tgt: null, sources: [] };
  var selectedOldVersion = null;
  var JOBS_KEY = '__yush_jobs_v1__';
  var R = { all: [], updated: [], failed: [], ignored: [], same: [] };
  var _worker = null;
  var _updatedText = null;
  var _lastRunAt = 0;
  var RUN_COOLDOWN_MS = 1500;
  var SETTINGS_KEY = 'yushUpdaterSettings';
  var DEFAULT_SETTINGS = { autoDownload: false, copyEnabled: true };
  var SETTINGS = Object.assign({}, DEFAULT_SETTINGS);

  /* ════════════════════════════════════════
     BOOT
     ════════════════════════════════════════ */
  function formatPHTime(ts) {
    if (!ts) return 'Not uploaded yet';
    try {
      var d = new Date(ts);
      return d.toLocaleString('en-PH', {
        timeZone: 'Asia/Manila',
        month: 'numeric', day: 'numeric', year: 'numeric',
        hour: 'numeric', minute: '2-digit', second: '2-digit',
        hour12: true
      });
    } catch (e) {
      try { return new Date(ts).toLocaleString(); } catch (e2) { return '—'; }
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    try { loadSettings(); } catch (e) { console.warn(e); }
    try { bindAuthUI(); } catch (e) { console.error('bindAuthUI', e); }
    try { bindAppUI(); } catch (e) { console.warn('bindAppUI', e); }
    try { bindUpdater(); } catch (e) { console.warn('bindUpdater', e); }
    try { bindFinder(); } catch (e) { console.warn('bindFinder', e); }
    try { bindSettings(); } catch (e) { console.warn('bindSettings', e); }
    try { bindAdminUploads(); } catch (e) { console.warn('bindAdminUploads', e); }
    try { if (window.YushFormatting && window.YushFormatting.init) window.YushFormatting.init(); } catch (e) { console.warn('YushFormatting', e); }
    try { bindLegalModal(); } catch (e) { console.warn('bindLegalModal', e); }
    try { if (Auth) tryAutoLogin(); } catch (e) { console.warn('tryAutoLogin', e); }
    try { renderLoginTurnstile(); } catch (e) {}
    try { renderAdminDumpList(); } catch (e) {}
    try {
      var rbtn = document.getElementById('btnRefreshDumpList');
      if (rbtn) rbtn.onclick = function () { renderAdminDumpList(); };
    } catch (e) {}
  });

  // Also expose immediately for early inline clicks
  window.doLogin = function () { console.warn('App still loading…'); };
  window.doRegister = function () { console.warn('App still loading…'); };
  window.doSendCode = function () { console.warn('App still loading…'); };

  function tryAutoLogin() {
    var session = Auth.getCurrentUser();
    if (session) {
      document.documentElement.classList.add('yush-authed');
      showApp(session);
      return;
    }
    document.documentElement.classList.remove('yush-authed');
    // Pre-fill remember-me
    var rem = Auth.loadRemembered();
    if (rem.email) {
      var le = document.getElementById('loginEmail');
      var lp = document.getElementById('loginPassword');
      var rm = document.getElementById('rememberMe');
      if (le) le.value = rem.email;
      if (lp) lp.value = rem.password || '';
      if (rm) rm.checked = true;
    }
  }

  /* ════════════════════════════════════════
     AUTH UI
     ════════════════════════════════════════ */
  function bindAuthUI() {
    function on(id, evt, fn) {
      var el = document.getElementById(id);
      if (el) el.addEventListener(evt, fn);
    }
    on('btnLogin', 'click', doLogin);
    on('btnRegister', 'click', doRegister);
    on('gotoRegister', 'click', function () { showAuthView('register'); });
    on('gotoLogin', 'click', function () { showAuthView('login'); });
    on('btnCancelPending', 'click', function () {
      try {
        var email = (document.getElementById('pendingEmailDisplay') || {}).textContent || '';
        if (Auth) Auth.cancelPending(email);
      } catch (e) {}
      showAuthView('login');
    });
    on('loginPassword', 'keydown', function (e) { if (e.key === 'Enter') doLogin(); });
    on('regPassword2', 'keydown', function (e) { if (e.key === 'Enter') doRegister(); });
    on('sendCodeBtn', 'click', doSendCode);

    document.querySelectorAll('.auth-eye').forEach(function (btn) {
      // Guard: skip if this button already has a bound listener (prevents double-toggle)
      if (btn.dataset.eyeBound) return;
      btn.dataset.eyeBound = '1';
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-target');
        if (window.togglePwd) window.togglePwd(id, btn);
        else {
          var inp = document.getElementById(id);
          if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
        }
      });
    });

    // Expose to window for inline handlers
    window.doLogin = doLogin;
    window.doRegister = doRegister;
    window.doSendCode = doSendCode;
    window.showAuthView = showAuthView;
  }

  function showAuthView(name) {
    var a = document.getElementById('authLoginView');
    var b = document.getElementById('authRegisterView');
    var c = document.getElementById('authPendingView');
    if (a) a.style.display = name === 'login' ? '' : 'none';
    if (b) b.style.display = name === 'register' ? '' : 'none';
    if (c) c.style.display = name === 'pending' ? '' : 'none';
    var e1 = document.getElementById('loginError'); if (e1) e1.textContent = '';
    var e2 = document.getElementById('regError'); if (e2) e2.textContent = '';
    if (name === 'login') setTimeout(renderLoginTurnstile, 50);
  }


  var TURNSTILE_SITE_KEY = '0x4AAAAAAEvFlouUrYi5Y6Tj';
  var TURNSTILE_VERIFY_ENDPOINT = yushApi('api/login-captcha-verify.php');
  var _loginTurnstileWidgetId = null;

  function renderLoginTurnstile(attempt) {
    attempt = attempt || 0;
    var mount = document.getElementById('loginTurnstile');
    if (!mount) return;
    if (!window.turnstile) {
      if (attempt > 40) return;
      setTimeout(function () { renderLoginTurnstile(attempt + 1); }, 250);
      return;
    }
    try {
      if (_loginTurnstileWidgetId !== null) {
        window.turnstile.remove(_loginTurnstileWidgetId);
        _loginTurnstileWidgetId = null;
      }
    } catch (e) {}
    mount.innerHTML = '';
    _loginTurnstileWidgetId = window.turnstile.render(mount, {
      sitekey: TURNSTILE_SITE_KEY,
      theme: document.body.classList.contains('light') ? 'light' : 'dark',
      size: 'flexible',
      callback: function () {
        var err = document.getElementById('loginError');
        if (err) err.textContent = '';
      },
      'expired-callback': function () {
        var err = document.getElementById('loginError');
        if (err) err.textContent = 'Verification expired — check the box again.';
      },
      'error-callback': function () {
        var err = document.getElementById('loginError');
        if (err) err.textContent = 'Verification failed to load. Refresh and try again.';
      }
    });
  }

  function getTurnstileToken() {
    try {
      if (window.turnstile && _loginTurnstileWidgetId !== null) {
        return window.turnstile.getResponse(_loginTurnstileWidgetId) || '';
      }
    } catch (e) {}
    var inp = document.querySelector('#loginTurnstile [name="cf-turnstile-response"], [name="cf-turnstile-response"]');
    return inp ? (inp.value || '') : '';
  }

  function resetTurnstile() {
    try {
      if (window.turnstile && _loginTurnstileWidgetId !== null) {
        window.turnstile.reset(_loginTurnstileWidgetId);
      }
    } catch (e) {}
  }

  function verifyTurnstileToken(token, onResult) {
    fetch(TURNSTILE_VERIFY_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: token, website: '' })
    })
      .then(function (res) { return res.json().catch(function () { return null; }); })
      .then(function (data) { onResult(!!(data && data.success)); })
      .catch(function () { onResult(true); }); // if API unreachable, don't lock the owner out
  }

  function doLogin() {
    if (!Auth) { alert('Auth failed to load. Re-upload js/auth.js'); return; }
    var emailEl = document.getElementById('loginEmail');
    var passEl = document.getElementById('loginPassword');
    var remEl = document.getElementById('rememberMe');
    var errEl = document.getElementById('loginError');
    if (!emailEl || !passEl) return;
    var email = emailEl.value;
    var pass = passEl.value;
    var remember = remEl ? remEl.checked : false;
    if (errEl) errEl.textContent = '';

    var token = getTurnstileToken();
    if (!token) {
      if (errEl) errEl.textContent = 'Please complete the verification check.';
      return;
    }

    function finishLogin() {
      var res = Auth.login(email, pass, remember);
      if (!res.ok) {
        if (errEl) errEl.textContent = res.error;
        resetTurnstile();
        if (res.pending) {
          var pe = document.getElementById('pendingEmailDisplay');
          if (pe) pe.textContent = email.toLowerCase().trim();
          showAuthView('pending');
        }
        return;
      }
      showApp(res.user);
    }

    verifyTurnstileToken(token, function (ok) {
      // Token already issued by Cloudflare widget. If server verify fails
      // (new hostname not yet added in Turnstile dashboard), still allow login.
      if (!ok) {
        console.warn('Turnstile server verify failed — proceeding because widget token exists.');
      }
      finishLogin();
    });
  }

  var _pendingCode = null;
  var _codeCooldownTimer = null;
  var EMAILJS_PUBLIC_KEY  = 'ZAhhQvlMpNMCivJhn';
  var EMAILJS_SERVICE_ID  = 'service_1sf8dfm';
  var EMAILJS_TEMPLATE_ID = 'template_68iwuwd';
  var CODE_TTL_MS = 5 * 60 * 1000;
  var TURNSTILE_VERIFY_ENDPOINT = yushApi('api/login-captcha-verify.php');
  var _emailjsReady = false;

  function ensureEmailJS(cb, onErr) {
    if (_emailjsReady && window.emailjs) { cb(); return; }
    function init() {
      try {
        window.emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
        _emailjsReady = true;
        cb();
      } catch (e) {
        if (onErr) onErr(e);
      }
    }
    if (window.emailjs) { init(); return; }
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
    s.onload = init;
    s.onerror = function () { if (onErr) onErr(new Error('Failed to load EmailJS')); };
    document.head.appendChild(s);
  }

  function sendVerificationEmail(email, code, onSuccess, onError) {
    ensureEmailJS(function () {
      window.emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
        to_email: email,
        email: email,
        code: code,
        passcode: code,
        user_email: email
      }).then(function () {
        if (onSuccess) onSuccess();
      }).catch(function (err) {
        if (onError) onError(err);
      });
    }, onError);
  }

  function startCodeCooldown(btn) {
    btn.disabled = true;
    var left = 60;
    btn.textContent = left + 's';
    if (_codeCooldownTimer) clearInterval(_codeCooldownTimer);
    _codeCooldownTimer = setInterval(function () {
      left--;
      if (left <= 0) {
        clearInterval(_codeCooldownTimer);
        btn.disabled = false;
        btn.textContent = 'Send code';
      } else {
        btn.textContent = left + 's';
      }
    }, 1000);
  }

  function doSendCode() {
    var email = (document.getElementById('regEmail').value || '').trim().toLowerCase();
    var statusEl = document.getElementById('codeStatus');
    var btn = document.getElementById('sendCodeBtn');
    var errEl = document.getElementById('regError');
    errEl.textContent = '';
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errEl.textContent = 'Enter a valid email first.';
      return;
    }
    if (btn.disabled) return;
    statusEl.className = 'auth-code-status checking show';
    statusEl.textContent = 'Sending verification code…';
    var code = String(Math.floor(100000 + Math.random() * 900000));
    sendVerificationEmail(email, code, function () {
      _pendingCode = { email: email, code: code, expiresAt: Date.now() + CODE_TTL_MS };
      statusEl.className = 'auth-code-status ok show';
      statusEl.textContent = 'Code sent! Check your inbox and paste the 6-digit code.';
      startCodeCooldown(btn);
    }, function (err) {
      statusEl.className = 'auth-code-status fail show';
      statusEl.textContent = 'Failed to send code. Try again later.';
      console.warn('EmailJS error', err);
      btn.disabled = false;
      btn.textContent = 'Send code';
    });
  }

  function doRegister() {
    if (!Auth) { alert('Auth failed to load. Re-upload js/auth.js'); return; }
    var email = document.getElementById('regEmail').value;
    var pass = document.getElementById('regPassword').value;
    var pass2 = document.getElementById('regPassword2').value;
    var code = (document.getElementById('regCode').value || '').trim();
    var errEl = document.getElementById('regError');
    if (pass !== pass2) {
      errEl.textContent = 'Passwords do not match.';
      return;
    }
    if (!_pendingCode || _pendingCode.email !== (email || '').toLowerCase().trim()) {
      errEl.textContent = 'Please send and enter the verification code first.';
      return;
    }
    if (Date.now() > _pendingCode.expiresAt) {
      errEl.textContent = 'Verification code expired. Request a new one.';
      return;
    }
    if (code !== _pendingCode.code) {
      errEl.textContent = 'Invalid verification code.';
      return;
    }
    var res = Auth.register(email, pass);
    if (!res.ok) {
      errEl.textContent = res.error;
      return;
    }
    _pendingCode = null;
    document.getElementById('pendingEmailDisplay').textContent = email.toLowerCase().trim();
    showAuthView('pending');
  }

  function showApp(user) {
    document.documentElement.classList.add('yush-authed');
    var ao = document.getElementById('authOverlay');
    var ma = document.getElementById('mainApp');
    if (ao) ao.style.display = 'none';
    if (ma) ma.style.display = '';
    updateProfileUI(user);
    // Show admin tab only for owner / admin role
    var isAdmin = user.role === 'admin' || Auth.isOwner(user.email);
    document.querySelectorAll('.admin-only').forEach(function (el) {
      el.style.display = isAdmin ? '' : 'none';
    });
    updateNotifBadge();
    switchTab('dashboard');
    refreshDashboard();
    loadOldVersions();
    loadNewVersions();
  }

  function updateProfileUI(user) {
    var name = user.name || Auth.nameFromEmail(user.email);
    var initial = Auth.initialFromEmail(user.email);
    document.getElementById('btnProfile').textContent = initial;
    document.getElementById('popoverAvatar').textContent = initial;
    document.getElementById('popoverName').textContent = name;
    document.getElementById('popoverHandle').textContent = '@' + (user.email || '');
    document.getElementById('popoverRole').textContent = user.role === 'admin' ? 'Admin' : 'User';
    document.getElementById('popoverStatus').textContent = user.status === 'active' ? 'Active' : user.status;
    document.getElementById('popoverExpiry').textContent = user.expiry
      ? 'Expires ' + new Date(user.expiry).toLocaleDateString()
      : 'Never';
    document.getElementById('settingsEmailDisplay').textContent = user.email || '—';
    var ef = document.getElementById('setEmailField'); if (ef) ef.value = '';
  }

  /* ════════════════════════════════════════
     APP UI — drawer, tabs, theme, profile
     ════════════════════════════════════════ */
  function bindAppUI() {
    var burger = document.getElementById('btnBurger');
    var drawer = document.getElementById('drawer');
    var overlay = document.getElementById('drawerOverlay');
    var closeBtn = document.getElementById('btnDrawerClose');

    function openDrawer() {
      if (drawer) drawer.classList.add('open');
      if (overlay) overlay.classList.add('open');
    }
    function closeDrawer() {
      if (drawer) drawer.classList.remove('open');
      if (overlay) overlay.classList.remove('open');
    }

    if (burger) burger.addEventListener('click', openDrawer);
    if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
    if (overlay) overlay.addEventListener('click', closeDrawer);

    document.querySelectorAll('.drawer-item').forEach(function (item) {
      item.addEventListener('click', function () {
        var tab = item.getAttribute('data-tab');
        if (!tab) return;
        try { switchTab(tab); } catch (err) { console.error('switchTab', err); }
        closeDrawer();
      });
    });

    document.getElementById('btnLogout').addEventListener('click', function () {
      Auth.logout();
      location.reload();
    });

    // Profile popover
    var profileBtn = document.getElementById('btnProfile');
    var popover = document.getElementById('profilePopover');
    profileBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var visible = popover.style.display !== 'none';
      closeAllPopups();
      popover.style.display = visible ? 'none' : '';
    });
    document.getElementById('btnManageAccount').addEventListener('click', function () {
      closeAllPopups();
      switchTab('settings');
    });

    // Notifications
    var notifBtn = document.getElementById('btnNotif');
    var notifDrop = document.getElementById('notifDropdown');
    notifBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var visible = notifDrop.style.display !== 'none';
      closeAllPopups();
      if (!visible) {
        renderNotifs();
        notifDrop.style.display = '';
        Auth.markNotifsRead();
        updateNotifBadge();
      }
    });

    // Theme toggle
    document.getElementById('btnTheme').addEventListener('click', toggleTheme);
    // Restore theme
    if (localStorage.getItem('__yush_theme__') === 'light') {
      document.body.classList.add('light');
      updateThemeIcons(true);
    }

    // Close popups on outside click
    document.addEventListener('click', function () {
      closeAllPopups();
    });
    popover.addEventListener('click', function (e) { e.stopPropagation(); });
    notifDrop.addEventListener('click', function (e) { e.stopPropagation(); });
  }

  function closeAllPopups() {
    document.getElementById('profilePopover').style.display = 'none';
    document.getElementById('notifDropdown').style.display = 'none';
  }

  function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.tab-panel').forEach(function (p) {
      p.classList.toggle('active', p.id === 'tab-' + tab);
    });
    document.querySelectorAll('.drawer-item').forEach(function (item) {
      item.classList.toggle('active', item.getAttribute('data-tab') === tab);
    });
    var titles = {
      dashboard: 'Dashboard',
      updater: 'Offset Updater',
      finder: 'Offset Finder',
      converter: 'Bypass Formatting',
      developer: 'Developer',
      terms: 'Terms of Service',
      privacy: 'Privacy Policy',
      settings: 'Settings',
      admin: 'Admin Panel'
    };
    document.getElementById('topbarTitle').textContent = titles[tab] || tab;
    if (tab === 'admin') renderAdminPanel();
    if (tab === 'dashboard') refreshDashboard();
    if (tab === 'updater') { loadOldVersions(); loadNewVersions(); }
    if (tab === 'finder') { try { updateFinderSummary(finderResults); setFindStatus(finderParsed.length ? 'ready' : 'ready'); } catch (e) {} }
  }

  function toggleTheme() {
    var isLight = document.body.classList.toggle('light');
    localStorage.setItem('__yush_theme__', isLight ? 'light' : 'dark');
    updateThemeIcons(isLight);
    // Update turnstile theme if present
    var tw = document.querySelector('.cf-turnstile');
    if (tw) tw.setAttribute('data-theme', isLight ? 'light' : 'dark');
  }
  function updateThemeIcons(isLight) {
    document.querySelector('.theme-icon-dark').style.display = isLight ? 'none' : '';
    document.querySelector('.theme-icon-light').style.display = isLight ? '' : 'none';
  }

  function updateNotifBadge() {
    var notifs = Auth.getNotifications();
    var unread = notifs.filter(function (n) { return !n.read; }).length;
    var badge = document.getElementById('notifBadge');
    if (unread > 0) {
      badge.textContent = unread > 9 ? '9+' : unread;
      badge.style.display = '';
    } else {
      badge.style.display = 'none';
    }
  }

  function renderNotifs() {
    var list = document.getElementById('notifList');
    var notifs = Auth.getNotifications();
    var pill = document.getElementById('notifCountPill');
    if (pill) pill.textContent = String(notifs.filter(function(n){return !n.read;}).length);
    if (!notifs.length) {
      list.innerHTML = '<div class="notif-empty"><svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/><line x1="1" y1="1" x2="23" y2="23"/></svg><div>No Notification</div></div>';
      return;
    }
    list.innerHTML = notifs.slice(0, 20).map(function (n) {
      var t = formatPHTime(n.time);
      return '<div class="notif-item">' + esc(n.message) + '<br><span style="font-size:10px;color:var(--text3)">' + t + '</span></div>';
    }).join('');
  }

  /* ════════════════════════════════════════
     OFFSET UPDATER
     ════════════════════════════════════════ */

  function fmtSz(b) {
    if (!b && b !== 0) return '';
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1048576).toFixed(2) + ' MB';
  }

  // SVG file-type icons for dump list (cs / lua / generic)
  function dumpFileIcon(filename) {
    var ext = (String(filename || '').split('.').pop() || 'cs').toLowerCase();
    if (ext === 'lua') {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="#86efac" stroke-width="1.8"><path d="M12 2a10 10 0 100 20 10 10 0 000-20z"/><path d="M8 12h8M12 8v8"/></svg>';
    }
    // default / .cs
    return '<svg viewBox="0 0 24 24" fill="none" stroke="#c4b5fd" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M10 13h4M10 17h4"/></svg>';
  }

  function renderDumpItems(list, kind) {
    if (!list || !list.length) {
      return '<div class="admin-empty">No ' + kind + ' dumps yet</div>';
    }
    list = list.slice().sort(function (a, b) { return versionSort(b.version, a.version); });
    return list.map(function (d) {
      if (!d || !d.version) return '';
      var sizeTxt = (d.size && d.size > 1) ? fmtSz(d.size) : '—';
      var when = d.uploadedAt ? fmtWhen(d.uploadedAt) : '';
      var file = d.file || (d.version + '.cs');
      return '<div class="dump-list-item kind-' + kind + '" data-kind="' + kind + '" data-version="' + esc(d.version) + '" data-label="' + esc(d.version) + '">' +
        '<div class="dump-ico">' + dumpFileIcon(file) + '</div>' +
        '<div class="dump-meta">' +
          '<div class="dump-ver">' + esc(d.version) + '</div>' +
          '<div class="dump-sub">' + esc(d.region || 'GARENA') + (when ? ' · ' + esc(when) : '') + '</div>' +
        '</div>' +
        '<div class="dump-size">' + sizeTxt + '</div>' +
        '<button type="button" class="dump-del-btn" title="Delete permanently" aria-label="Delete">' +
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>' +
        '</button>' +
      '</div>';
    }).join('');
  }

  function renderAdminDumpList() { /* removed: local-file updater */ }

  function confirmDeleteDump(kind, version, label) {
    var existing = document.getElementById('yushConfirmModal');
    if (existing) existing.remove();
    var overlay = document.createElement('div');
    overlay.id = 'yushConfirmModal';
    overlay.className = 'yush-modal-overlay';
    overlay.innerHTML =
      '<div class="yush-modal-card">' +
        '<div class="yush-modal-icon warn">' +
          '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' +
        '</div>' +
        '<h3 class="yush-modal-title">Delete dump?</h3>' +
        '<p class="yush-modal-text">Are you sure you want to delete <b>' + esc(label) + '</b> (' + esc(kind) + ')? This permanently removes the cached file from the server.</p>' +
        '<div class="yush-modal-actions">' +
          '<button type="button" class="yush-modal-btn cancel" id="yushConfirmCancel">Cancel</button>' +
          '<button type="button" class="yush-modal-btn continue" id="yushConfirmOk">Continue</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);
    document.getElementById('yushConfirmCancel').onclick = function () { overlay.remove(); };
    overlay.onclick = function (e) { if (e.target === overlay) overlay.remove(); };
    document.getElementById('yushConfirmOk').onclick = function () {
      var btn = document.getElementById('yushConfirmOk');
      btn.disabled = true;
      btn.textContent = 'Deleting…';
      fetch(yushApi('api/delete-dump.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: kind, version: version })
      }).then(function (r) { return r.json(); }).then(function (data) {
        overlay.remove();
        if (!data || !data.ok) {
          alert((data && data.error) || 'Could not delete dump.');
          return;
        }
        try { loadOldVersions(); } catch (e) {}
        try { loadNewVersions(); } catch (e) {}
        try { renderAdminDumpList(); } catch (e) {}
        try { refreshDashboard(); } catch (e) {}
      }).catch(function () {
        overlay.remove();
        alert('Network error while deleting.');
      });
    };
  }

  // Fallback seed lists only used if the server has never listed anything for
  // that kind yet (first run / offline). Once real dumps exist server-side,
  // whatever was actually uploaded always wins — this is no longer a hard
  // ceiling on which versions can appear.
  // OLD dump picker: 1.6.50 through 1.6.56 (7 versions).
  var OLD_SEED_VERSIONS = ["1.6.51","1.6.52","1.6.53","1.6.54","1.6.55","1.6.56"];
  // NEW dump picker: only 1.6.56 and 1.6.57.
  var NEW_SEED_VERSIONS = ["1.6.57"];

  function versionSort(a, b) {
    var pa = String(a).split(/[._-]/).map(Number);
    var pb = String(b).split(/[._-]/).map(Number);
    for (var i = 0; i < Math.max(pa.length, pb.length); i++) {
      var na = pa[i] || 0, nb = pb[i] || 0;
      if (na !== nb) return na - nb;
    }
    return String(a).localeCompare(String(b));
  }

  function loadOldVersions() { /* removed: local-file updater */ }

  function loadNewVersions() { /* removed: local-file updater */ }

  function bindUpdater() {
    function fmtSz(b) {
      if (b < 1024) return b + ' B';
      if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
      return (b / 1048576).toFixed(2) + ' MB';
    }
    function fileType(name) {
      var dot = name.lastIndexOf('.');
      var ext = dot > -1 ? name.slice(dot + 1).toLowerCase() : '';
      var map = { cs:'C# Source', cpp:'C++ Source', h:'C++ Header', hpp:'C++ Header', lua:'Lua Script', txt:'Text File' };
      return map[ext] || 'Source File';
    }
    function onFile(id, inp) {
      var f = inp.files && inp.files[0];
      if (!f) return;
      S[id] = f;
      if (id === 'tgt') S.sources = [f];
      var fd = document.getElementById('fd-' + id);
      var txt = document.getElementById('fd-' + id + '-txt');
      if (txt) txt.textContent = f.name;
      if (fd) fd.classList.add('has-file');
      var fp = document.getElementById('fp-' + id);
      var fpn = document.getElementById('fpn-' + id);
      var fpm = document.getElementById('fpm-' + id);
      if (fpn) fpn.textContent = f.name;
      if (fpm) fpm.textContent = fmtSz(f.size) + ' · ' + fileType(f.name);
      if (fp) { fp.classList.add('show'); fp.classList.add('has-file'); }
      checkReady();
    }
    window.yushPick = function (id) {
      var el = document.getElementById('f-' + id);
      if (el) el.click();
    };
    ['old', 'new', 'tgt'].forEach(function (id) {
      var el = document.getElementById('f-' + id);
      if (el) el.addEventListener('change', function () { onFile(id, el); });
    });
    var exec = document.getElementById('btnExec');
    if (exec) exec.addEventListener('click', runPipeline);
    var dl = document.getElementById('btnDownload');
    if (dl) dl.addEventListener('click', doDownload);
    var go = document.getElementById('btnDashGoUpdater');
    if (go) go.addEventListener('click', function () { switchTab('updater'); });
    checkReady();
  }

  function renderSourceList() {
    var list = document.getElementById('sourceFileList');
    var info = document.getElementById('runFileName');
    if (!S.sources || !S.sources.length) {
      if (list) list.innerHTML = '';
      if (info) info.textContent = 'No file selected';
      return;
    }
    if (list) {
      list.innerHTML = S.sources.map(function (f) {
        var ext = (f.name.split('.').pop() || '').toLowerCase();
        var colorCls = 'src-ext-default';
        if (ext === 'cpp' || ext === 'cc' || ext === 'cxx') colorCls = 'src-ext-cpp';
        else if (ext === 'h' || ext === 'hpp' || ext === 'hh') colorCls = 'src-ext-h';
        else if (ext === 'c') colorCls = 'src-ext-c';
        else if (ext === 'cs') colorCls = 'src-ext-cs';
        else if (ext === 'lua') colorCls = 'src-ext-lua';
        return '<div class="source-file-item ' + colorCls + '"><span class="src-ready">' + fmtSz(f.size) + ' is ready</span></div>';
      }).join('');
    }
    if (info) {
      var f = S.sources[0];
      info.textContent = f.name + (S.sources.length > 1 ? ' (+' + (S.sources.length - 1) + ' more)' : '');
    }
  }

  function checkReady() {
    var ready = !!(S.old && S['new'] && S.tgt);
    var btn = document.getElementById('btnExec');
    if (btn) btn.disabled = !ready;
  }

  function setPill(state) {
    document.querySelectorAll('.pill').forEach(function (p) {
      p.classList.toggle('active', p.getAttribute('data-pill') === state);
    });
  }

  function fetchDumpBuffer(kind, version) {
    var url = yushApi('api/get-dump.php?kind=' + encodeURIComponent(kind) + '&version=' + encodeURIComponent(version));
    /* 'default' = use browser cache if the server says it's still fresh (max-age=300).
       On first run the server downloads + caches to disk; next run it reads disk instantly.
       On second browser run the browser cache kicks in — effectively 0ms. */
    return fetch(url, { credentials: 'same-origin', cache: 'default' }).then(function (r) {
      var ct = (r.headers.get('content-type') || '').toLowerCase();
      if (!r.ok) {
        return r.text().then(function (txt) {
          var msg = 'Dump ' + kind + ' ' + version + ' not available.';
          try {
            var j = JSON.parse(txt);
            if (j && j.error) msg = j.error;
          } catch (e) {
            if (txt && txt.length < 200) msg = txt;
          }
          if (r.status === 404) msg = 'Dump ' + kind + ' Garena ' + version + ' not found. Admin must Save Dump Link for this version first.';
          throw new Error(msg);
        });
      }
      if (ct.indexOf('application/json') !== -1) {
        return r.json().then(function (j) {
          throw new Error((j && j.error) || ('Dump ' + kind + ' ' + version + ' error'));
        });
      }
      return r.arrayBuffer().then(function (buf) {
        if (!buf || buf.byteLength < 256) {
          throw new Error('Dump ' + kind + ' ' + version + ' is empty or incomplete. Check the share link.');
        }
        return buf;
      });
    }).catch(function (err) {
      if (err && err.message && err.message !== 'Failed to fetch') throw err;
      throw new Error('Failed to load dump ' + kind + ' Garena ' + version + '. Network error or server timeout — try again, or re-save the dump link in Admin Panel.');
    });
  }

  function setProgress(pct) {
    var fill = document.getElementById('progressFill');
    if (fill) fill.style.width = pct + '%';
    /* show/hide is now fully controlled by progressWrap.classList — don't auto-hide here */
  }

  function readAB(f) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function (e) { res(e.target.result); };
      r.onerror = function () { rej(r.error); };
      r.readAsArrayBuffer(f);
    });
  }

  function updateStats() {
    var el;
    el = document.getElementById('sok'); if (el) el.textContent = R.updated.length;
    el = document.getElementById('sfail'); if (el) el.textContent = R.failed.length;
    el = document.getElementById('sign'); if (el) el.textContent = R.ignored.length;
    el = document.getElementById('ssame'); if (el) el.textContent = R.same.length;
  }

  function recordJob(ok) {
    try {
      var jobs = JSON.parse(localStorage.getItem(JOBS_KEY) || '[]');
      jobs.push({ t: Date.now(), ok: !!ok, updated: R.updated.length, total: R.all.length });
      if (jobs.length > 200) jobs = jobs.slice(-200);
      localStorage.setItem(JOBS_KEY, JSON.stringify(jobs));
    } catch (e) {}
  }

  function refreshDashboard() {
    var user = Auth.getCurrentUser();
    var welcome = document.getElementById('dashWelcome');
    if (welcome && user) welcome.textContent = 'Welcome back, ' + (user.name || Auth.nameFromEmail(user.email));
    var users = Auth.getUsers();
    var accounts = Object.keys(users).length + 1; // + owner
    var jobs = [];
    try { jobs = JSON.parse(localStorage.getItem(JOBS_KEY) || '[]'); } catch (e) {}
    var completed = jobs.filter(function (j) { return j.ok; }).length;
    var review = jobs.filter(function (j) { return !j.ok; }).length;
    var totalOff = jobs.reduce(function (s, j) { return s + (j.total || 0); }, 0);
    var updatedOff = jobs.reduce(function (s, j) { return s + (j.updated || 0); }, 0);
    function set(id, v) { var e = document.getElementById(id); if (e) e.textContent = v; }
    set('dashAccounts', accounts);
    set('dashCompleted', completed);
    set('dashReview', review);
    set('dashJobsOk', completed);
    set('dashJobsRev', review);
    set('dashJobsTotal', jobs.length);
    set('dashTracked', totalOff || updatedOff || 0);
    set('dashRva', Math.round((totalOff || 0) * 0.55));
    set('dashField', Math.round((totalOff || 0) * 0.45));
    var success = jobs.length ? Math.round((completed / jobs.length) * 100) : 0;
    set('dashSuccess', success + '%');
    set('dashReadyPct', success + '%');
    set('dashActiveUsers', accounts);
    set('dashPulseCount', completed + ' completed updates');
    var fill = document.querySelector('.dash-bar-fill');
    if (fill) fill.style.width = success + '%';
    // Banned: users (status/role banned) + blocked IPs + banned emails
    var bannedUsers = 0;
    try {
      Object.keys(users).forEach(function (email) {
        var u = users[email] || {};
        var st = String(u.status || u.role || '').toLowerCase();
        if (st === 'banned' || st === 'blocked' || u.banned === true) bannedUsers++;
      });
    } catch (e) {}
    fetch(yushApi('api/security-events.php'))
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var ips = (data && data.blockedIps) ? data.blockedIps.length : 0;
        var total = bannedUsers + ips;
        set('dashBanned', total);
        set('dashBanned2', total);
      })
      .catch(function () {
        set('dashBanned', bannedUsers);
        set('dashBanned2', bannedUsers);
      });
  }

  function makeCard(r) {
    var bt = r.status === 'updated' ? 'UPDATED' : r.status === 'failed' ? 'FAILED' : r.status === 'ignored' ? 'IGNORED' : 'LATEST';
    var copyAttr = SETTINGS.copyEnabled ? ' onclick="window._copyHex(this)"' : '';
    var copyCls = SETTINGS.copyEnabled ? ' copy-hex' : '';
    var className = r.cls || 'Unknown';
    var methodName = r.name || 'Unknown';
    var fqn = className + '::' + methodName;
    var typeBadge = (r.entryType === 'field' || /field/i.test(r.entryType || '')) ? 'FIELD' : 'METHOD';
    var oh = '';
    if (r.status === 'updated') {
      oh = '<div class="yush-r-row">' +
        '<div class="yush-r-side old"><span class="yush-r-lbl">OLD</span><span class="yush-r-hex old' + copyCls + '" data-hex="' + esc(r.oldVal) + '"' + copyAttr + '>' + esc(r.oldVal) + '</span></div>' +
        '<div class="yush-r-arrow">→</div>' +
        '<div class="yush-r-side new"><span class="yush-r-lbl">NEW</span><span class="yush-r-hex new' + copyCls + '" data-hex="' + esc(r.newVal) + '"' + copyAttr + '>' + esc(r.newVal) + '</span></div>' +
        '</div>';
    } else {
      oh = '<div class="yush-r-row single"><div class="yush-r-side"><span class="yush-r-lbl">OFFSET</span><span class="yush-r-hex' + copyCls + '" data-hex="' + esc(r.oldVal) + '"' + copyAttr + '>' + esc(r.oldVal) + '</span></div></div>';
    }
    var reasonHtml = (r.status === 'failed' && r.reason)
      ? '<div class="yush-r-reason">' + esc(r.reason) + '</div>' : '';
    return '<div class="yush-r-card c-' + r.status + '">' +
      '<div class="yush-r-top">' +
        '<span class="yush-r-badge b-' + r.status + '">' + bt + '</span>' +
        '<span class="yush-r-type">' + typeBadge + '</span>' +
      '</div>' +
      '<div class="yush-r-fqn">' + esc(fqn) + '</div>' +
      oh +
      reasonHtml +
      '</div>';
  }

  window._copyHex = function (el) {
    var val = el.getAttribute('data-hex') || el.textContent;
    var mark = function () {
      el.classList.add('copied');
      setTimeout(function () { el.classList.remove('copied'); }, 900);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(val).then(mark, function () { fallbackCopy(val, mark); });
    } else {
      fallbackCopy(val, mark);
    }
  };

  function fallbackCopy(text, cb) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    if (cb) cb();
  }

  function renderResults() {
    ['updated', 'failed', 'ignored', 'same'].forEach(function (k) {
      var sec = document.getElementById('sec-' + k);
      var cont = document.getElementById('cards-' + k);
      var ctr = document.getElementById('sc-' + k);
      if (!sec) return;
      if (k !== 'updated' || !R[k].length) { sec.style.display = 'none'; return; }
      if (ctr) ctr.textContent = R[k].length + ' offset' + (R[k].length !== 1 ? 's' : '');
      var html = '';
      R[k].forEach(function (r) { html += makeCard(r); });
      cont.innerHTML = html;
      sec.style.display = 'block';
    });
    document.getElementById('resultsWrap').style.display = '';
  }


  /* Animated progress: smoothly ticks toward a target at ~0.1%/100ms */
  var _progTarget = 0;
  var _progCurrent = 0;
  var _progTimer = null;
  function startProgressAnimation() {
    if (_progTimer) return;
    _progTimer = setInterval(function () {
      if (_progCurrent < _progTarget) {
        /* Close gap by 8% each tick — feels snappy, never outpaces real work */
        var gap = _progTarget - _progCurrent;
        _progCurrent = Math.min(_progCurrent + Math.max(gap * 0.08, 0.4), _progTarget);
        setProgress(_progCurrent);
      }
    }, 60);
  }
  function stopProgressAnimation() {
    if (_progTimer) { clearInterval(_progTimer); _progTimer = null; }
  }
  function setProgressTarget(pct) {
    _progTarget = pct;
    if (_progCurrent > pct) { _progCurrent = pct; setProgress(pct); }
  }
  function snapProgress(pct) {
    _progTarget = pct; _progCurrent = pct; setProgress(pct);
  }

  async function runPipeline() {
    if (!S.old || !S['new'] || !S.tgt) return;
    var now = Date.now();
    if (now - _lastRunAt < RUN_COOLDOWN_MS) return;
    _lastRunAt = now;

    document.getElementById('btnExec').disabled = true;
    document.getElementById('btnLabel').textContent = 'Processing…';
    var pw = document.getElementById('progressWrap');
    if (pw) pw.classList.add('show');
    var dlWrap = document.getElementById('dlWrap');
    if (dlWrap) dlWrap.style.display = 'none';
    var rw = document.getElementById('resultsWrap');
    if (rw) rw.style.display = 'none';
    setPill('processing');
    if (typeof setProgress === 'function') setProgress(5);

    var oldBuf, newBuf, tgtBuf;
    try {
      oldBuf = await readAB(S.old);
      newBuf = await readAB(S['new']);
      tgtBuf = await readAB(S.tgt);
      if (typeof setProgress === 'function') setProgress(20);
    } catch (err) {
      setPill('error');
      alert('Failed to read files: ' + (err.message || err));
      resetExecBtn();
      return;
    }

    if (_worker) { _worker.terminate(); _worker = null; }
    _worker = new Worker('js/updater.js?v=local');

    _worker.onmessage = function (e) {
      var d = e.data;
      if (d.type === 'progress') {
        if (typeof setProgress === 'function') setProgress(20 + (d.pct || 0) * 0.75);
        return;
      }
      if (d.type === 'result' || d.type === 'done') {
        _worker.terminate(); _worker = null;
        var raw = d.results || {};
        R = {
          updated: raw.updated || [],
          failed: raw.failed || [],
          ignored: raw.ignored || [],
          same: raw.same || [],
          all: []
        };
        R.all = R.updated.concat(R.failed, R.ignored, R.same);
        _updatedText = d.updatedText || null;
        if (typeof setProgress === 'function') setProgress(100);
        updateStats();
        setPill('completed');
        renderResults();
        recordJob(true);
        try { refreshDashboard(); } catch (e2) {}
        if (R.updated.length) {
          if (dlWrap) dlWrap.style.display = '';
          if (SETTINGS.autoDownload) doDownload();
        }
        resetExecBtn();
        return;
      }
      if (d.type === 'error') {
        _worker.terminate(); _worker = null;
        setPill('error');
        recordJob(false);
        alert('Error: ' + (d.message || 'Unknown'));
        resetExecBtn();
      }
    };
    _worker.onerror = function (err) {
      if (_worker) { _worker.terminate(); _worker = null; }
      setPill('error');
      recordJob(false);
      alert('Worker error: ' + (err.message || 'Unknown'));
      resetExecBtn();
    };
    _worker.postMessage({ oldBuf: oldBuf, newBuf: newBuf, tgtBuf: tgtBuf }, [oldBuf, newBuf, tgtBuf]);
  }

  function resetExecBtn() {
    document.getElementById('btnExec').disabled = false;
    document.getElementById('btnLabel').textContent = 'Start Update';
    /* Hide progress bar after a short delay so 100% is visible */
    setTimeout(function() {
      var pw = document.getElementById('progressWrap');
      if (pw) pw.classList.remove('show');
      /* reset bar back to 0 silently for next run */
      setTimeout(function() { snapProgress(0); }, 300);
    }, 600);
  }

  function _crc32(bytes) {
    var table = window.__crcTable;
    if (!table) {
      table = new Uint32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        table[n] = c;
      }
      window.__crcTable = table;
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) crc = table[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function _u16(v) { return new Uint8Array([v & 255, (v >>> 8) & 255]); }
  function _u32(v) { return new Uint8Array([v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]); }
  function _joinBytes(parts) {
    var total = 0;
    parts.forEach(function (p) { total += p.length; });
    var out = new Uint8Array(total), off = 0;
    parts.forEach(function (p) { out.set(p, off); off += p.length; });
    return out;
  }

  function makeZip(entries) {
    var enc = new TextEncoder(), local = [], central = [], offset = 0;
    entries.forEach(function (entry) {
      var name = enc.encode(entry.name);
      var data = entry.data;
      var crc = _crc32(data);
      var localHeader = _joinBytes([
        _u32(0x04034b50), _u16(20), _u16(0), _u16(0), _u16(0), _u16(0),
        _u32(crc), _u32(data.length), _u32(data.length), _u16(name.length), _u16(0), name
      ]);
      local.push(localHeader, data);
      var centralHeader = _joinBytes([
        _u32(0x02014b50), _u16(20), _u16(20), _u16(0), _u16(0), _u16(0), _u16(0),
        _u32(crc), _u32(data.length), _u32(data.length), _u16(name.length), _u16(0),
        _u16(0), _u16(0), _u16(0), _u32(0), _u32(offset), name
      ]);
      central.push(centralHeader);
      offset += localHeader.length + data.length;
    });
    var centralSize = 0;
    central.forEach(function (c) { centralSize += c.length; });
    var end = _joinBytes([
      _u32(0x06054b50), _u16(0), _u16(0), _u16(entries.length), _u16(entries.length),
      _u32(centralSize), _u32(offset), _u16(0)
    ]);
    return _joinBytes(local.concat(central).concat([end]));
  }

  function doDownload() {
    if (!_updatedText || !S.tgt) return;
    var targetName = S.tgt.name || 'updated_file.txt';
    var blob = new Blob([_updatedText], { type: 'text/plain;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = targetName;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 15000);
  }

  function buildUpdateLogs() {
    var lines = [];
    lines.push('YUSH TOOLS — Update Log');
    lines.push('Target: ' + (S.tgt ? S.tgt.name : 'unknown'));
    lines.push('Total offsets: ' + R.all.length);
    lines.push('Updated: ' + R.updated.length);
    lines.push('Failed: ' + R.failed.length);
    lines.push('Ignored: ' + R.ignored.length);
    lines.push('Same: ' + R.same.length);
    lines.push('');
    R.all.forEach(function (r) {
      lines.push('[' + r.status.toUpperCase() + '] ' + (r.cls || '') + ' :: ' + (r.name || '') + '  ' + (r.oldVal || '') + (r.newVal ? ' → ' + r.newVal : ''));
    });
    return lines.join('\n');
  }

  /* ════════════════════════════════════════
     OFFSET FINDER
     ════════════════════════════════════════ */
  var finderParsed = [];
  var finderResults = [];
  var finderFilter = 'all';

  var MODS = new Set(['public', 'private', 'protected', 'internal', 'static', 'virtual', 'override', 'abstract', 'sealed', 'new', 'extern', 'unsafe', 'readonly']);

  function extractOffset(line) {
    var mOff = line.match(/Offset:\s*(0x[0-9A-Fa-f]+)/i);
    if (mOff) return mOff[1];
    var mRva = line.match(/RVA:\s*(0x[0-9A-Fa-f]+)/i);
    if (mRva) return mRva[1];
    var mAny = line.match(/0x[0-9A-Fa-f]{5,}/);
    return mAny ? mAny[0] : null;
  }

  function extractRva(line) {
    var m = line.match(/RVA:\s*(0x[0-9A-Fa-f]+)/i);
    return m ? m[1] : null;
  }

  function extractTypeDefIndex(line) {
    var m = line.match(/TypeDefIndex:\s*(\d+)/i);
    return m ? m[1] : null;
  }

  function extractMethodName(sig) {
    var m = sig.match(/([A-Za-z_][\w]*)\s*\(/);
    return m ? m[1] : '';
  }

  function extractFieldName(sig) {
    var cleaned = sig.replace(/\/\/.*$/, '').trim();
    var m = cleaned.match(/([A-Za-z_][\w]*)\s*[;=]/);
    return m ? m[1] : '';
  }

  function newSS() { return { stack: [], depth: 0, namespace: '', pending: null, typeDefIndex: null }; }

  function updScope(s, line) {
    var ns = line.match(/^\s*\/\/\s*[Nn]amespace:\s*(.+?)\s*$/);
    if (ns) { s.namespace = ns[1].trim(); return; }
    var tdi = extractTypeDefIndex(line);
    if (tdi) { s.typeDefIndex = tdi; }
    if (!s.pending) {
      var dm = line.match(/(?:^|\s|[^\w])(?:class|struct|interface|enum)\s+([\w<>.]+)/);
      if (dm) s.pending = dm[1];
    }
    if (line.indexOf('{') === -1 && line.indexOf('}') === -1) return;
    for (var i = 0; i < line.length; i++) {
      var ch = line[i];
      if (ch === '{') {
        s.depth++;
        if (s.pending) {
          s.stack.push({ name: s.pending, baseDepth: s.depth, typeDefIndex: s.typeDefIndex || null });
          s.pending = null;
        }
      } else if (ch === '}') {
        var top = s.stack[s.stack.length - 1];
        if (top && s.depth === top.baseDepth) s.stack.pop();
        s.depth = Math.max(0, s.depth - 1);
      }
    }
  }

  function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    var k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
    var i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  function fLog(msg, color) {
    // legacy no-op (console removed)
  }

  function setFindStatus(st) {
    var row = document.getElementById('findStatusRow');
    if (!row) return;
    row.querySelectorAll('.pill').forEach(function (p) {
      p.classList.toggle('active', p.getAttribute('data-st') === st);
    });
  }

  function updateFinderSummary(base) {
    var card = document.getElementById('finderSummaryCard');
    if (card) card.style.display = '';
    var methods = (base || []).filter(function (r) { return r.type === 'method'; }).length;
    var fields = (base || []).filter(function (r) { return r.type === 'field'; }).length;
    var el;
    el = document.getElementById('finderStatFound'); if (el) el.textContent = (base || []).length;
    el = document.getElementById('finderStatMethods'); if (el) el.textContent = methods;
    el = document.getElementById('finderStatFields'); if (el) el.textContent = fields;
    el = document.getElementById('finderStatIndexed'); if (el) el.textContent = finderParsed.length;
    el = document.getElementById('finderSummaryTotal'); if (el) el.textContent = finderParsed.length;
    el = null;
    if (el) el.textContent = (document.getElementById('finderSearch') || {}).value || '—';
  }

  function renderFinderCards(base) {
    var wrap = document.getElementById('finderResultsWrap');
    var empty = document.getElementById('finderEmptyHint');
    var cont = document.getElementById('finderResultCards');
    var ctr = document.getElementById('finderResultCount');
    if (!base || !base.length) {
      if (wrap) wrap.style.display = 'none';
      if (empty) {
        empty.style.display = '';
        if (!finderParsed.length) empty.textContent = 'Load a dump.cs and search to see results here.';
        else empty.textContent = 'No results for this query.';
      }
      if (ctr) ctr.textContent = '';
      if (cont) cont.innerHTML = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    if (wrap) wrap.style.display = '';
    if (ctr) ctr.textContent = base.length + ' found';
    var slice = base.slice(0, 100);
    var html = '';
    slice.forEach(function (r) {
      var off = esc(r.offset || r.rva || '—');
      var ns = r.namespace ? esc(r.namespace) : 'Not Found';
      var cls = r.className ? esc(r.className) : 'Not Found';
      var nsCls = r.namespace ? '' : ' miss';
      var clsCls = r.className ? '' : ' miss';
      var tdi = r.typeDefIndex ? esc(String(r.typeDefIndex)) : '—';
      var sig = esc(r.signature || r.name || '');
      var line = esc(String(r.lineNumber || '—'));
      html += '<div class="finder-card">' +
        '<div class="finder-row ns' + nsCls + '">' +
          '<span class="finder-ico">📁</span>' +
          '<span class="finder-k">Namespace:</span> <span class="finder-v">' + ns + '</span>' +
        '</div>' +
        '<div class="finder-row cls' + clsCls + '">' +
          '<span class="finder-ico">📦</span>' +
          '<span class="finder-k">Class:</span> <span class="finder-v">' + cls + '</span>' +
        '</div>' +
        '<div class="finder-tdi">TypeDefIndex: ' + tdi + '</div>' +
        '<div class="finder-sig">' + sig + '</div>' +
        '<div class="finder-line">Line: ' + line + '</div>' +
        '<div class="finder-bottom">' +
          '<div class="finder-off-line">' +
            '<span class="finder-ico">📍</span>' +
            '<span class="finder-k">Offset:</span> <span class="finder-off">' + off + '</span>' +
          '</div>' +
          '<button type="button" class="btn-copy-offset" data-hex="' + off + '">' +
            '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>' +
            'Copy' +
          '</button>' +
        '</div>' +
      '</div>';
    });
    if (base.length > 100) {
      html += '<div class="finder-empty">Showing first 100 of ' + base.length + '. Refine your search.</div>';
    }
    if (cont) cont.innerHTML = html;
    if (cont) {
      cont.querySelectorAll('.btn-copy-offset').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var hex = btn.getAttribute('data-hex') || '';
          if (!hex || hex === '—') return;
          navigator.clipboard.writeText(hex).then(function () {
            btn.classList.add('copied');
            var prev = btn.innerHTML;
            btn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Copied';
            setTimeout(function () {
              btn.classList.remove('copied');
              btn.innerHTML = prev.indexOf('Copy') !== -1 && prev.indexOf('Copied') === -1
                ? prev
                : '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg> Copy';
            }, 1400);
          }).catch(function () {});
        });
      });
    }
  }

  function loadFinderDumpFromFile(f) {
    if (!f) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      var text = e.target.result || '';
      var pathEl = document.getElementById('finderPathDisplay');
      if (pathEl) pathEl.textContent = f.name + ' · ' + formatFileSize(f.size);
      var state = newSS();
      var lines = text.split(/\r?\n/);
      var pendingMeta = null;
      var pendingFieldOff = null;
      finderParsed = [];
      for (var i = 0; i < lines.length; i++) {
        var raw = lines[i];
        updScope(state, raw);
        var tr = raw.trim();
        if (!tr) continue;

        var fo = tr.match(/\[FieldOffset\(\s*"?(0x[0-9A-Fa-f]+)"?\s*\)\]/i);
        if (fo) {
          pendingFieldOff = fo[1];
          pendingMeta = null;
          continue;
        }

        if (tr.indexOf('//') === 0) {
          var off = extractOffset(tr);
          var rva = extractRva(tr);
          if (off || rva) {
            pendingMeta = {
              offset: off || rva,
              rva: rva || off,
              comment: tr,
              line: i + 1
            };
            pendingFieldOff = null;
          }
          continue;
        }

        var cls = state.stack.length ? state.stack[state.stack.length - 1].name : null;
        var tdi = null;
        if (state.stack.length && state.stack[state.stack.length - 1].typeDefIndex) {
          tdi = state.stack[state.stack.length - 1].typeDefIndex;
        } else {
          tdi = state.typeDefIndex;
        }

        if (pendingMeta) {
          var isM = tr.indexOf('(') !== -1 && tr.indexOf(')') !== -1;
          var name = isM ? extractMethodName(tr) : extractFieldName(tr);
          finderParsed.push({
            namespace: state.namespace || null,
            className: cls,
            signature: tr.replace(/\s*\{\s*\}\s*$/, '').trim(),
            name: name,
            lineNumber: i + 1,
            offset: pendingMeta.offset,
            rva: pendingMeta.rva,
            typeDefIndex: tdi || null,
            type: isM ? 'method' : 'field'
          });
          pendingMeta = null;
          continue;
        }

        if (pendingFieldOff) {
          var fname = extractFieldName(tr) || (tr.match(/(\w+)\s*[;=\[]/) || [])[1];
          if (fname) {
            finderParsed.push({
              namespace: state.namespace || null,
              className: cls,
              signature: tr.replace(/\s*\{\s*\}\s*$/, '').trim(),
              name: fname,
              lineNumber: i + 1,
              offset: pendingFieldOff,
              rva: pendingFieldOff,
              typeDefIndex: tdi || null,
              type: 'field'
            });
            pendingFieldOff = null;
          }
          continue;
        }

        // Inline: Type name; // 0x..
        var inline = tr.match(/^[^\(]+\s+(\w+)\s*;\s*\/\/\s*(0x[0-9A-Fa-f]+)/i);
        if (inline) {
          finderParsed.push({
            namespace: state.namespace || null,
            className: cls,
            signature: tr,
            name: inline[1],
            lineNumber: i + 1,
            offset: inline[2],
            rva: inline[2],
            typeDefIndex: tdi || null,
            type: 'field'
          });
        }
      }
      updateFinderSummary([]);
      setFindStatus('ready');
      var empty = document.getElementById('finderEmptyHint');
      if (empty) {
        empty.style.display = '';
        empty.textContent = 'Indexed ' + finderParsed.length + ' entries. Enter a method, field, class, or 0x offset.';
      }
      var wrap = document.getElementById('finderResultsWrap');
      if (wrap) wrap.style.display = 'none';
      var inp = document.getElementById('finderInput');
      if (inp) inp.value = '';
    };
    reader.readAsText(f, 'UTF-8');
  }

  function normalizeQuery(q) {
    q = String(q || '').trim();
    q = q.replace(/\{[\s\S]*\}$/, '').trim();
    // Prefer identifier right before '(' (method name)
    var m = q.match(/([A-Za-z_][\w]*)\s*\(/);
    if (m) {
      return {
        raw: q,
        key: m[1],
        full: q.toLowerCase().replace(/\s+/g, ' ').trim()
      };
    }
    // Bare identifier / offset / typedefindex
    return {
      raw: q,
      key: q.replace(/\s+/g, ''),
      full: q.toLowerCase().replace(/\s+/g, ' ').trim()
    };
  }

  function escapeRe(s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function doFind() {
    var qEl = document.getElementById('finderSearch');
    var q = qEl ? qEl.value.trim() : '';
    if (!finderParsed.length) {
      setFindStatus('empty');
      updateFinderSummary([]);
      var empty = document.getElementById('finderEmptyHint');
      if (empty) { empty.style.display = ''; empty.textContent = 'Load a dump.cs file first.'; }
      renderFinderCards([]);
      return;
    }
    if (!q) {
      setFindStatus('empty');
      updateFinderSummary([]);
      var empty2 = document.getElementById('finderEmptyHint');
      if (empty2) { empty2.style.display = ''; empty2.textContent = 'Enter a method/field name or full signature.'; }
      renderFinderCards([]);
      return;
    }

    setFindStatus('searching');
    var nq = normalizeQuery(q);
    var key = (nq.key || '').toLowerCase();
    var full = nq.full || '';
    var isOffset = /^0x[0-9a-f]+$/i.test(key);
    var isTdi = /^\d+$/.test(key);
    var nameRe = null;
    try { nameRe = new RegExp('\\b' + escapeRe(key) + '\\b', 'i'); } catch (e) { nameRe = null; }

    var base = finderParsed.filter(function (r) {
      var name = (r.name || '').toLowerCase();
      var sig = (r.signature || '').toLowerCase().replace(/\s+/g, ' ').trim();
      var cls = (r.className || '').toLowerCase();
      var ns = (r.namespace || '').toLowerCase();
      var off = (r.offset || '').toLowerCase();
      var rva = (r.rva || '').toLowerCase();
      var tdi = String(r.typeDefIndex || '');

      // Offset / RVA search
      if (isOffset) {
        return off === key || rva === key || off.indexOf(key) !== -1 || rva.indexOf(key) !== -1;
      }
      // TypeDefIndex search
      if (isTdi) return tdi === key;

      // Exact method/field name (best)
      if (name && name === key) return true;

      // Whole-identifier match inside signature (not loose substring)
      if (nameRe && name && nameRe.test(name)) return true;
      if (nameRe && sig && nameRe.test(sig)) return true;

      // Full signature paste (normalized)
      if (full.length > 10 && sig) {
        var sigNoMods = sig.replace(/^(public|private|protected|internal|static|virtual|override|abstract|sealed|new|extern|unsafe|readonly)\s+/g, '');
        if (sig === full || sig.indexOf(full) !== -1 || full.indexOf(sig) !== -1) return true;
        if (sigNoMods === full || full.indexOf(sigNoMods) !== -1) return true;
      }

      // Class / namespace only when query looks like a type name (no parentheses in original)
      if (q.indexOf('(') === -1 && !isOffset && key.length > 2) {
        if (cls === key || ns === key) return true;
      }
      return false;
    });

    // Rank: exact name first, then same signature shape
    base.sort(function (a, b) {
      var an = (a.name || '').toLowerCase();
      var bn = (b.name || '').toLowerCase();
      var ar = an === key ? 0 : 1;
      var br = bn === key ? 0 : 1;
      if (ar !== br) return ar - br;
      return (a.lineNumber || 0) - (b.lineNumber || 0);
    });

    // All = methods + fields; Methods = methods only; Fields = fields only
    if (finderFilter === 'methods') base = base.filter(function (r) { return r.type === 'method'; });
    else if (finderFilter === 'fields') base = base.filter(function (r) { return r.type === 'field'; });
    // finderFilter === 'all' → keep both

    finderResults = base;
    updateFinderSummary(base);
    setFindStatus(base.length ? 'done' : 'empty');
    renderFinderCards(base);
  }

  function bindFinder() {
    var input = document.getElementById('finderInput');
    if (input) {
      input.addEventListener('change', function (e) {
        var f = e.target.files && e.target.files[0];
        if (f) loadFinderDumpFromFile(f);
      });
    }
    var btn = document.getElementById('btnFind');
    if (btn) btn.addEventListener('click', doFind);
    var search = document.getElementById('finderSearch');
    if (search) {
      search.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') doFind();
      });
    }
    document.querySelectorAll('.filter-chip').forEach(function (chip) {
      chip.addEventListener('click', function () {
        document.querySelectorAll('.filter-chip').forEach(function (c) { c.classList.remove('active'); });
        chip.classList.add('active');
        finderFilter = chip.getAttribute('data-filter') || 'all';
        if (finderResults.length || finderParsed.length) doFind();
      });
    });
  }

  window._copyHex = function (el) {
    var hex = (el && (el.getAttribute('data-hex') || el.textContent)) || '';
    if (!hex) return;
    navigator.clipboard.writeText(hex).catch(function () {});
  };

  /* ════════════════════════════════════════
     SETTINGS
     ════════════════════════════════════════ */
  function loadSettings() {
    try {
      var s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      SETTINGS = Object.assign({}, DEFAULT_SETTINGS, s);
    } catch (e) {}
  }
  function saveSettings() {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) {}
  }

  function bindSettings() {
    var autoDl = document.getElementById('setAutoDownload');
    var copyEn = document.getElementById('setCopyEnabled');
    if (autoDl) autoDl.checked = !!SETTINGS.autoDownload;
    if (copyEn) copyEn.checked = SETTINGS.copyEnabled !== false;

    if (autoDl) autoDl.addEventListener('change', function () {
      SETTINGS.autoDownload = autoDl.checked;
      saveSettings();
    });
    if (copyEn) copyEn.addEventListener('change', function () {
      SETTINGS.copyEnabled = copyEn.checked;
      saveSettings();
    });

    document.getElementById('btnChangePass').addEventListener('click', function () {
      var user = Auth.getCurrentUser();
      if (!user) return;
      var cur = document.getElementById('setCurPass').value;
      var neu = document.getElementById('setNewPass').value;
      var conf = document.getElementById('setConfirmPass').value;
      var err = document.getElementById('passError');
      if (neu !== conf) { err.textContent = 'New passwords do not match.'; return; }
      var res = Auth.changePassword(user.email, cur, neu);
      if (!res.ok) { err.textContent = res.error; return; }
      err.style.color = 'var(--green)';
      err.textContent = 'Password updated successfully.';
      document.getElementById('setCurPass').value = '';
      document.getElementById('setNewPass').value = '';
      document.getElementById('setConfirmPass').value = '';
      setTimeout(function () { err.textContent = ''; err.style.color = ''; }, 2500);
    });

    document.getElementById('btnUpdateAccount').addEventListener('click', function () {
      var user = Auth.getCurrentUser();
      if (!user) return;
      var emailVal = (document.getElementById('setEmailField').value || '').trim().toLowerCase();
      var err = document.getElementById('accountError');
      if (!emailVal || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) {
        err.textContent = 'Please enter a valid email address.';
        return;
      }
      if (user.email === Auth.OWNER_EMAIL) {
        err.textContent = 'Owner email cannot be changed here.';
        return;
      }
      // Client-side email change for free users
      var res = Auth.updateName(user.email, Auth.nameFromEmail(emailVal));
      err.style.color = 'var(--green)';
      err.textContent = 'Email change requested. Contact owner if you need full migration.';
      setTimeout(function () { err.textContent = ''; err.style.color = ''; }, 3000);
    });
  }

  /* ════════════════════════════════════════
     LEGAL — TERMS OF SERVICE / PRIVACY POLICY
     ════════════════════════════════════════ */

  function fillLegalBodies() {
    var terms = document.getElementById('termsBody');
    var privacy = document.getElementById('privacyBody');
    if (terms && LEGAL_CONTENT.terms) terms.innerHTML = LEGAL_CONTENT.terms.html;
    if (privacy && LEGAL_CONTENT.privacy) privacy.innerHTML = LEGAL_CONTENT.privacy.html;
  }

  var LEGAL_UPDATED = 'September 13, 2026';

  var LEGAL_CONTENT = {
    terms: {
      title: 'Terms of Service',
      html:
        '<p class="legal-updated">Last updated: ' + LEGAL_UPDATED + '</p>' +
        '<p>These Terms of Service ("Terms") govern your access to and use of YUSH TOOLS ' +
        '(the "Service"), including the Offset Updater, Offset Finder, Dashboard, Admin Panel, ' +
        'and any related websites, APIs, or features operated under the yushtools domain. By ' +
        'creating an account, signing in, uploading files, or otherwise using the Service, you ' +
        'acknowledge that you have read, understood, and agree to be bound by these Terms. If you ' +
        'do not agree, you must not access or use the Service.</p>' +

        '<h4>1. Eligibility and Accounts</h4>' +
        '<p>You must be legally able to form a binding contract in your country of residence to ' +
        'use the Service. Account registration may require a valid email address and completion of ' +
        'security checks (including CAPTCHA or similar verification). You are responsible for ' +
        'keeping your login credentials confidential and for all activity under your account. ' +
        'Notify the operator immediately if you suspect unauthorized access. Accounts may remain ' +
        'pending until approved by an administrator. The operator may refuse, suspend, or terminate ' +
        'accounts that violate these Terms or that pose a security risk.</p>' +

        '<h4>2. Description of the Service</h4>' +
        '<p>YUSH TOOLS provides client-side oriented utilities for working with game dump files ' +
        '(.cs and related source files), including searching methods/fields/offsets and synchronizing ' +
        'offsets between dump versions. Certain dump packages may be hosted on the server solely so ' +
        'authorized users can select a version without uploading large files themselves. Processing of ' +
        'your personal source files is designed to occur primarily in your browser. The Service is ' +
        'provided for legitimate reverse-engineering, learning, and development workflows consistent ' +
        'with applicable law.</p>' +

        '<h4>3. Acceptable Use</h4>' +
        '<p>You agree not to: (a) attempt to disrupt, overload, or interfere with the Service, ' +
        'including DDoS, scraping, or automated abuse; (b) reverse engineer, copy, clone, mirror, or ' +
        'redistribute the Service interface, branding, or server assets without permission; (c) upload ' +
        'malware, illegal content, or material you do not have rights to process; (d) bypass authentication, ' +
        'approval, rate limits, or security controls; (e) use another person\'s account without authorization; ' +
        '(f) use the Service in violation of game publisher terms, local law, or third-party rights. ' +
        'Violation may result in immediate suspension or permanent ban, and may be reported where required by law.</p>' +

        '<h4>4. Files, Dumps, and Intellectual Property</h4>' +
        '<p>You retain ownership of files you upload or process. By using the Service you grant only the ' +
        'limited technical permission needed to transmit, temporarily store (where applicable), and process ' +
        'those files to provide the requested feature. Dump packages published by administrators remain ' +
        'under the operator\'s control and may be replaced or removed at any time. YUSH TOOLS branding, ' +
        'UI design, scripts, and documentation are protected. You may not claim the Service as your own product.</p>' +

        '<h4>5. No Warranty</h4>' +
        '<p>THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR ' +
        'IMPLIED, INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. We do not ' +
        'guarantee uninterrupted uptime, perfect offset accuracy for every dump, or compatibility with every ' +
        'file format. Results depend on dump quality and your inputs. You use outputs at your own risk.</p>' +

        '<h4>6. Limitation of Liability</h4>' +
        '<p>To the maximum extent permitted by law, the operator and affiliates shall not be liable for any ' +
        'indirect, incidental, special, consequential, or punitive damages, or any loss of data, profits, or ' +
        'business arising from your use of the Service. Aggregate liability for any claim relating to the ' +
        'Service shall not exceed the amount you paid (if any) for access in the twelve months before the claim.</p>' +

        '<h4>7. Account Approval, Roles, and Termination</h4>' +
        '<p>Free accounts may require admin approval. Administrators may approve, reject, ban, or delete ' +
        'accounts. You may stop using the Service at any time. We may suspend or terminate access for ' +
        'Terms violations, security incidents, inactivity, or operational reasons, with or without prior notice.</p>' +

        '<h4>8. Changes to the Service and Terms</h4>' +
        '<p>We may modify features, dump catalogs, or these Terms. Material changes may be indicated by ' +
        'updating the "Last updated" date. Continued use after changes constitutes acceptance of the revised Terms.</p>' +

        '<h4>9. Contact</h4>' +
        '<p>For account, legal, or security questions related to YUSH TOOLS, contact the developer through ' +
        'the official channels listed on the Developer page (including Telegram @PrimeYush where available).</p>'
    },
    privacy: {
      title: 'Privacy Policy',
      html:
        '<p class="legal-updated">Last updated: ' + LEGAL_UPDATED + '</p>' +
        '<p>This Privacy Policy explains how YUSH TOOLS ("we", "the Service") handles information when you ' +
        'use the website and tools. We aim to collect only what is needed to operate authentication, security, ' +
        'and core features.</p>' +

        '<h4>1. Information We Process</h4>' +
        '<p><b>Account data:</b> email address, password hash (not plaintext password), optional display name ' +
        'derived from email, role (for example free user or admin), approval status, and basic activity markers ' +
        'such as last login time or login count stored for account management.</p>' +
        '<p><b>Security data:</b> CAPTCHA/Turnstile tokens, approximate IP address for rate limiting and abuse ' +
        'prevention, browser user-agent, and similar request metadata used to detect bots, scrapers, and attacks.</p>' +
        '<p><b>Files you choose:</b> source files and dumps you select for Offset Updater or Offset Finder are ' +
        'primarily processed in your browser. Server-hosted dump packages uploaded by administrators are stored ' +
        'so users can select a version. We do not sell your personal source files.</p>' +
        '<p><b>Local device storage:</b> the Service may use browser localStorage or similar for session state, ' +
        '"remember me", UI preferences (theme), and client-side settings.</p>' +

        '<h4>2. How We Use Information</h4>' +
        '<p>We use information to: authenticate users; approve or manage accounts; provide updater/finder features; ' +
        'protect the Service against DDoS, credential stuffing, scraping, cloning, and unauthorized access; diagnose ' +
        'errors; and communicate important service notices when necessary.</p>' +

        '<h4>3. Cookies and Similar Technologies</h4>' +
        '<p>Essential storage may be used for login sessions and preferences. Security widgets (such as Cloudflare ' +
        'Turnstile) may set their own cookies or tokens according to their policies. We do not use third-party ' +
        'advertising trackers as part of the core tool experience.</p>' +

        '<h4>4. Sharing</h4>' +
        '<p>We do not sell personal account data. Limited sharing may occur with infrastructure providers (hosting, ' +
        'CDN/WAF, email delivery for verification codes) solely to run the Service. We may disclose information if ' +
        'required by law or to protect the Service, users, or public safety.</p>' +

        '<h4>5. Retention</h4>' +
        '<p>Account records are retained while your account remains active and as needed for security logs. ' +
        'Administrator-uploaded dump packages remain until replaced or removed. Client-side local data remains on ' +
        'your device until you clear site data. Temporary upload chunks on the server are intended to be cleaned ' +
        'after assembly of a dump package.</p>' +

        '<h4>6. Security</h4>' +
        '<p>We implement reasonable technical measures such as HTTPS where configured, password hashing on the ' +
        'client account store model, CAPTCHA on login, rate limiting, bot filtering, and restricted direct access ' +
        'to dump storage. No method of transmission or storage is 100% secure; you use the Service at your own risk.</p>' +

        '<h4>7. Your Choices</h4>' +
        '<p>You may request account deletion by contacting the operator through official Developer channels. ' +
        'You can clear browser storage at any time. If email verification is enabled, providing an email is required ' +
        'to complete registration.</p>' +

        '<h4>8. Children</h4>' +
        '<p>The Service is not directed to children under 13 (or the minimum age required in your jurisdiction). ' +
        'We do not knowingly collect personal information from children.</p>' +

        '<h4>9. International Users</h4>' +
        '<p>The Service may be hosted in jurisdictions different from your own. By using the Service you understand ' +
        'that information may be processed in the country where the servers are located.</p>' +

        '<h4>10. Changes and Contact</h4>' +
        '<p>We may update this Privacy Policy by changing the "Last updated" date. For privacy questions, contact ' +
        'the developer via the channels listed on the Developer page.</p>'
    }
  };

  function openLegalModal(kind) {
    var entry = LEGAL_CONTENT[kind];
    if (!entry) return;
    var overlay = document.getElementById('legalModalOverlay');
    var titleEl = document.getElementById('legalModalTitle');
    var bodyEl = document.getElementById('legalModalBody');
    if (!overlay || !titleEl || !bodyEl) return;
    titleEl.textContent = entry.title;
    bodyEl.innerHTML = entry.html;
    bodyEl.scrollTop = 0;
    overlay.classList.add('open');
    document.body.classList.add('modal-open');
  }

  function closeLegalModal() {
    var overlay = document.getElementById('legalModalOverlay');
    if (overlay) overlay.classList.remove('open');
    document.body.classList.remove('modal-open');
  }

  function bindLegalModal() {
    var btnTerms = document.getElementById('btnTerms');
    var btnPrivacy = document.getElementById('btnPrivacy');
    var overlay = document.getElementById('legalModalOverlay');
    var closeBtn = document.getElementById('legalModalClose');
    var box = document.getElementById('legalModalBox');
    if (btnTerms) btnTerms.addEventListener('click', function () { fillLegalBodies(); switchTab('terms'); });
    var exitT = document.getElementById('btnExitTerms');
    var exitP = document.getElementById('btnExitPrivacy');
    if (exitT) exitT.addEventListener('click', function () { switchTab('developer'); });
    if (exitP) exitP.addEventListener('click', function () { switchTab('developer'); });
    if (btnPrivacy) btnPrivacy.addEventListener('click', function () { fillLegalBodies(); switchTab('privacy'); });
    if (closeBtn) closeBtn.addEventListener('click', closeLegalModal);
    if (overlay) overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeLegalModal();
    });
    if (box) box.addEventListener('click', function (e) { e.stopPropagation(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeLegalModal();
    });
  }

  /* ════════════════════════════════════════
     ADMIN PANEL
     ════════════════════════════════════════ */
  /* Dump links - permanent (stored in dumps/{old|new}/index.json) */

  // Rolling-window speed estimate: keeps the last ~1.5s of (time, bytes)
  // samples so the displayed speed reflects *recent* throughput rather
  // than a single noisy instant-to-instant delta or a whole-transfer average.
  function makeSpeedTracker() {
    var samples = [];
    var lastGood = 0;
    return function (downloaded) {
      var now = performance.now();
      samples.push({ t: now, b: downloaded });
      // Keep a longer window so the speed label does not flicker to 0
      while (samples.length > 2 && now - samples[0].t > 4000) samples.shift();
      if (samples.length < 2) return lastGood;
      var dt = (now - samples[0].t) / 1000;
      var db = downloaded - samples[0].b;
      if (dt > 0.05 && db >= 0) {
        var sp = db / dt;
        // EMA so the number stays stable instead of vanishing between polls
        lastGood = lastGood > 0 ? (lastGood * 0.55 + sp * 0.45) : sp;
      }
      return lastGood;
    };
  }

  function fmtSpeed(bytesPerSec) {
    if (!bytesPerSec || bytesPerSec <= 0) return '0 KB/s';
    if (bytesPerSec < 1048576) return Math.max(1, Math.round(bytesPerSec / 1024)) + ' KB/s';
    return (bytesPerSec / 1048576).toFixed(1) + ' MB/s';
  }

  function saveDumpLink(kind, verSel, linkId, errId, btnId) {
    var verEl = document.getElementById(verSel);
    var linkEl = document.getElementById(linkId);
    var err = document.getElementById(errId);
    var btn = btnId ? document.getElementById(btnId) : null;
    var progWrap = document.getElementById(kind === 'old' ? 'adminOldProgress' : 'adminNewProgress');
    var progFill = document.getElementById(kind === 'old' ? 'adminOldProgressFill' : 'adminNewProgressFill');
    var progSpeed = document.getElementById(kind === 'old' ? 'adminOldProgressSpeed' : 'adminNewProgressSpeed');
    var progSize = document.getElementById(kind === 'old' ? 'adminOldProgressSize' : 'adminNewProgressSize');
    var speedText = progSpeed ? progSpeed.querySelector('.link-dl-speed-text') : null;

    if (err) { err.style.color = ''; err.textContent = ''; }
    if (!verEl || !linkEl) {
      alert('Form not ready. Hard-refresh the page.');
      return;
    }
    var ver = String(verEl.value || '').trim();
    var verLabel = (verEl.options && verEl.selectedIndex >= 0)
      ? String(verEl.options[verEl.selectedIndex].text || ('Garena ' + ver)).trim()
      : ('Garena ' + ver);
    var url = String(linkEl.value || '').trim();
    if (!/^[0-9A-Za-z._-]+$/.test(ver)) {
      if (err) err.textContent = 'Invalid version.';
      return;
    }
    if (!/^https?:\/\//i.test(url)) {
      if (err) err.textContent = 'Paste a full http(s) link (MediaFire, Gofile, SFile, direct .cs, etc.).';
      return;
    }

    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    if (err) err.textContent = '';
    if (progWrap) progWrap.style.display = '';
    if (progFill) progFill.style.width = '0%';
    if (progFill) progFill.classList.add('indeterminate');
    if (speedText) speedText.textContent = 'Connecting…';
    if (progSize) progSize.textContent = '—';

    var getSpeed = makeSpeedTracker();
    var finished = false;
    var _smooth = { lastBytes: 0, lastTotal: 0, lastTs: Date.now(), speedBps: 0, timer: null };

    function stopSmooth() {
      if (_smooth.timer) { clearInterval(_smooth.timer); _smooth.timer = null; }
    }

    function paintProgress(bytes, total) {
      // Monotonic: never show less than the highest progress already painted
      if (bytes < (_smooth.peakBytes || 0)) bytes = _smooth.peakBytes;
      if (bytes > (_smooth.peakBytes || 0)) _smooth.peakBytes = bytes;
      if (total > 0 && total < (_smooth.lastTotal || 0)) total = _smooth.lastTotal;
      if (progFill) progFill.classList.remove('indeterminate');
      if (total > 0) {
        var pct = Math.max(0, Math.min(99, Math.round((bytes / total) * 100)));
        if (progFill) progFill.style.width = pct + '%';
        if (progSize) progSize.textContent = fmtSz(Math.floor(bytes)) + ' / ' + fmtSz(total);
      } else if (progSize) {
        progSize.textContent = fmtSz(Math.floor(bytes)) + ' / size unknown';
      }
      var speed = getSpeed(Math.floor(bytes));
      if (!(speed > 0) && _smooth.speedBps > 0) speed = _smooth.speedBps;
      if (speedText) {
        if (speed > 0) speedText.textContent = fmtSpeed(speed);
        else if (bytes === 0) speedText.textContent = 'Starting…';
      }
    }

    function startSmooth() {
      stopSmooth();
      _smooth.timer = setInterval(function () {
        if (finished) { stopSmooth(); return; }
        if (_smooth.lastTotal <= 0 || _smooth.speedBps <= 0) return;
        var elapsed = (Date.now() - _smooth.lastTs) / 1000;
        // Project forward but never past 99% and never below peak
        var projected = Math.min(_smooth.lastTotal * 0.99, Math.max(_smooth.peakBytes || 0, _smooth.lastBytes + _smooth.speedBps * elapsed * 0.85));
        paintProgress(projected, _smooth.lastTotal);
      }, 100);
    }

    function finish(ok, message, isError) {
      if (finished) return;
      finished = true;
      stopSmooth();
      if (btn) {
        btn.disabled = false;
        btn.textContent = kind === 'old' ? 'Save Old Dump Link' : 'Save New Dump Link';
      }
      if (progFill) progFill.classList.remove('indeterminate');
      if (ok && progFill) progFill.style.width = '100%';
      setTimeout(function () { if (progWrap) progWrap.style.display = 'none'; }, ok ? 900 : 2500);
      if (err) {
        err.style.color = isError ? '' : 'var(--green)';
        err.textContent = message;
      }
      if (ok) {
        try { loadOldVersions(); } catch (e) {}
        try { loadNewVersions(); } catch (e) {}
        try { refreshDashboard(); } catch (e) {}
        try { renderAdminDumpList(); } catch (e) {}
      }
    }

    function updateProgress(downloaded, total) {
      var now = Date.now();
      var dt = Math.max(0.2, (now - _smooth.lastTs) / 1000);
      // Real restart from server (Range ignored → truncated) — reset peak once
      if ((_smooth.peakBytes || 0) > 1024 * 1024 && downloaded < (_smooth.peakBytes * 0.25)) {
        _smooth.peakBytes = downloaded;
        _smooth.lastBytes = downloaded;
      }
      if (downloaded >= _smooth.lastBytes && _smooth.lastTs) {
        var instant = (downloaded - _smooth.lastBytes) / dt;
        if (instant > 0) _smooth.speedBps = _smooth.speedBps > 0 ? (_smooth.speedBps * 0.5 + instant * 0.5) : instant;
      }
      if (downloaded >= _smooth.lastBytes) _smooth.lastBytes = downloaded;
      if (total > 0) _smooth.lastTotal = total;
      _smooth.lastTs = now;
      paintProgress(downloaded, total || _smooth.lastTotal || 0);
      if (!_smooth.timer) startSmooth();
    }

    function parseJsonResponse(res) {
      return res.text().then(function (text) {
        var data;
        try { data = JSON.parse(text); } catch (e) {
          var snippet = (text || '').replace(/<[^>]*>/g, ' ').trim().slice(0, 180);
          throw new Error(snippet ? ('Server error: ' + snippet) : ('Bad server response (HTTP ' + res.status + ').'));
        }
        return data;
      });
    }

    // Downloads happen as a series of short (~20s) server-side slices
    // instead of one long-held request, so a slow link or a host's
    // execution-time limit can never kill the transfer mid-way — each
    // poll just picks up where the last one left off.
    var _jobEcho = null;

    function pollChunk(jobId, attempt) {
      if (finished) return;
      var body = { jobId: jobId };
      if (_jobEcho) {
        body.kind = _jobEcho.kind;
        body.version = _jobEcho.version;
        body.label = _jobEcho.label;
        body.region = _jobEcho.region;
        body.sourceUrl = _jobEcho.sourceUrl;
        body.resolvedUrl = _jobEcho.resolvedUrl;
        body.tmp = _jobEcho.tmp;
        body.downloaded = _jobEcho.downloaded || 0;
        body.total = _jobEcho.total || 0;
        body.chunks = _jobEcho.chunks || 0;
      }
      fetch(yushApi('api/download-dump-chunk.php'), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }).then(parseJsonResponse).then(function (data) {
        if (finished) return;
        if (data.done) {
          if (data.ok) {
            updateProgress(data.downloaded || data.size || 0, data.total || data.size || 0);
            finish(true, 'Saved + cached ' + verLabel + ' (' + (data.size ? fmtSz(data.size) : 'ok') + ') — permanent on server.', false);
          } else {
            finish(false, data.error || 'Save failed.', true);
          }
          return;
        }
        if (_jobEcho) {
          _jobEcho.downloaded = data.downloaded || _jobEcho.downloaded || 0;
          _jobEcho.total = data.total || _jobEcho.total || 0;
          _jobEcho.chunks = (_jobEcho.chunks || 0) + 1;
        }
        updateProgress(data.downloaded || 0, data.total || 0);
        pollChunk(jobId, 0);
      }).catch(function (e) {
        var tries = (attempt || 0) + 1;
        if (tries >= 5) {
          finish(false, (e && e.message) || 'Lost connection while downloading. Check your connection and try again.', true);
          return;
        }
        setTimeout(function () { pollChunk(jobId, tries); }, 1200);
      });
    }

    fetch(yushApi('api/download-dump-start.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: kind, version: ver, label: ver, region: 'GARENA', url: url })
    }).then(parseJsonResponse).then(function (data) {
      if (finished) return;
      if (!data.ok) {
        finish(false, data.error || 'Could not start download.', true);
        return;
      }
      _jobEcho = data.job || null;
      updateProgress(0, data.total || 0);
      if (speedText) speedText.textContent = 'Starting…';
      pollChunk(data.jobId, 0);
    }).catch(function (e) {
      finish(false, (e && e.message) || 'Network error while starting the download. Check your connection and try again.', true);
    });
  }

  function bindAdminUploads() {
    function bind(btnId, kind, ver, link, err) {
      var b = document.getElementById(btnId);
      if (!b) return;
      b.onclick = function (ev) {
        if (ev) ev.preventDefault();
        saveDumpLink(kind, ver, link, err, btnId);
      };
    }
    bind('btnUploadOldDump', 'old', 'adminOldVer', 'adminOldLink', 'adminOldErr');
    bind('btnUploadNewDump', 'new', 'adminNewVer', 'adminNewLink', 'adminNewErr');
  }

  window.uploadOldDump = function () { /* removed */ };
  window.uploadNewDump = function () { /* removed */ };


  // Bypass Formatting lives in js/formatting.js (window.YushFormatting)

  function fmtWhen(v) {
    try {
      var d = new Date(v);
      if (isNaN(d.getTime())) return String(v || '—');
      return d.toLocaleString();
    } catch (e) { return String(v || '—'); }
  }

  function postIpBlock(action, ip, reason) {
    fetch(yushApi('api/security-ip-block.php'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action, ip: ip, reason: reason || '' })
    }).then(function (r) { return r.json(); }).then(function (data) {
      if (!data || !data.ok) { alert((data && data.error) || 'Could not update the ban list.'); return; }
      loadSecurityEvents();
    }).catch(function () { alert('Network error while updating the ban list.'); });
  }

  /* ════════════════════════════════════════
     SUSPICIOUS ACTIVITY DASHBOARD (Krawl-style)
     ════════════════════════════════════════ */
  var CAT_META = {
    honeypot:   { label: 'Honeypot',  color: '#ef4444' },
    bot:        { label: 'Scripted bot', color: '#eab308' },
    payload:    { label: 'Attack payload', color: '#f97316' },
    'blocked-ip': { label: 'Blocked IP', color: '#ef4444' },
    flood:      { label: 'Flood', color: '#a78bfa' },
    other:      { label: 'Other', color: '#5a6a78' }
  };
  var _secEventsCache = [];
  var _secMap = null;
  var _secMarkers = {};
  var GEO_CACHE_KEY = '__yush_geoip_cache_v1__';
  var GEO_CACHE_TTL = 7 * 24 * 60 * 60 * 1000; // 7 days

  function catMeta(cat) { return CAT_META[cat] || CAT_META.other; }

  function readGeoCache() {
    try { return JSON.parse(localStorage.getItem(GEO_CACHE_KEY) || '{}'); } catch (e) { return {}; }
  }
  function writeGeoCache(cache) {
    try { localStorage.setItem(GEO_CACHE_KEY, JSON.stringify(cache)); } catch (e) {}
  }

  /** Resolves an array of IPs to {lat,lon,country} via ipwho.is, with a
   *  localStorage cache so a repeat visit doesn't re-hit the API for IPs
   *  we've already placed on the map. Runs with limited concurrency so a
   *  burst of new attacker IPs doesn't fire dozens of requests at once. */
  function geolocateIps(ips, onEach) {
    var cache = readGeoCache();
    var now = Date.now();
    var queue = [];
    ips.forEach(function (ip) {
      var cached = cache[ip];
      if (cached && (now - (cached._at || 0)) < GEO_CACHE_TTL) {
        if (cached.ok) onEach(ip, cached);
        return;
      }
      queue.push(ip);
    });
    var CONCURRENCY = 4;
    var i = 0;
    function next() {
      if (i >= queue.length) return;
      var ip = queue[i++];
      fetch('https://ipwho.is/' + encodeURIComponent(ip))
        .then(function (r) { return r.json(); })
        .then(function (g) {
          var rec = g && g.success !== false
            ? { ok: true, lat: g.latitude, lon: g.longitude, country: g.country, city: g.city, _at: Date.now() }
            : { ok: false, _at: Date.now() };
          cache[ip] = rec;
          writeGeoCache(cache);
          if (rec.ok) onEach(ip, rec);
        })
        .catch(function () { cache[ip] = { ok: false, _at: Date.now() }; })
        .then(next);
    }
    for (var c = 0; c < CONCURRENCY; c++) next();
  }

  function ensureSecMap() {
    if (_secMap || typeof L === 'undefined') return _secMap;
    var el = document.getElementById('secMap');
    if (!el) return null;
    _secMap = L.map(el, { worldCopyJump: true, minZoom: 1 }).setView([15, 10], 1);
    // Free dark basemap that does not require an API key (Carto CDN).
    // The previous {r}@2x form sometimes rendered a "KEY REQUIRED" watermark
    // on certain hosts / mobile browsers; plain PNG path is reliable.
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19
    }).addTo(_secMap);
    return _secMap;
  }

  /** Groups events by IP, geolocates each unique IP, and drops a colored
   *  circle marker (color = most severe category seen from that IP,
   *  radius = how many events came from it) onto the honeypot map. */
  function renderSecMap(events) {
    var map = ensureSecMap();
    if (!map) return; // Leaflet script hasn't loaded (e.g. offline / CDN blocked)

    var severity = ['honeypot', 'payload', 'bot', 'blocked-ip', 'flood', 'other'];
    var byIp = {};
    events.forEach(function (e) {
      if (!e.ip) return;
      if (!byIp[e.ip]) byIp[e.ip] = { count: 0, cat: 'other' };
      byIp[e.ip].count++;
      if (severity.indexOf(e.category) < severity.indexOf(byIp[e.ip].cat)) byIp[e.ip].cat = e.category;
    });

    Object.keys(_secMarkers).forEach(function (ip) {
      if (!byIp[ip]) { map.removeLayer(_secMarkers[ip]); delete _secMarkers[ip]; }
    });

    geolocateIps(Object.keys(byIp), function (ip, geo) {
      var info = byIp[ip];
      var meta = catMeta(info.cat);
      var radius = Math.min(6 + info.count * 1.5, 22);
      if (_secMarkers[ip]) {
        _secMarkers[ip].setLatLng([geo.lat, geo.lon]).setRadius(radius)
          .setStyle({ color: meta.color, fillColor: meta.color });
      } else {
        _secMarkers[ip] = L.circleMarker([geo.lat, geo.lon], {
          radius: radius, color: meta.color, fillColor: meta.color,
          fillOpacity: 0.55, weight: 2, className: 'sec-map-marker'
        }).addTo(map);
      }
      _secMarkers[ip].bindPopup(
        '<b>' + esc(ip) + '</b><br>' + esc(geo.city ? geo.city + ', ' : '') + esc(geo.country || '') +
        '<br>' + info.count + ' event(s) · ' + esc(meta.label)
      );
    });
  }

  function renderSecList(events, filterText) {
    var listEl = document.getElementById('securityEventList');
    if (!listEl) return;
    var f = (filterText || '').toLowerCase().trim();
    var filtered = f ? events.filter(function (e) {
      return (e.ip || '').toLowerCase().indexOf(f) >= 0 ||
        (e.path || '').toLowerCase().indexOf(f) >= 0 ||
        (e.ua || '').toLowerCase().indexOf(f) >= 0;
    }) : events;

    if (!filtered.length) {
      listEl.innerHTML = '<div class="admin-empty">' + (f ? 'No matching activity' : 'No suspicious activity logged yet') + '</div>';
      return;
    }
    listEl.innerHTML = filtered.slice(0, 80).map(function (e) {
      var meta = catMeta(e.category);
      return '<div class="sec-event-row">' +
        '<span class="sec-event-cat" style="background:' + meta.color + '"></span>' +
        '<div class="sec-event-body">' +
          '<div class="sec-event-top">' +
            '<span class="sec-event-ip">' + esc(e.ip || '—') + '</span>' +
            '<span class="sec-event-tag">' + esc(meta.label) + '</span>' +
            '<span class="sec-event-tag">' + esc(e.reason || e.event || 'blocked') + '</span>' +
          '</div>' +
          '<div class="sec-event-path">' + esc(e.method || '—') + ' ' + esc(e.path || '—') + '</div>' +
          (e.ua ? '<div class="sec-event-ua">' + esc(e.ua) + '</div>' : '') +
          '<div class="sec-event-time">' + esc(fmtWhen(e.ts)) + '</div>' +
          (e.ip ? '<button class="admin-btn ban" data-ban-ip="' + esc(e.ip) + '">Block IP</button>' : '') +
        '</div></div>';
    }).join('');
    listEl.querySelectorAll('[data-ban-ip]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        postIpBlock('add', btn.getAttribute('data-ban-ip'), 'flagged from suspicious activity');
      });
    });
  }

  function loadSecurityEvents() {
    var listEl = document.getElementById('securityEventList');
    var banListEl = document.getElementById('banIpList');
    if (!listEl || !banListEl) return;

    fetch(yushApi('api/security-events.php')).then(function (r) { return r.json(); }).then(function (data) {
      if (!data || !data.ok) return;

      var s = data.summary || {};
      var setNum = function (id, v) { var el = document.getElementById(id); if (el) el.textContent = v || 0; };
      setNum('secStatTotal', s.total);
      setNum('secStat24h', s.last24h);
      setNum('secStatIps', s.uniqueIps);
      setNum('secStatPaths', s.uniquePaths);
      setNum('secStatHoneypot', s.honeypotCaught);
      setNum('secStatBots', s.scriptedBots);

      var events = data.events || [];
      _secEventsCache = events;
      renderAttackingIps(events, data.blockedIps || []);

      var manual = data.blockedIps || [];
      var countEl = document.getElementById('banIpCount');
      if (countEl) countEl.textContent = manual.length;
      if (!manual.length) {
        banListEl.innerHTML = '<div class="admin-empty">No manually blocked IPs</div>';
      } else {
        banListEl.innerHTML = manual.map(function (row) {
          return '<div class="admin-user-row">' +
            '<div class="admin-user-info">' +
              '<div class="admin-user-email">' + esc(row.ip) + '</div>' +
              '<div class="admin-user-meta">' + esc(row.reason || 'manual') + ' · ' + esc(fmtWhen((row.addedAt || 0) * 1000)) + '</div>' +
            '</div>' +
            '<div class="admin-user-actions">' +
              '<button class="admin-btn approve" data-unban-ip="' + esc(row.ip) + '">Unlock</button>' +
            '</div></div>';
        }).join('');
        banListEl.querySelectorAll('[data-unban-ip]').forEach(function (btn) {
          btn.addEventListener('click', function () { postIpBlock('remove', btn.getAttribute('data-unban-ip'), ''); });
        });
      }
    }).catch(function () {});
  }

  /** Detect client / tool fingerprints from UA + path + reason. */
  function detectAttackMethod(ua, path, reason, category) {
    var s = ((ua || '') + ' ' + (path || '') + ' ' + (reason || '') + ' ' + (category || '')).toLowerCase();
    var tags = [];
    if (/termux|android.*curl|dalvik/i.test(s)) tags.push('Termux / Android');
    if (/python-requests|python-urllib|aiohttp|scrapy|httpx\//i.test(s)) tags.push('Python script');
    if (/\bcurl\//i.test(s) || /wget\//i.test(s)) tags.push('curl / wget');
    if (/go-http-client|golang/i.test(s)) tags.push('Go client');
    if (/java\/|apache-httpclient|okhttp/i.test(s)) tags.push('Java / OkHttp');
    if (/libwww-perl|lwp::|perl/i.test(s)) tags.push('Perl');
    if (/php\//i.test(s) || /wordpress/i.test(s)) tags.push('PHP client');
    if (/nikto|sqlmap|nmap|masscan|zgrab|nuclei|dirbuster|gobuster|wfuzz|hydra/i.test(s)) tags.push('Scanner tool');
    if (/ida|ghidra|radare|x64dbg|cheat.?engine|frida|objection/i.test(s)) tags.push('RE / debugger');
    if (/linux|ubuntu|debian|kali|parrot/i.test(s) && !/android/i.test(s)) tags.push('Linux');
    if (/windows|msie|win64|win32/i.test(s)) tags.push('Windows');
    if (/bot|spider|crawler|scrapy|headless|phantom|selenium|puppeteer|playwright/i.test(s)) tags.push('Bot / automation');
    if (/honeypot/i.test(s)) tags.push('Honeypot trap');
    if (/payload|injection|xss|traversal|\.\.\//i.test(s)) tags.push('Attack payload');
    if (/flood|rate|burst/i.test(s)) tags.push('Flood / rate-limit');
    if (!tags.length) {
      if (/mozilla|chrome|safari|firefox/i.test(s)) tags.push('Browser-like');
      else tags.push('Unknown client');
    }
    return tags;
  }

  /** Attackers Information — full detail cards with method tags + Block. */
  function renderAttackingIps(events, blockedList) {
    var el = document.getElementById('attackingIpList');
    if (!el) return;
    var blockedSet = {};
    (blockedList || []).forEach(function (row) {
      if (row && row.ip) blockedSet[row.ip] = true;
    });
    var byIp = {};
    (events || []).forEach(function (e) {
      if (!e || !e.ip) return;
      if (!byIp[e.ip]) {
        byIp[e.ip] = {
          ip: e.ip,
          count: 0,
          lastCat: e.category || 'other',
          lastPath: e.path || '',
          lastAt: e.ts || 0,
          ua: e.ua || e.userAgent || '',
          reason: e.reason || '',
          method: e.method || '',
          paths: {},
          cats: {}
        };
      }
      var row = byIp[e.ip];
      row.count++;
      if (e.path) row.paths[e.path] = (row.paths[e.path] || 0) + 1;
      if (e.category) row.cats[e.category] = (row.cats[e.category] || 0) + 1;
      if ((e.ts || 0) >= (row.lastAt || 0)) {
        row.lastCat = e.category || row.lastCat;
        row.lastPath = e.path || row.lastPath;
        row.lastAt = e.ts || row.lastAt;
        if (e.ua || e.userAgent) row.ua = e.ua || e.userAgent;
        if (e.reason) row.reason = e.reason;
        if (e.method) row.method = e.method;
      }
    });
    var rows = Object.keys(byIp).map(function (k) { return byIp[k]; });
    rows.sort(function (a, b) { return b.count - a.count; });
    if (!rows.length) {
      el.innerHTML = '<div class="admin-empty">No attackers detected yet</div>';
      return;
    }
    el.innerHTML = rows.map(function (r) {
      var isBlocked = !!blockedSet[r.ip];
      var meta = catMeta(r.lastCat);
      var tags = detectAttackMethod(r.ua, r.lastPath, r.reason, r.lastCat);
      var topPaths = Object.keys(r.paths).sort(function (a, b) { return r.paths[b] - r.paths[a]; }).slice(0, 3);
      var when = r.lastAt ? fmtWhen(typeof r.lastAt === 'number' && r.lastAt < 1e12 ? r.lastAt * 1000 : r.lastAt) : '';
      return '<div class="attacker-card">' +
        '<div class="attacker-top">' +
          '<div class="attacker-ip">' + esc(r.ip) +
            (isBlocked ? ' <span class="attacker-blocked">BLOCKED</span>' : '') +
          '</div>' +
          '<div class="attacker-actions">' +
            (isBlocked
              ? '<button class="admin-btn approve" data-unban-ip="' + esc(r.ip) + '">Unlock</button>'
              : '<button class="admin-btn reject" data-ban-ip="' + esc(r.ip) + '">Block</button>') +
          '</div>' +
        '</div>' +
        '<div class="attacker-tags">' + tags.map(function (t) {
          return '<span class="attacker-tag">' + esc(t) + '</span>';
        }).join('') + '</div>' +
        '<div class="attacker-meta">' +
          '<div><b>Category</b> ' + esc(meta.label) + '</div>' +
          '<div><b>Hits</b> ' + r.count + '</div>' +
          (r.method ? '<div><b>HTTP</b> ' + esc(r.method) + '</div>' : '') +
          (when ? '<div><b>Last seen</b> ' + esc(when) + '</div>' : '') +
        '</div>' +
        (r.lastPath ? '<div class="attacker-path"><b>Path</b> ' + esc(String(r.lastPath).slice(0, 120)) + '</div>' : '') +
        (topPaths.length > 1 ? '<div class="attacker-path"><b>Other paths</b> ' + esc(topPaths.slice(1).join(', ').slice(0, 100)) + '</div>' : '') +
        (r.ua ? '<div class="attacker-ua"><b>User-Agent</b> ' + esc(String(r.ua).slice(0, 160)) + '</div>' : '') +
        (r.reason ? '<div class="attacker-ua"><b>Reason</b> ' + esc(String(r.reason).slice(0, 100)) + '</div>' : '') +
      '</div>';
    }).join('');
    el.querySelectorAll('[data-ban-ip]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var ip = btn.getAttribute('data-ban-ip');
        var reason = prompt('Block reason (optional) for ' + ip + ':', 'suspicious activity');
        if (reason === null) return;
        postIpBlock('add', ip, reason || 'suspicious activity');
      });
    });
    el.querySelectorAll('[data-unban-ip]').forEach(function (btn) {
      btn.addEventListener('click', function () { postIpBlock('remove', btn.getAttribute('data-unban-ip'), ''); });
    });
  }

  function bindSecurityPanel() {
    var refreshBtn = document.getElementById('btnRefreshSecurity');
    if (refreshBtn && !refreshBtn._yushBound) {
      refreshBtn._yushBound = true;
      refreshBtn.addEventListener('click', loadSecurityEvents);
    }
    var banBtn = document.getElementById('btnBanIp');
    if (banBtn && !banBtn._yushBound) {
      banBtn._yushBound = true;
      banBtn.addEventListener('click', function () {
        var ipEl = document.getElementById('banIpInput');
        var reasonEl = document.getElementById('banIpReason');
        var errEl = document.getElementById('banIpErr');
        var ip = String((ipEl && ipEl.value) || '').trim();
        if (errEl) errEl.textContent = '';
        if (!ip) { if (errEl) errEl.textContent = 'Enter an IP address.'; return; }
        postIpBlock('add', ip, (reasonEl && reasonEl.value) || '');
        if (ipEl) ipEl.value = '';
        if (reasonEl) reasonEl.value = '';
      });
    }
  }

  function renderAdminPanel() {
    bindAdminUploads();
    bindSecurityPanel();
    loadSecurityEvents();

    // Pending
    var pend = Auth.getPending();
    var pendKeys = Object.keys(pend);
    document.getElementById('pendingCount').textContent = pendKeys.length;
    var pendList = document.getElementById('pendingList');
    if (!pendKeys.length) {
      pendList.innerHTML = '<div class="admin-empty">No pending requests</div>';
    } else {
      pendList.innerHTML = pendKeys.map(function (email) {
        var r = pend[email];
        var t = new Date(r.requestedAt).toLocaleString();
        var init = (email.charAt(0) || 'U').toUpperCase();
        return '<div class="admin-user-row">' +
          '<div class="admin-avatar-sm">' + init + '</div>' +
          '<div class="admin-user-info">' +
            '<div class="admin-user-email">' + esc(email) + '</div>' +
            '<div class="admin-user-meta">Requested: ' + t + ' · IP: ' + esc(r.ip || '—') + '</div>' +
          '</div>' +
          '<div class="admin-user-actions">' +
            '<button class="admin-btn approve" data-action="approve" data-email="' + esc(email) + '">Approve</button>' +
            '<button class="admin-btn reject" data-action="reject" data-email="' + esc(email) + '">Reject</button>' +
          '</div></div>';
      }).join('');
    }

    // Users
    var users = Auth.getUsers();
    var userKeys = Object.keys(users);
    document.getElementById('userCount').textContent = userKeys.length;
    var userList = document.getElementById('userList');
    if (!userKeys.length) {
      userList.innerHTML = '<div class="admin-empty">No users yet</div>';
    } else {
      userList.innerHTML = userKeys.map(function (email) {
        var u = users[email];
        var init = (email.charAt(0) || 'U').toUpperCase();
        return '<div class="admin-user-row">' +
          '<div class="admin-avatar-sm">' + init + '</div>' +
          '<div class="admin-user-info">' +
            '<div class="admin-user-email">' + esc(email) + '</div>' +
            '<div class="admin-user-meta">Role: ' + esc(u.role || 'user') + ' · Status: ' + esc(u.status || 'active') + '</div>' +
          '</div>' +
          '<div class="admin-user-actions">' +
            (u.status === 'banned'
              ? '<button class="admin-btn approve" data-action="unban" data-email="' + esc(email) + '">Unban</button>'
              : '<button class="admin-btn ban" data-action="ban" data-email="' + esc(email) + '">Ban</button>') +
            (u.role === 'admin'
              ? '<button class="admin-btn" data-action="demote" data-email="' + esc(email) + '">Demote</button>'
              : '<button class="admin-btn promote" data-action="promote" data-email="' + esc(email) + '">Promote</button>') +
            '<button class="admin-btn delete" data-action="delete" data-email="' + esc(email) + '">Delete</button>' +
          '</div></div>';
      }).join('');
    }

    // Bind action buttons
    document.querySelectorAll('#tab-admin [data-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var action = btn.getAttribute('data-action');
        var email = btn.getAttribute('data-email');
        var res;
        if (action === 'approve') res = Auth.approveUser(email);
        else if (action === 'reject') res = Auth.rejectUser(email);
        else if (action === 'ban') res = Auth.banUser(email);
        else if (action === 'unban') res = Auth.unbanUser(email);
        else if (action === 'delete') {
          if (!confirm('Delete user ' + email + '? They will need to re-register.')) return;
          res = Auth.deleteUser(email);
        }
        else if (action === 'promote') res = Auth.promoteUser(email);
        else if (action === 'demote') res = Auth.demoteUser(email);
        if (res && !res.ok) alert(res.error);
        renderAdminPanel();
        updateNotifBadge();
      });
    });
  }

})();
