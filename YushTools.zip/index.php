<?php
require_once __DIR__ . '/protection/bootstrap.php';
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=no">
<title>YUSH TOOLS — Control Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>

<script>
/* Critical UI helpers — load before modules so clicks never silently fail */
window.togglePwd = window.togglePwd || function (id, btn) {
  var el = document.getElementById(id);
  if (!el) return;
  var show = el.type === 'password';
  el.type = show ? 'text' : 'password';
  if (btn) {
    btn.classList.toggle('is-visible', show);
    btn.innerHTML = show
      ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
      : '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
  }
};
window.showLogin = window.showLogin || function () {
  var a=document.getElementById('authLoginView'), b=document.getElementById('authRegisterView'), c=document.getElementById('authPendingView');
  if(a)a.style.display=''; if(b)b.style.display='none'; if(c)c.style.display='none';
};
window.showRegister = window.showRegister || function () {
  var a=document.getElementById('authLoginView'), b=document.getElementById('authRegisterView'), c=document.getElementById('authPendingView');
  if(a)a.style.display='none'; if(b)b.style.display=''; if(c)c.style.display='none';
};
/* Early session restore — hide login logo flash if still logged in (1-day TTL) */
(function () {
  try {
    var KEY = '__yush_session_v2__';
    var raw = localStorage.getItem(KEY);
    if (!raw) return;
    var s = JSON.parse(raw);
    if (!s || !s.email) return;
    var exp = s.expiresAt || ((s.loginAt || 0) + 86400000);
    if (Date.now() > exp) {
      localStorage.removeItem(KEY);
      return;
    }
    document.documentElement.classList.add('yush-authed');
  } catch (e) {}
})();
</script>
<style>
/* Prevent auth flash when session is already valid */
html.yush-authed #authOverlay { display: none !important; }
html.yush-authed #mainApp { display: block !important; }
</style>
</head>
<body>
<div class="app" id="app">

  <!-- ════════════════════ AUTH GATE ════════════════════ -->
  <div class="auth-overlay" id="authOverlay">
    <div class="auth-card" id="authCard">
      <!-- Login View -->
      <div class="auth-view" id="authLoginView">
        <div class="auth-brand">
          <div class="auth-logo">Y</div>
          <div>
            <div class="auth-brand-title">YUSH TOOLS</div>
            <div class="auth-brand-sub">Sign in to continue</div>
          </div>
        </div>
        <div class="auth-field">
          <label>Email</label>
          <input type="email" id="loginEmail" placeholder="you@gmail.com" autocomplete="username" spellcheck="false">
        </div>
        <div class="auth-field">
          <label>Password</label>
          <div class="auth-input-row">
            <input type="password" id="loginPassword" placeholder="••••••••" autocomplete="current-password">
            <button type="button" class="auth-eye" data-target="loginPassword" aria-label="Toggle password"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
          </div>
        </div>
        <label class="auth-remember">
          <input type="checkbox" id="rememberMe">
          <span>Remember me</span>
        </label>
        <div class="auth-turnstile-wrap" id="loginTurnstileWrap">
          <div id="loginTurnstile"></div>
        </div>
        </div>
        <button class="btn-primary full" id="btnLogin" type="button" onclick="window.doLogin&&window.doLogin()">Sign In</button>
        <div class="auth-switch">Don't have an account? <button type="button" id="gotoRegister" onclick="window.showRegister&&window.showRegister()">Create account</button></div>
        <div class="auth-error" id="loginError"></div>
      </div>

      <!-- Register View -->
      <div class="auth-view" id="authRegisterView" style="display:none">
        <div class="auth-brand">
          <div class="auth-logo">Y</div>
          <div>
            <div class="auth-brand-title">Create Account</div>
            <div class="auth-brand-sub">Verify your email to continue</div>
          </div>
        </div>
        <div class="auth-field">
          <label>Email</label>
          <input type="email" id="regEmail" placeholder="you@gmail.com" autocomplete="username" spellcheck="false">
        </div>
        <div class="auth-field">
          <label>Password</label>
          <div class="auth-input-row">
            <input type="password" id="regPassword" placeholder="Min. 6 characters" autocomplete="new-password">
            <button type="button" class="auth-eye" data-target="regPassword" aria-label="Toggle password"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
          </div>
        </div>
        <div class="auth-field">
          <label>Confirm Password</label>
          <div class="auth-input-row">
            <input type="password" id="regPassword2" placeholder="Repeat password" autocomplete="new-password">
            <button type="button" class="auth-eye" data-target="regPassword2" aria-label="Toggle password"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
          </div>
        </div>
        <div class="auth-field">
          <label>Verification Code</label>
          <div class="auth-code-row">
            <input type="text" id="regCode" placeholder="6-digit code" autocomplete="one-time-code" spellcheck="false" inputmode="numeric" maxlength="6">
            <button type="button" class="auth-sendcode-btn" id="sendCodeBtn" onclick="window.doSendCode&&window.doSendCode()">Send code</button>
          </div>
          <div class="auth-code-status" id="codeStatus"></div>
        </div>
        <button class="btn-primary full" id="btnRegister" type="button" onclick="window.doRegister&&window.doRegister()">Sign Up</button>
        <div class="auth-switch">Already have an account? <button type="button" id="gotoLogin" onclick="window.showLogin&&window.showLogin()">Sign in</button></div>
        <div class="auth-error" id="regError"></div>
      </div>

      <!-- Pending Approval View -->
      <div class="auth-view" id="authPendingView" style="display:none">
        <div class="auth-brand">
          <div class="auth-logo pending">⏳</div>
          <div>
            <div class="auth-brand-title">Awaiting Approval</div>
            <div class="auth-brand-sub">Your request is being reviewed</div>
          </div>
        </div>
        <p class="auth-pending-msg">Your account registration has been submitted. The owner will review and approve or reject it shortly. You can close this page — status will update automatically when you return.</p>
        <div class="auth-pending-email" id="pendingEmailDisplay">—</div>
        <button class="btn-secondary" id="btnCancelPending" onclick="window.cancelPending&&window.cancelPending()" type="button">Cancel Request</button>
      </div>
    </div>
  </div>

  <!-- ════════════════════ MAIN APP ════════════════════ -->
  <div class="main-app" id="mainApp" style="display:none">

    <!-- Top Bar (matches reference image 1) -->
    <header class="topbar">
      <button class="topbar-burger" id="btnBurger" type="button" aria-label="Menu">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
          <line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/>
        </svg>
      </button>
      <div class="topbar-title" id="topbarTitle">Offset Updater</div>
      <div class="topbar-actions">
        <button class="icon-btn" id="btnNotif" type="button" title="Notifications" aria-label="Notifications">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          <span class="notif-badge" id="notifBadge" style="display:none">0</span>
        </button>
        <button class="icon-btn" id="btnTheme" type="button" title="Toggle theme" aria-label="Theme">
          <svg class="theme-icon-dark" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
          <svg class="theme-icon-light" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" style="display:none"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
        </button>
        <button class="profile-avatar" id="btnProfile" type="button" title="Profile" aria-label="Profile">Y</button>
      </div>
    </header>

    <!-- Side Drawer (matches reference image 3) -->
    <div class="drawer-overlay" id="drawerOverlay"></div>
    <aside class="drawer" id="drawer">
      <div class="drawer-header">
        <div class="drawer-brand">
          <div class="drawer-logo">Y</div>
          <div>
            <div class="drawer-title">YUSH TOOLS</div>
            <div class="drawer-sub">Control Panel</div>
          </div>
        </div>
        <button class="drawer-close" id="btnDrawerClose" type="button" aria-label="Close">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="drawer-section-label">WORKSPACE</div>
      <nav class="drawer-nav" id="drawerNav">
        <button class="drawer-item active" data-tab="dashboard">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
          <span>Dashboard</span>
        </button>
        <button class="drawer-item" data-tab="updater">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9H3m9 9a9 9 0 0 1-9-9m9 9c1.66 0 3-4.03 3-9s-1.34-9-3-9m0 18c-1.66 0-3-4.03-3-9s1.34-9 3-9m-9 9a9 9 0 0 1 9-9"/></svg>
          <span>Offset Updater</span>
        </button>
        <button class="drawer-item" data-tab="finder">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <span>Offset Finder</span>
        </button>
        <button class="drawer-item" data-tab="converter">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>
          <span>Bypass Formatting</span>
        </button>
        <button class="drawer-item" data-tab="developer">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
          <span>Developer</span>
        </button>
        <button class="drawer-item" data-tab="settings">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
          <span>Settings</span>
        </button>
        <!-- Admin Panel – only visible for owner -->
        <button class="drawer-item admin-only" data-tab="admin" style="display:none">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          <span>Admin Panel</span>
        </button>
      </nav>
      <div class="drawer-footer">
        <button class="drawer-logout" id="btnLogout" type="button">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Log out
        </button>
      </div>
    </aside>

    <!-- Profile Popover (matches reference image 2) -->
    <div class="profile-popover" id="profilePopover" style="display:none">
      <div class="profile-popover-header">
        <div class="profile-popover-avatar" id="popoverAvatar">Y</div>
        <div>
          <div class="profile-popover-label">SIGNED IN ACCOUNT</div>
          <div class="profile-popover-name" id="popoverName">—</div>
          <div class="profile-popover-handle" id="popoverHandle">@—</div>
        </div>
      </div>
      <div class="profile-popover-meta">
        <div class="profile-meta-row"><span>Role</span><span id="popoverRole">User</span></div>
        <div class="profile-meta-row"><span>Account status</span><span class="status-active" id="popoverStatus">Active</span></div>
        <div class="profile-meta-row"><span>Account expiry</span><span id="popoverExpiry">Never</span></div>
      </div>
      <button class="profile-manage-btn" id="btnManageAccount" type="button">
        Manage account
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </button>
    </div>

    <!-- Notification dropdown -->
    <div class="notif-dropdown" id="notifDropdown" style="display:none">
      <div class="notif-header-row">
        <div>
          <div class="notif-kicker">WORKSPACE FEED</div>
          <div class="notif-header">Notifications</div>
        </div>
        <div class="notif-header-actions">
          <span class="notif-count-pill" id="notifCountPill">0</span>
          <button type="button" class="notif-mark-btn" id="btnMarkNotifsRead">Mark all as read</button>
        </div>
      </div>
      <div class="notif-list" id="notifList">
        <div class="notif-empty">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
          <div>No Notification</div>
        </div>
      </div>
      <button type="button" class="notif-footer-btn" id="btnNotifOpenDash">Open dashboard
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
      </button>
    </div>

    <!-- ════════ CONTENT PANELS ════════ -->
    <main class="content" id="content">

      <!-- ── TAB 1: Offset Updater ── -->
      
      <!-- ── TAB: Dashboard ── -->
      <section class="tab-panel active" id="tab-dashboard">
        <div class="dash-welcome card">
          <div class="dash-welcome-text">
            <h2 id="dashWelcome">Welcome back</h2>
            <p>Review workspace activity and continue your latest update workflow.</p>
          </div>
          <button type="button" class="dash-play-btn" id="btnDashGoUpdater" title="Open Updater">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><polygon points="8 5 20 12 8 19 8 5"/></svg>
          </button>
        </div>
        <div class="dash-stats">
          <div class="dash-stat"><div class="dash-stat-icon ds-dump"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg></div><div><div class="dash-stat-lbl">DUMP PACKAGES</div><div class="dash-stat-val" id="dashDumps">0</div></div></div>
          <div class="dash-stat"><div class="dash-stat-icon ds-acc"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></div><div><div class="dash-stat-lbl">ACCOUNTS</div><div class="dash-stat-val" id="dashAccounts">0</div></div></div>
          <div class="dash-stat"><div class="dash-stat-icon ds-ok"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div><div><div class="dash-stat-lbl">COMPLETED</div><div class="dash-stat-val" id="dashCompleted">0</div></div></div>
          <div class="dash-stat"><div class="dash-stat-icon ds-rev"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div><div><div class="dash-stat-lbl">NEEDS REVIEW</div><div class="dash-stat-val" id="dashReview">0</div></div></div>
        </div>
        <div class="card dash-card">
          <div class="dash-card-head"><span class="dash-kicker">WORKSPACE HEALTH</span><span class="dash-live">Live</span></div>
          <h3>Asset mix</h3>
          <div class="dash-ring-wrap">
            <svg viewBox="0 0 120 120" width="140" height="140" class="dash-ring">
              <circle cx="60" cy="60" r="48" fill="none" stroke="rgba(139,92,246,0.15)" stroke-width="12"/>
              <circle cx="60" cy="60" r="48" fill="none" stroke="#8b5cf6" stroke-width="12" stroke-dasharray="200 301" stroke-linecap="round" transform="rotate(-90 60 60)"/>
              <circle cx="60" cy="60" r="48" fill="none" stroke="#22d3ee" stroke-width="12" stroke-dasharray="80 301" stroke-dashoffset="-200" stroke-linecap="round" transform="rotate(-90 60 60)"/>
              <text x="60" y="58" text-anchor="middle" fill="currentColor" font-size="22" font-weight="700" id="dashTracked">0</text>
              <text x="60" y="74" text-anchor="middle" fill="#9aa8b8" font-size="9">Tracked offsets</text>
            </svg>
          </div>
          <div class="dash-legend">
            <div><span class="dot purple"></span> RVA offsets <b id="dashRva">0</b></div>
            <div><span class="dot cyan"></span> Field offsets <b id="dashField">0</b></div>
            <div><span class="dot gray"></span> Dump packages <b id="dashPkg">0</b></div>
          </div>
        </div>
        <div class="card dash-card">
          <div class="dash-card-head"><span class="dash-kicker">UPDATE PIPELINE</span><span class="dash-chip">All time</span></div>
          <h3>Job completion</h3>
          <div class="dash-pct" id="dashSuccess">100%</div>
          <div class="dash-bar"><div class="dash-bar-fill" style="width:100%"></div></div>
          <div class="dash-legend">
            <div><span class="dot green"></span> Completed <b id="dashJobsOk">0</b></div>
            <div><span class="dot red"></span> Needs review <b id="dashJobsRev">0</b></div>
            <div><span class="dot gray"></span> Total jobs <b id="dashJobsTotal">0</b></div>
          </div>
        </div>

        <div class="card dash-card">
          <div class="dash-card-head"><span class="dash-kicker">COVERAGE SNAPSHOT</span><span class="dash-chip">Current</span></div>
          <h3>Version readiness</h3>
          <div class="dash-ring-wrap">
            <svg viewBox="0 0 120 120" width="140" height="140" class="dash-ring">
              <circle cx="60" cy="60" r="48" fill="none" stroke="rgba(34,211,238,0.12)" stroke-width="12"/>
              <circle id="dashReadyRing" cx="60" cy="60" r="48" fill="none" stroke="#22d3ee" stroke-width="12" stroke-dasharray="235 301" stroke-linecap="round" transform="rotate(-90 60 60)"/>
              <text x="60" y="58" text-anchor="middle" fill="currentColor" font-size="22" font-weight="700" id="dashReadyPct">78%</text>
              <text x="60" y="74" text-anchor="middle" fill="#9aa8b8" font-size="9">Ready to update</text>
            </svg>
          </div>
          <div class="dash-legend">
            <div><span class="dot purple"></span> Latest package <b id="dashLatestPkg">Ready</b></div>
            <div><span class="dot cyan"></span> Active users <b id="dashActiveUsers">0</b></div>
            <div><span class="dot" style="background:#f59e0b"></span> Next action <b id="dashNextAction">Update</b></div>
          </div>
        </div>
        <div class="card dash-card">
          <div class="dash-card-head"><span class="dash-kicker">TREND LINE</span><span class="dash-chip">Recent</span></div>
          <h3>Update pulse</h3>
          <div class="dash-pulse-wrap">
            <svg viewBox="0 0 320 100" width="100%" height="100" preserveAspectRatio="none" class="dash-pulse">
              <defs>
                <linearGradient id="pulseFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="rgba(139,92,246,0.35)"/>
                  <stop offset="100%" stop-color="rgba(139,92,246,0)"/>
                </linearGradient>
              </defs>
              <path d="M0,80 C40,70 60,40 90,50 S140,20 170,35 S230,70 260,40 S300,20 320,15 L320,100 L0,100 Z" fill="url(#pulseFill)"/>
              <path d="M0,80 C40,70 60,40 90,50 S140,20 170,35 S230,70 260,40 S300,20 320,15" fill="none" stroke="#8b5cf6" stroke-width="2.5"/>
            </svg>
          </div>
          <div class="dash-pulse-meta">
            <b id="dashPulseCount">0 completed updates</b>
            <p>Keep the latest dump ready for the next release cycle.</p>
          </div>
        </div>

      </section>


      <!-- ── TAB: Offset Updater (version-based) ── -->
      <section class="tab-panel" id="tab-updater">

        <section class="step-card no-glow">
          <div class="step-header">
            <div class="step-num">1</div>
            <div class="step-info">
              <h3>Choose Old dump</h3>
              <p>Select the old dump used by your current source.</p>
            </div>
          </div>
          <div class="version-grid" id="oldVersionGrid">
            <div class="version-empty">Loading versions…</div>
          </div>

          <div class="to-version-field" style="margin-top:14px">
            <label>Select Latest Version</label>
            <select id="latestVersionSelect">
              <option value="1.6.56">Garena 1.6.56</option>
              <option value="1.6.57">Garena 1.6.57</option>
            </select>
          </div>
        </section>

        <section class="step-card no-glow">
          <div class="step-header">
            <div class="step-num">2</div>
            <div class="step-info">
              <h3>Upload source files</h3>
              <p>Choose one or more source files that need updated offsets.</p>
            </div>
          </div>
          <div class="upload-zone" id="sourceDropZone">
            <div class="upload-zone-icon">
              <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div>
            <div class="upload-zone-title">Choose source files</div>
            <div class="source-file-list" id="sourceFileList"></div>
            <div class="upload-zone-sub">CPP, H, HPP, or C files. Choose files together or add them one at a time.</div>
            <button type="button" class="upload-zone-btn" onclick="document.getElementById('f-sources').click()">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
              Choose or add files
            </button>
            <input type="file" id="f-sources" accept=".h,.hpp,.c,.cpp,.cc,.cs,.txt,*" multiple hidden>
          </div>
          <p class="step-hint secure-hint">
            <svg class="secure-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            <span>Your file is only used to generate this update.</span>
          </p>
        </section>

        <section class="step-card no-glow">
          <div class="step-header">
            <div class="step-num">3</div>
            <div class="step-info">
              <h3>Run updater</h3>
              <p>Review the selection before processing.</p>
            </div>
          </div>
          <div class="run-summary-box">
            <div class="run-sum-grid">
              <div class="run-sum-item from">
                <div class="run-sum-lbl">FROM VERSION</div>
                <div class="run-sum-val" id="runFromVer">—</div>
              </div>
              <div class="run-sum-item to">
                <div class="run-sum-lbl">TO VERSION</div>
                <div class="run-sum-val to" id="runToVer">—</div>
              </div>
              <div class="run-sum-item file">
                <div class="run-sum-lbl">FILE</div>
                <div class="run-sum-val" id="runFileName">No file selected</div>
              </div>
            </div>
          </div>
          <button class="btn-execute" id="btnExec" type="button" disabled>
            <div class="btn-execute-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            </div>
            <div class="btn-execute-text">
              <span class="btn-execute-title" id="btnLabel">Run Updater</span>
              <span class="btn-execute-sub">Compare and synchronize offsets</span>
            </div>
          </button>
          <div class="progress-wrap" id="progressWrap">
            <div class="progress-bar-bg"><div class="progress-bar-fill" id="progressFill"></div></div>
          </div>
        </section>

        <section class="summary-card" id="statsRow">
          <div class="summary-header">
            <div class="summary-title">
              <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="4" y1="20" x2="4" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="20" y1="20" x2="20" y2="14"/></svg>
              Update Summary
            </div>
            <div class="summary-pills" id="summaryPills">
              <span class="pill active" data-pill="ready"><i></i>Ready</span>
              <span class="pill" data-pill="processing"><i></i>Processing</span>
              <span class="pill" data-pill="completed"><i></i>Completed</span>
              <span class="pill" data-pill="error"><i></i>Error</span>
            </div>
          </div>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon si-same"><svg viewBox="0 0 24 24" width="14" height="14" fill="#fff" stroke="none"><polygon points="12 2 15 9 22 9.5 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9.5 9 9"/></svg></div>
              <div class="stat-body"><div class="stat-lbl">Already Latest</div><div class="stat-val" id="ssame">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon si-ok"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
              <div class="stat-body"><div class="stat-lbl">Updated</div><div class="stat-val" id="sok">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon si-fail"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div>
              <div class="stat-body"><div class="stat-lbl">Failed</div><div class="stat-val" id="sfail">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon si-ign"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.4"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.4" fill="#fff" stroke="none"/></svg></div>
              <div class="stat-body"><div class="stat-lbl">Ignored</div><div class="stat-val" id="sign">0</div></div>
            </div>
          </div>
          <div class="stat-total-row">Total detected: <b id="st">0</b></div>
        </section>

        <div class="dl-wrap" id="dlWrap" style="display:none">
          <button class="btn-dl" id="btnDownload" type="button">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Download ZIP
          </button>
        </div>
        <div class="results-wrap" id="resultsWrap" style="display:none">
          <div id="sec-updated" style="display:none">
            <div class="section-header">
              <div class="section-title" style="color:var(--green)">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> Updated
              </div>
              <div class="section-header-line"></div>
              <span id="sc-updated" class="section-count"></span>
            </div>
            <div id="cards-updated"></div>
          </div>
        </div>
      </section>

      <!-- ── TAB 2: Offset Finder ── -->
      <section class="tab-panel" id="tab-finder">
        <div class="section-head">
          <h2 class="section-title">Offset Finder</h2>
          <p class="section-sub">Search inside dump.cs for methods, fields, and offsets</p>
        </div>

        <div class="card">
          <div class="file-row">
            <div class="finder-path-display" id="finderPathDisplay">No file loaded</div>
            <button class="btn-browse" type="button" onclick="window.loadFinderFile?window.loadFinderFile():document.getElementById('finderInput').click()">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
              Load
            </button>
            <input type="file" id="finderInput" accept=".cs,.txt,*" hidden>
          </div>
        </div>

        <div class="card">
          <div class="search-row">
            <input class="search-input" id="finderSearch" placeholder="Enter method name, class, or offset (0x...)" autocomplete="off" spellcheck="false">
            <button class="btn-primary" id="btnFind" type="button" onclick="window.doFind&&window.doFind()">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Find
            </button>
          </div>
          <div class="filter-chip-row">
            <button class="filter-chip active" data-filter="all" type="button">All</button>
            <button class="filter-chip" data-filter="methods" type="button">Methods</button>
            <button class="filter-chip" data-filter="fields" type="button">Fields</button>
          </div>
        </div>

        <section class="summary-card" id="finderSummaryCard">
          <div class="summary-header">
            <div class="summary-title">
              <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Find Summary
            </div>
            <div class="summary-pills" id="findStatusRow">
              <span class="pill active" data-st="ready"><i></i>Ready</span>
              <span class="pill" data-st="searching"><i></i>Searching</span>
              <span class="pill" data-st="done"><i></i>Done</span>
              <span class="pill" data-st="empty"><i></i>No match</span>
            </div>
          </div>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon si-ok" style="background:linear-gradient(135deg,#3b82f6,#2563eb)">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </div>
              <div class="stat-body"><div class="stat-lbl">Matches</div><div class="stat-val" id="finderStatFound">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background:linear-gradient(135deg,#8b5cf6,#6d28d9)">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.5"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
              </div>
              <div class="stat-body"><div class="stat-lbl">Methods</div><div class="stat-val" id="finderStatMethods">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background:linear-gradient(135deg,#22d3ee,#0891b2)">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.5"><path d="M4 7h16M4 12h10M4 17h7"/></svg>
              </div>
              <div class="stat-body"><div class="stat-lbl">Fields</div><div class="stat-val" id="finderStatFields">0</div></div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#d97706)">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
              </div>
              <div class="stat-body"><div class="stat-lbl">Indexed</div><div class="stat-val" id="finderStatIndexed">0</div></div>
            </div>
          </div>
          <div class="finder-summary-meta" style="margin-top:12px;font-size:12px;color:var(--text3);text-align:center">
            Query: <b id="finderSummaryQuery">—</b>
          </div>
        </section>
        <div class="finder-results" id="finderResultsWrap" style="display:none">
          <div class="section-header">
            <div class="section-title" style="color:var(--cyan)">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Results
            </div>
            <div class="section-header-line"></div>
            <span id="finderResultCount" class="section-count"></span>
          </div>
          <div id="finderResultCards"></div>
        </div>
        <div class="finder-empty" id="finderEmptyHint">Load a dump.cs and search to see results here.</div>
      </section>

      <!-- ── TAB 3: Bypass Formatting ── -->
      <section class="tab-panel" id="tab-converter">
        <div class="section-head">
          <h2 class="section-title">Bypass Formatting</h2>
          <p class="section-sub">Generate bypass / hook formats from offsets</p>
        </div>

        <div class="card bp-input-card">
          <div class="auth-field">
            <label>LIBRARY</label>
            <input type="text" id="bpLibrary" value="libanogs.so" spellcheck="false" autocomplete="off" placeholder="libanogs.so">
          </div>
          <div class="auth-field">
            <label>HEX PATCH</label>
            <input type="text" id="bpHex" value="00 00 80 D2 C0 03 5F D6" spellcheck="false" autocomplete="off" placeholder="00 00 80 D2 C0 03 5F D6">
          </div>
          <div class="auth-field">
            <label>OFFSETS</label>
            <textarea id="bpOffsets" class="bp-offsets-ta" rows="5" spellcheck="false" placeholder="Paste your offset here&#10;0x4E3E9D4"></textarea>
            <div class="bp-hint">One offset per line · 0x prefix optional</div>
          </div>
          <button class="btn-primary full" type="button" id="btnBpGenerate">Generate Formats</button>
        </div>

        <div id="bpResults" class="bp-results" style="display:none"></div>
      </section>

      <!-- ── TAB 4: Developer ── -->
      <section class="tab-panel" id="tab-developer">
        <div class="section-head">
          <h2 class="section-title">Developer</h2>
          <p class="section-sub">About this tool</p>
        </div>

        <div class="dev-card">
          <div class="dev-avatar"><img src="assets/banner.png" alt="YUSH TOOLS" class="dev-avatar-img" onerror="this.style.display='none'"></div>
          <div class="dev-role">Developer of YUSH TOOLS</div>
          <a class="dev-handle" href="https://t.me/PrimeYush" target="_blank" rel="noopener">
            <svg width="17" height="17" viewBox="0 0 240 240" fill="currentColor"><circle cx="120" cy="120" r="120" fill="#29a9eb"/><path d="M180 72l-19 92c-1.4 6.4-5.2 8-10.6 5l-29-21.4-14 13.5c-1.6 1.6-2.9 2.9-5.9 2.9l2.1-30 55-49.7c2.4-2.1-.5-3.3-3.7-1.2l-68 42.8-29.3-9.2c-6.4-2-6.5-6.4 1.3-9.5l114.6-44.2c5.3-2 10 1.3 8.5 9z" fill="#fff"/></svg>
            <span>@PrimeYush</span>
          </a>
        </div>

        <div class="settings-section-title">Partners</div>
        <div class="partner-list">
          <a class="partner-row" href="https://t.me/zh4cks" target="_blank" rel="noopener">
            <span class="partner-avatar"><img src="assets/zhack.png" alt="@zh4cks" class="partner-avatar-img"></span>
            <div class="partner-info">
              <div class="partner-label">Partner</div>
              <div class="partner-handle">@zh4cks</div>
            </div>
            <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
          <a class="partner-row" href="https://t.me/NullHynn" target="_blank" rel="noopener">
            <span class="partner-avatar"><img src="assets/hynn.png" alt="@NullHynn" class="partner-avatar-img"></span>
            <div class="partner-info">
              <div class="partner-label">Partner</div>
              <div class="partner-handle">@NullHynn</div>
            </div>
            <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
        </div>

        <div class="settings-section-title">Social Platforms</div>
        <div class="link-list">
          <a class="link-row" href="https://t.me/NocturneTeamChannel" target="_blank" rel="noopener">
            <span class="link-ic ic-tg">
              <svg width="16" height="16" viewBox="0 0 240 240" fill="#fff"><path d="M180 72l-19 92c-1.4 6.4-5.2 8-10.6 5l-29-21.4-14 13.5c-1.6 1.6-2.9 2.9-5.9 2.9l2.1-30 55-49.7c2.4-2.1-.5-3.3-3.7-1.2l-68 42.8-29.3-9.2c-6.4-2-6.5-6.4 1.3-9.5l114.6-44.2c5.3-2 10 1.3 8.5 9z"/></svg>
            </span>
            <div><div class="link-title">Telegram Channel</div><div class="link-sub">@NocturneTeamChannel</div></div>
            <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
          <a class="link-row" href="https://www.tiktok.com/@primeyush?_r=1&_t=ZS-99fofnYa3n7" target="_blank" rel="noopener">
            <span class="link-ic ic-tiktok">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>
            </span>
            <div><div class="link-title">TikTok</div><div class="link-sub">@primeyush</div></div>
            <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
          <a class="link-row" href="https://www.youtube.com/@PrimeYush" target="_blank" rel="noopener">
            <span class="link-ic ic-youtube">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M23.5 6.2a3 3 0 00-2.1-2.1C19.6 3.5 12 3.5 12 3.5s-7.6 0-9.4.6A3 3 0 00.5 6.2 31 31 0 000 12a31 31 0 00.5 5.8 3 3 0 002.1 2.1c1.8.6 9.4.6 9.4.6s7.6 0 9.4-.6a3 3 0 002.1-2.1A31 31 0 0024 12a31 31 0 00-.5-5.8zM9.6 15.5v-7l6.3 3.5-6.3 3.5z"/></svg>
            </span>
            <div><div class="link-title">YouTube</div><div class="link-sub">@PrimeYush</div></div>
            <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
        </div>

        <div class="settings-section-title">Legal</div>
        <div class="link-list">
        </div>
      </section>

      <!-- ── TAB 5: Settings ── -->
      <section class="tab-panel" id="tab-settings">
        <div class="section-head">
          <h2 class="section-title">Settings</h2>
          <p class="section-sub">Manage your account and preferences</p>
        </div>

        <!-- Change Password (matches image 4) -->
        <div class="card settings-card">
          <div class="settings-card-head">
            <div class="settings-icon lock">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            </div>
            <div>
              <div class="settings-card-title">Change Password</div>
              <div class="settings-card-sub">Security</div>
            </div>
          </div>
          <div class="auth-field">
            <label>CURRENT PASSWORD</label>
            <div class="auth-input-row">
              <input type="password" id="setCurPass" placeholder="Current Password">
              <button type="button" class="auth-eye" data-target="setCurPass"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
            </div>
          </div>
          <div class="auth-field">
            <label>NEW PASSWORD</label>
            <div class="auth-input-row">
              <input type="password" id="setNewPass" placeholder="New Password">
              <button type="button" class="auth-eye" data-target="setNewPass"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
            </div>
          </div>
          <div class="auth-field">
            <label>CONFIRM PASSWORD</label>
            <div class="auth-input-row">
              <input type="password" id="setConfirmPass" placeholder="Confirm Password">
              <button type="button" class="auth-eye" data-target="setConfirmPass"><svg class="eye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><svg class="eye-off" style="display:none" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg></button>
            </div>
          </div>
          <button class="btn-primary full" id="btnChangePass" type="button">Change Password</button>
          <div class="auth-error" id="passError"></div>
        </div>

        <!-- Email Information -->
        <div class="card settings-card">
          <div class="settings-card-head">
            <div class="settings-icon mail">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            </div>
            <div>
              <div class="settings-card-title">Email Information</div>
              <div class="settings-card-sub" id="settingsEmailDisplay">—</div>
            </div>
          </div>
          <div class="auth-field">
            <label>EMAIL</label>
            <input type="email" id="setEmailField" placeholder="Enter new email" autocomplete="off" spellcheck="false">
          </div>
          <button class="btn-primary full" id="btnUpdateAccount" type="button">Change Email Account</button>
          <div class="auth-error" id="accountError"></div>
        </div>

        <!-- Updater Preferences -->
        <div class="card settings-card">
          <div class="settings-card-head">
            <div class="settings-icon gear">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
            </div>
            <div>
              <div class="settings-card-title">Updater Preferences</div>
              <div class="settings-card-sub">Pipeline options</div>
            </div>
          </div>
          <label class="toggle-row">
            <span>Auto-download result ZIP</span>
            <input type="checkbox" id="setAutoDownload">
            <span class="toggle-track"></span>
          </label>
          <label class="toggle-row">
            <span>Click-to-copy hex values</span>
            <input type="checkbox" id="setCopyEnabled" checked>
            <span class="toggle-track"></span>
          </label>
        </div>
      </section>

      <!-- ── TAB 6: Admin Panel (owner only) ── -->
      <section class="tab-panel" id="tab-admin">
        <div class="section-head">
          <h2 class="section-title">Admin Panel</h2>
          <p class="section-sub">User management, approvals & security</p>
        </div>

        <!-- Pending Approvals -->
        
        <div class="card admin-card">
          <div class="admin-card-head">
            <div class="admin-head-left"><div class="admin-icon users">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div><div><h3>Upload Old Dump</h3><p class="admin-sub">Permanent dump links for users</p></div></div>
          </div>
          <div class="auth-field"><label>VERSION</label>
            <select id="adminOldVer"><option value="1.6.50">Garena 1.6.50</option><option value="1.6.51">Garena 1.6.51</option><option value="1.6.52">Garena 1.6.52</option><option value="1.6.53">Garena 1.6.53</option><option value="1.6.54">Garena 1.6.54</option><option value="1.6.55">Garena 1.6.55</option><option value="1.6.56">Garena 1.6.56</option></select>
          </div>
          <div class="auth-field"><label>DUMP LINK</label>
            <input type="url" id="adminOldLink" placeholder="https://www.mediafire.com/file/xxxxx/dump.cs" spellcheck="false" autocomplete="off">
            <div class="bp-hint">Paste MediaFire/Gofile/direct link. Server downloads the .cs and stores it permanently under dumps/.</div>
          </div>
          <button class="btn-primary full" type="button" id="btnUploadOldDump" onclick="window.uploadOldDump&&window.uploadOldDump()">Save Old Dump Link</button>
          <div class="auth-error" id="adminOldErr"></div>
        </div>
        <div class="card admin-card">
          <div class="admin-card-head">
            <div class="admin-head-left"><div class="admin-icon pending">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div><div><h3>Upload New Dump</h3><p class="admin-sub">Latest dump per version (via link)</p></div></div>
          </div>
          <div class="auth-field"><label>VERSION</label>
            <select id="adminNewVer"><option value="1.6.56">Garena 1.6.56</option><option value="1.6.57">Garena 1.6.57</option></select>
          </div>
          <div class="auth-field"><label>DUMP LINK</label>
            <input type="url" id="adminNewLink" placeholder="https://www.mediafire.com/file/xxxxx/dump.cs" spellcheck="false" autocomplete="off">
            <div class="bp-hint">Server downloads & caches the file. Survives site updates. Changing the link re-downloads.</div>
          </div>
          <button class="btn-primary full" type="button" id="btnUploadNewDump" onclick="window.uploadNewDump&&window.uploadNewDump()">Save New Dump Link</button>
          <div class="auth-error" id="adminNewErr"></div>
        </div>
<div class="card admin-card">
          <div class="admin-card-head">
            <div class="admin-head-left"><div class="admin-icon pending"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div><h3>Pending Approvals</h3><p class="admin-sub">Users waiting for access</p></div></div>
            <span class="badge" id="pendingCount">0</span>
          </div>
          <div class="admin-list" id="pendingList">
            <div class="admin-empty">No pending requests</div>
          </div>
        </div>

        <!-- Registered Users -->
        <div class="card admin-card">
          <div class="admin-card-head">
            <div class="admin-head-left"><div class="admin-icon users"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></div><div><h3>Registered Users</h3><p class="admin-sub">Manage roles &amp; access</p></div></div>
            <span class="badge" id="userCount">0</span>
          </div>
          <div class="admin-list" id="userList">
            <div class="admin-empty">No users yet</div>
          </div>
        </div>

        <!-- Attack Attempts -->
        <div class="card admin-card">
          <div class="admin-card-head">
            <div class="admin-head-left"><div class="admin-icon attacks"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div><div><h3>Attack Attempts</h3><p class="admin-sub">Failed logins &amp; threats</p></div></div>
            <span class="badge danger" id="attackCount">0</span>
          </div>
          <div class="admin-list" id="attackList">
            <div class="admin-empty">No attack attempts recorded</div>
          </div>
        </div>
      </section>

    </main>
  </div>
</div>


      <!-- ── TAB: Terms of Service ── -->
      <section class="tab-panel" id="tab-terms">
        <div class="legal-panel">
          <p class="legal-page-sub">Usage terms for YUSH TOOLS</p>
          <div class="legal-body" id="termsBody"></div>
        </div>
      </section>

      <!-- ── TAB: Privacy Policy ── -->
      <section class="tab-panel" id="tab-privacy">
        <div class="legal-panel">
          <p class="legal-page-sub">How your files and data are handled</p>
          <div class="legal-body" id="privacyBody"></div>
        </div>
      </section>

<!-- Legal Modal (Terms of Service / Privacy Policy) -->

<script src="js/protection.js"></script>
<script src="js/auth.js"></script>
<script src="js/finder.js"></script>
<script src="js/formatting.js"></script>
<script src="js/main.js"></script>
</body>
</html>
