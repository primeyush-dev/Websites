<?php
/**
 * Soft protection bootstrap — never blank the page on shared hosting glitches.
 */
try {
    require_once __DIR__ . '/security.php';
    if (function_exists('yush_run_security_guard')) {
        yush_run_security_guard();
    }
} catch (Throwable $e) {
    // Log only — continue serving the app
    error_log('YUSH security bootstrap: ' . $e->getMessage());
}
