<?php
/**
 * YUSH UPDATER defensive security configuration.
 * Protection only: no external human-verification dependency.
 */
return [
    // Rate limits: requests per rolling window.
    'rate_limits' => [
        'default' => ['limit' => 120, 'window' => 60],
        'login' => ['limit' => 12, 'window' => 300],
        'register' => ['limit' => 6, 'window' => 600],
        'api' => ['limit' => 60, 'window' => 60],
        'expensive' => ['limit' => 12, 'window' => 60],
        'head' => ['limit' => 30, 'window' => 60],
        // Short, hard window checked on every request before the per-bucket
        // limit above. Per-minute limits alone are too slow to react to an
        // actual flood — a bad actor can burn the whole minute's budget in a
        // couple of seconds. This catches that burst regardless of which
        // endpoint it's aimed at.
        'burst' => ['limit' => 25, 'window' => 5],
        // Chunked dump uploads are EXPECTED to fire many rapid POSTs at the
        // same endpoint (1MB per request) — a 300MB dump is 300 requests.
        // Generous on purpose; still capped so someone can't abuse the
        // endpoint itself, just not at the cost of legitimate large uploads.
        'chunk_upload' => ['limit' => 1000, 'window' => 120],
    ],

    // Anti-clone / anti-dump: a real visitor requests a handful of distinct
    // pages/assets. A tool cloning or scraping the whole site (HTTrack,
    // wget -r, a custom dumper, etc.) requests many DIFFERENT paths in a
    // short window even if it rotates its user agent to dodge the bot list
    // above. Track distinct paths per IP and block once that count is
    // clearly beyond normal browsing.
    'crawl_guard' => [
        'enabled' => true,
        'window' => 30,
        'distinct_path_limit' => 35,
    ],

    // Temporary block after repeated rate-limit hits.
    'abuse' => [
        'block_after' => 4,
        'block_window' => 900,
        'block_seconds' => 900,
    ],

    // Maximum request body size enforced by the guard.
    // No application request-size ceiling. This site processes selected files locally;
    // uploaded HTTP bodies are not used by the updater. CDN/WAF limits should be
    // configured separately for public endpoints.
    'max_content_length' => 0,
    // Query strings are cheap to cap and help reject oversized parser abuse.
    'max_query_length' => 8192,

    // Leave empty on hosts where the same site is served from multiple hostnames.
    'allowed_hosts' => [],

    // Only trust proxy headers when the immediate client is a trusted proxy.
    // Add your actual reverse-proxy/CDN IP ranges before enabling.
    'trusted_proxies' => [],

    // Explicit allow/block lists. Use exact IPs only.
    'allow_ips' => [],
    'block_ips' => [],

    // Keep bot filtering conservative to avoid breaking legitimate browsers.
    'bot_detection' => [
        'enabled' => true,
        'score_block' => 16,
        'block_scripted_without_browser_headers' => true,
    ],

    // Security logging.
    'logging' => [
        'enabled' => true,
        // Structured JSON-lines log that the Admin Panel's "Suspicious
        // Activity" dashboard reads from (api/security-events.php). Lives
        // under protection/, which the root .htaccess already blocks from
        // direct web access.
        'file' => __DIR__ . '/logs/security.log',
    ],

    // Send HSTS only when HTTPS is guaranteed on the whole domain.
    'hsts' => true,

    // Cloudflare Turnstile (login CAPTCHA). The secret key is server-side only —
    // it must never be sent to the browser or committed to a public repo.
    'turnstile' => [
        'site_key'   => '0x4AAAAAAEvFlouUrYi5Y6Tj',
        'secret_key' => '0x4AAAAAAEvFli9IEO0repZIpeWqKH6m24k',
        'verify_url' => 'https://challenges.cloudflare.com/turnstile/v0/siteverify',
    ],

    // Known crawler / SEO-bot / archiver signatures to hard-block outright.
    // This site's robots.txt disallows everything, so there is no reason to
    // let compliant-but-unwanted crawlers (or the many that ignore robots.txt)
    // through at all. This list is intentionally separate from the generic
    // scripted-client markers in yush_bot_score() so it can be tuned freely.
    'blocked_bot_signatures' => [
        // SEO / marketing crawlers
        'ahrefsbot','semrushbot','mj12bot','dotbot','blexbot','rogerbot',
        'seznambot','megaindex','serpstatbot','dataforseobot','barkrowler',
        // AI training / AI-answer crawlers
        'gptbot','chatgpt-user','ccbot','anthropic-ai','claudebot','claude-web',
        'bytespider','petalbot','diffbot','omgili','timpibot','youbot','ai2bot',
        'meta-externalagent','applebot-extended','amazonbot','imagesiftbot',
        // Generic site cloning / offline-mirroring tools
        'httrack','webcopier','webzip','teleport','black widow','webreaper',
        'siteshoter','sitesnagger','webstripper','pavuk','larbin','wget','curl/',
    ],

    // Payload signatures checked against the request URI, query string, and
    // (for form/json requests) the raw POST body. Conservative substring
    // matches only — this is a lightweight defense-in-depth net, not a
    // replacement for parameterized queries / output escaping in app code.
    'attack_signatures' => [
        // SQL injection
        'union select','union all select',"' or '1'='1","or 1=1--",'sleep(',
        'benchmark(','information_schema','xp_cmdshell','into outfile',
        // XSS / HTML injection
        '<script','javascript:','onerror=','onload=','<svg/onload',
        // Path traversal / LFI
        '../','..%2f','/etc/passwd','boot.ini','win.ini',
        // RCE / code execution
        'phpinfo(','eval(','base64_decode(','system(','exec(','passthru(',
        'shell_exec(','${jndi:','proc_open(',
        // Common exploit probes
        'wp-config.php','.env','/.git/','/.aws/credentials',
    ],

    // Hidden honeypot field for the login form. A human never sees or fills
    // this field ('website' — an unrelated-sounding name real users skip);
    // any submission with it non-empty is treated as a bot. Matches the
    // field name used in js/auth.js and read in api/login-captcha-verify.php.
    'honeypot_field' => 'website',
];
