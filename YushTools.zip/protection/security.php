<?php
/**
 * YUSH UPDATER server-side defensive guard.
 *
 * This is an application-layer mitigation. It cannot replace a CDN/WAF
 * for volumetric DDoS because PHP only sees requests that reached the host.
 */
if (defined('YUSH_SECURITY_LOADED')) { return; }
define('YUSH_SECURITY_LOADED', true);

function yush_path_rules(): array {
    static $rules = null;
    if ($rules === null) {
        $rules = require __DIR__ . '/path_rules.php';
    }
    return $rules;
}

function yush_normalized_path(): string {
    $path = rawurldecode(yush_path());
    $path = preg_replace('~/+~', '/', $path) ?: '/';
    return strtolower($path);
}

function yush_has_path_attack(): bool {
    $raw = (string)($_SERVER['REQUEST_URI'] ?? '');
    $decoded = rawurldecode($raw);
    if (strpos($raw, "\0") !== false || strpos($decoded, "\0") !== false) return true;
    if (preg_match('~(?:\.\./|\.\\\|%2e%2e|%252e|%2f%2e%2e|%5c)~i', $raw . ' ' . $decoded)) return true;
    return false;
}

function yush_query_size_ok(): bool {
    $query = (string)($_SERVER['QUERY_STRING'] ?? '');
    $limit = (int)(yush_cfg()['max_query_length'] ?? 8192);
    return $limit <= 0 || strlen($query) <= $limit;
}

function yush_sensitive_path_probe(): bool {
    $path = yush_normalized_path();
    $rules = yush_path_rules();
    return isset($rules[$path]);
}

function yush_host_allowed(): bool {
    $allowed = yush_cfg()['allowed_hosts'] ?? [];
    if (!$allowed) return true;
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    $host = preg_replace('/:\d+$/', '', $host);
    return $host !== '' && in_array($host, array_map('strtolower', $allowed), true);
}

function yush_cfg(): array {
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/config.php';
    }
    return $cfg;
}

/**
 * True if $ip is a private/loopback/link-local address — i.e. it can never
 * itself be a real Internet client. Shared hosts commonly front PHP with a
 * local reverse proxy whose REMOTE_ADDR looks like this, in which case it's
 * safe to also trust forwarded-IP headers even without an explicit
 * trusted_proxies entry (there's no other candidate REMOTE_ADDR could be).
 */
function yush_ip_is_private_hop(string $ip): bool {
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
}

function yush_ip(): string {
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!filter_var($remote, FILTER_VALIDATE_IP)) return '0.0.0.0';

    $trusted = yush_cfg()['trusted_proxies'] ?? [];
    $trustForwarded = (bool)($trusted && in_array($remote, $trusted, true)) || yush_ip_is_private_hop($remote);

    if ($trustForwarded) {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_TRUE_CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $candidate = trim(explode(',', (string)$_SERVER[$key])[0]);
                if (filter_var($candidate, FILTER_VALIDATE_IP) && !yush_ip_is_private_hop($candidate)) {
                    return $candidate;
                }
            }
        }
    }
    return $remote;
}

function yush_path(): string {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path = parse_url($uri, PHP_URL_PATH);
    return is_string($path) && $path !== '' ? $path : '/';
}

function yush_method(): string {
    return strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
}

/**
 * Reads the raw POST body once and caches it for the rest of the request.
 * php://input can behave inconsistently if read more than once per request
 * on some SAPI configurations, so every consumer (the WAF payload scan, the
 * Turnstile endpoint, etc.) should go through this instead of calling
 * file_get_contents('php://input') directly.
 */
function yush_raw_body(int $maxBytes = 65536): string {
    static $cached = null;
    if ($cached === null) {
        $body = @file_get_contents('php://input', false, null, 0, $maxBytes);
        $cached = is_string($body) ? $body : '';
    }
    return $cached;
}

function yush_log(string $event, array $ctx = []): void {
    $cfg = yush_cfg();
    if (empty($cfg['logging']['enabled'])) return;
    $safe = [
        'event' => $event,
        'ip' => yush_ip(),
        'path' => yush_path(),
        'method' => yush_method(),
        'ts' => gmdate('c'),
    ];
    foreach ($ctx as $k => $v) {
        if (in_array(strtolower((string)$k), ['password','token','cookie','authorization','secret','apikey','api_key'], true)) continue;
        $safe[$k] = is_scalar($v) ? (string)$v : '[redacted]';
    }
    $line = '[YUSH-SECURITY] ' . json_encode($safe, JSON_UNESCAPED_SLASHES);
    $file = $cfg['logging']['file'] ?? null;
    if (is_string($file) && $file !== '') {
        @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    } else {
        error_log($line);
    }
}

/**
 * Manually-managed IP blocklist, editable from the Admin Panel's
 * "IP Ban List" card (via api/security-ip-block.php) without touching
 * config.php. Stored under protection/data/, already blocked from direct
 * web access by the root .htaccess "protection(?:/|$)" rule.
 */
function yush_blocklist_file(): string {
    $dir = __DIR__ . '/data';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir . '/blocked-ips.json';
}

function yush_dynamic_block_ips(): array {
    $f = yush_blocklist_file();
    if (!is_file($f)) return [];
    $data = json_decode((string)@file_get_contents($f), true);
    return is_array($data) ? $data : [];
}

function yush_add_block_ip(string $ip, string $reason = ''): bool {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;
    $list = yush_dynamic_block_ips();
    $list[$ip] = ['ip' => $ip, 'reason' => $reason !== '' ? substr($reason, 0, 120) : 'manual', 'addedAt' => time()];
    return @file_put_contents(yush_blocklist_file(), json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

function yush_remove_block_ip(string $ip): bool {
    $list = yush_dynamic_block_ips();
    unset($list[$ip]);
    return @file_put_contents(yush_blocklist_file(), json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

function yush_storage_dir(): ?string {
    static $dir = false;
    if ($dir !== false) return $dir ?: null;
    $base = sys_get_temp_dir();
    $dir = $base . DIRECTORY_SEPARATOR . 'yush_security_v2';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    if (!is_dir($dir) || !is_writable($dir)) {
        $dir = null;
        return null;
    }
    return $dir;
}

function yush_bucket_file(string $key): ?string {
    $dir = yush_storage_dir();
    if (!$dir) return null;
    return $dir . DIRECTORY_SEPARATOR . hash('sha256', $key) . '.json';
}

function yush_read_bucket(string $key): array {
    $file = yush_bucket_file($key);
    $defaults = ['start' => time(), 'count' => 0, 'hits' => 0, 'blocked_until' => 0, 'strikes' => 0];
    if (!$file || !is_file($file)) return $defaults;
    $raw = @file_get_contents($file);
    $data = json_decode((string)$raw, true);
    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

function yush_write_bucket(string $key, array $data): void {
    $file = yush_bucket_file($key);
    if (!$file) return;
    @file_put_contents($file, json_encode($data), LOCK_EX);
}

function yush_rate(string $bucket, int $limit, int $window): bool {
    $key = $bucket . '|' . yush_ip();
    $data = yush_read_bucket($key);
    $now = time();

    if (($now - (int)$data['start']) >= $window) {
        // Preserve escalation memory (strikes) across window resets so
        // repeat offenders get progressively longer blocks instead of a
        // clean slate every window — a cheap deterrent against sustained
        // application-layer flood/scrape attempts from a single IP.
        $data = ['start' => $now, 'count' => 0, 'hits' => 0, 'blocked_until' => 0, 'strikes' => (int)($data['strikes'] ?? 0)];
    }
    if (!empty($data['blocked_until']) && $now < (int)$data['blocked_until']) {
        yush_log('temporary_block', [
            'bucket' => $bucket,
            'ua' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200),
        ]);
        return false;
    }
    $data['count']++;
    $ok = $data['count'] <= $limit;
    if (!$ok) {
        $data['hits']++;
        $abuse = yush_cfg()['abuse'];
        if ($data['hits'] >= (int)$abuse['block_after']) {
            $strikes = (int)($data['strikes'] ?? 0) + 1;
            $data['strikes'] = min($strikes, 8); // cap growth
            $base = (int)$abuse['block_seconds'];
            $escalated = $base * (2 ** min($strikes - 1, 6)); // 1x,2x,4x,...64x
            $data['blocked_until'] = $now + min($escalated, 86400); // never more than 24h
            $data['hits'] = 0;
            yush_log('escalated_block', ['bucket'=>$bucket, 'strikes'=>$strikes, 'seconds'=>min($escalated, 86400)]);
            if (yush_alert_should_send('escalated-rate|' . $bucket . '|' . yush_ip(), 900)) {
                yush_alert_owner('Repeated abuse — IP temporarily blocked', [
                    'Bucket'            => $bucket,
                    'Strikes'           => (string)$strikes,
                    'Blocked for (sec)' => (string)min($escalated, 86400),
                    'IP address'        => yush_ip(),
                    'Path'              => yush_path(),
                    'User agent'        => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
                    'Time (UTC)'        => gmdate('Y-m-d H:i:s') . ' UTC',
                ]);
            }
        }
    }
    yush_write_bucket($key, $data);
    return $ok;
}

/**
 * Anti-clone / anti-dump guard. Unlike yush_rate() (which counts total
 * requests) this counts DISTINCT normalized paths seen from one IP inside a
 * rolling window. A human clicking around never generates dozens of unique
 * paths in half a minute; a site-cloning/dumping tool walking every link it
 * can find does — even if it rotates user agents to slip past
 * yush_known_bad_bot(). Returns true when the IP should be blocked.
 */
function yush_crawl_guard_tripped(): bool {
    $cfg = yush_cfg()['crawl_guard'] ?? [];
    if (empty($cfg['enabled'])) return false;

    $window = (int)($cfg['window'] ?? 30);
    $limit = (int)($cfg['distinct_path_limit'] ?? 35);
    $key = 'crawl|' . yush_ip();
    $file = yush_bucket_file($key);
    if (!$file) return false; // no writable storage — fail open, rate limit still applies

    $now = time();
    $raw = is_file($file) ? @file_get_contents($file) : false;
    $data = $raw ? json_decode((string)$raw, true) : null;
    if (!is_array($data) || !isset($data['start']) || ($now - (int)$data['start']) >= $window) {
        $data = ['start' => $now, 'paths' => []];
    }

    $path = yush_normalized_path();
    if (!in_array($path, $data['paths'], true)) {
        $data['paths'][] = $path;
        // Cap stored paths so the bucket file can't grow unbounded.
        if (count($data['paths']) > 500) $data['paths'] = array_slice($data['paths'], -500);
    }

    @file_put_contents($file, json_encode($data), LOCK_EX);

    if (count($data['paths']) > $limit) {
        yush_log('crawl_guard_block', ['distinct_paths' => count($data['paths']), 'window' => $window]);
        return true;
    }
    return false;
}

/**
 * Verify a Cloudflare Turnstile token server-side.
 * Never trust a client-reported "captcha passed" flag — always re-check
 * the token against Cloudflare's siteverify endpoint from the server.
 */
function yush_turnstile_verify(string $token, string $remoteIp): array {
    $cfg = yush_cfg()['turnstile'] ?? [];
    $secret = (string)($cfg['secret_key'] ?? '');
    $url = (string)($cfg['verify_url'] ?? 'https://challenges.cloudflare.com/turnstile/v0/siteverify');

    if ($secret === '' || $token === '') {
        return ['success' => false, 'error-codes' => ['missing-input']];
    }

    $payload = http_build_query([
        'secret'   => $secret,
        'response' => $token,
        'remoteip' => $remoteIp,
    ]);

    $result = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_CONNECTTIMEOUT => 5,
        ]);
        $result = curl_exec($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                'content' => $payload,
                'timeout' => 8,
            ],
        ]);
        $result = @file_get_contents($url, false, $ctx);
    }

    if ($result === false || $result === null) {
        return ['success' => false, 'error-codes' => ['network-error']];
    }

    $decoded = json_decode($result, true);
    if (!is_array($decoded)) {
        return ['success' => false, 'error-codes' => ['bad-response']];
    }
    return $decoded;
}

function yush_security_headers(): void {
    if (headers_sent()) return;

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), usb=(), payment=()');
    // header('Cross-Origin-Opener-Policy: same-origin');
    // header('Cross-Origin-Resource-Policy: same-origin'); // can break Turnstile on some hosts
    header('Cache-Control: no-store, private, max-age=0');

    // The current app has inline handlers/styles, so this CSP is intentionally
    // compatible rather than falsely "strict". Remove unsafe-inline only after
    // migrating inline handlers/styles to external files/nonces/hashes.
    header("Content-Security-Policy: default-src 'self' https: data: blob:; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https:; font-src 'self' data: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://challenges.cloudflare.com https://*.cloudflare.com; frame-src https://challenges.cloudflare.com https://*.cloudflare.com; connect-src 'self' https:; media-src 'self' blob:; worker-src 'self' blob:;");
    if (!empty(yush_cfg()['hsts']) && (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

function yush_bot_score(): int {
    $score = 0;
    $ua = strtolower(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
    $accept = trim((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
    $lang = trim((string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''));

    if ($ua === '') $score += 7;
    $markers = [
        'scrapy','python-requests','python-urllib','curl/','wget/','go-http-client',
        'libwww-perl','aiohttp','httpclient','okhttp','java/','php/','node-fetch',
        'axios/','got/','headlesschrome','phantomjs','selenium','playwright',
        'puppeteer','mechanize','nikto','sqlmap','masscan','scraper','spider'
    ];
    foreach ($markers as $marker) {
        if (strpos($ua, $marker) !== false) { $score += 8; break; }
    }
    if ($accept === '') $score += 3;
    if ($lang === '') $score += 3;
    if (stripos($ua, 'mozilla/') === 0 && empty($_SERVER['HTTP_SEC_FETCH_SITE'])) $score += 1;
    return min($score, 100);
}

/**
 * Hard-block known crawlers, AI-scraping bots, and offline site-mirroring
 * tools by user-agent substring. Unlike yush_bot_score() this is an
 * unconditional deny list, not a weighted heuristic — every entry here is a
 * deliberate policy choice (robots.txt already disallows everything on this
 * site, so there is nothing for a "well-behaved" crawler to legitimately do).
 */
function yush_known_bad_bot(): bool {
    $ua = strtolower(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
    if ($ua === '') return false;
    foreach (yush_cfg()['blocked_bot_signatures'] ?? [] as $sig) {
        if ($sig !== '' && strpos($ua, $sig) !== false) return true;
    }
    return false;
}

/**
 * Lightweight, defense-in-depth payload scan. Checks the request path, query
 * string, and (for small form/json bodies only) the raw POST body against a
 * conservative list of injection/traversal/RCE substrings. This is not a
 * substitute for parameterized queries, output escaping, or a real WAF — it
 * exists to cheaply reject obvious automated exploit probes before they
 * reach application logic.
 */
function yush_attack_payload_detected(): bool {
    $sigs = yush_cfg()['attack_signatures'] ?? [];
    if (!$sigs) return false;

    $haystack = strtolower(rawurldecode(yush_path() . '?' . (string)($_SERVER['QUERY_STRING'] ?? '')));

    $method = yush_method();
    $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    if ($method === 'POST' && $len > 0 && $len <= 65536 &&
        (strpos($ct, 'application/json') !== false || strpos($ct, 'x-www-form-urlencoded') !== false)) {
        $body = yush_raw_body();
        if ($body !== '') {
            $haystack .= ' ' . strtolower($body);
        }
    }

    foreach ($sigs as $sig) {
        if ($sig !== '' && strpos($haystack, strtolower($sig)) !== false) return true;
    }
    return false;
}

/**
 * True if a hidden honeypot form field was submitted non-empty. Wire this up
 * from any endpoint that receives form/JSON submissions (see
 * api/login-captcha-verify.php) alongside the shared 'honeypot_field' name
 * used in the corresponding HTML form.
 */
function yush_honeypot_tripped(?string $value): bool {
    return $value !== null && trim($value) !== '';
}

function yush_classify_bucket(): string {
    $path = yush_path();
    $method = yush_method();
    if ($method === 'HEAD') return 'head';
    if (preg_match('~/(login|signin|auth)~i', $path)) return 'login';
    if (preg_match('~/(register|signup|create-account)~i', $path)) return 'register';
    // Chunked dump uploads legitimately fire dozens/hundreds of rapid-fire
    // POSTs to the SAME endpoint by design (1MB chunks) — that's expected
    // traffic, not a flood, so it gets its own generous bucket instead of
    // falling into the generic 'api' limit meant for one-off calls.
    if (preg_match('~/upload-chunk\.php~i', $path)) return 'chunk_upload';
    if (preg_match('~/(api|ajax|endpoint)~i', $path)) return 'api';
    if (preg_match('~/(download|export|search|process|convert)~i', $path)) return 'expensive';
    return 'default';
}

/**
 * Lightweight, standalone Telegram sender for attack/abuse alerts. Kept
 * independent of protection/approvals.php (rather than requiring it) so
 * security.php — which loads before everything else via bootstrap.php —
 * never has a hard dependency on the approvals feature. It reuses the same
 * bot token / owner id from approvals-config.php, since that's the same
 * Telegram bot/chat the owner already has open for account approvals.
 */
function yush_attack_alert_cfg(): array {
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/approvals-config.php';
        $loaded = is_file($file) ? (require $file) : [];
        $cfg = is_array($loaded) ? $loaded : [];
    }
    return $cfg;
}

/**
 * De-duplicates repeated alerts for the same key (typically reason+IP) within
 * a cooldown window, so a sustained probe/attack doesn't flood Telegram with
 * one message per request. Reuses the existing bucket storage.
 */
function yush_alert_should_send(string $key, int $cooldown = 900): bool {
    $data = yush_read_bucket('alert|' . $key);
    $now = time();
    if (!empty($data['blocked_until']) && $now < (int)$data['blocked_until']) return false;
    $data['blocked_until'] = $now + $cooldown;
    yush_write_bucket('alert|' . $key, $data);
    return true;
}

function yush_alert_owner(string $title, array $fields): void {
    $cfg = yush_attack_alert_cfg();
    $token = (string)($cfg['bot_token'] ?? '');
    $ownerId = (int)($cfg['owner_id'] ?? 0);
    if ($token === '' || $ownerId <= 0) return;

    $lines = ['🚨 <b>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</b>'];
    foreach ($fields as $label => $value) {
        $value = ($value === null || $value === '') ? '—' : (string)$value;
        $lines[] = '<b>' . htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8') . ':</b> <code>'
                 . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '</code>';
    }
    $text = implode("\n", $lines);

    $url = 'https://api.telegram.org/bot' . $token . '/sendMessage';
    $payload = json_encode([
        'chat_id' => $ownerId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ]);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_CONNECTTIMEOUT => 4,
        ]);
        @curl_exec($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => $payload,
                'timeout' => 6,
                'ignore_errors' => true,
            ],
        ]);
        @file_get_contents($url, false, $ctx);
    }
}

/**
 * Sends a Telegram alert with the IP and full request context for reasons
 * that indicate a genuine attack/probe attempt — not for the noisy, often
 * benign ones (plain rate limiting, oversized request, disallowed method),
 * so the owner's chat doesn't get flooded by ordinary traffic spikes.
 */
function yush_alert_attack(string $reason, int $status): void {
    $alertable = [
        'path-normalization', 'sensitive-path', 'known-bad-bot',
        'attack-payload', 'ip-block', 'scripted-client', 'bot-score', 'host',
    ];
    if (!in_array($reason, $alertable, true)) return;

    $ip = yush_ip();
    if (!yush_alert_should_send('attack|' . $reason . '|' . $ip)) return;

    yush_alert_owner('Attack attempt detected', [
        'Reason'      => $reason,
        'HTTP status' => (string)$status,
        'IP address'  => $ip,
        'Method'      => yush_method(),
        'Path'        => yush_path(),
        'Query'       => (string)($_SERVER['QUERY_STRING'] ?? ''),
        'Host'        => (string)($_SERVER['HTTP_HOST'] ?? ''),
        'User agent'  => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
        'Referer'     => substr((string)($_SERVER['HTTP_REFERER'] ?? ''), 0, 250),
        'Time (UTC)'  => gmdate('Y-m-d H:i:s') . ' UTC',
    ]);
}

function yush_block(int $status, string $reason, int $retry = 60, string $userMessage = ''): void {
    yush_log('blocked', [
        'reason' => $reason,
        'ua' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200),
        'status' => $status,
    ]);
    yush_alert_attack($reason, $status);
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        if ($status === 429) header('Retry-After: ' . max(1, min(3600, $retry)));
        header('Cache-Control: no-store');
    }
    if ($userMessage !== '') {
        $safe = htmlspecialchars($userMessage, ENT_QUOTES, 'UTF-8');
        exit('<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Access denied</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f1117;color:#e8eaf0;font-family:system-ui,sans-serif;padding:24px;text-align:center} .card{max-width:420px;background:#1a1d27;border:1px solid #2a2f3a;border-radius:16px;padding:28px 24px} h1{font-size:18px;margin:0 0 10px} p{color:#a8b0c0;font-size:14px;line-height:1.5;margin:0}</style></head><body><div class="card"><h1>Access denied</h1><p>' . $safe . '</p></div></body></html>');
    }
    exit("Request blocked.\n");
}

function yush_run_security_guard(): void {
    $cfg = yush_cfg();
    yush_security_headers();

    if (!yush_host_allowed()) yush_block(421, 'host');
    if (yush_has_path_attack()) yush_block(400, 'path-normalization');
    if (!yush_query_size_ok()) yush_block(414, 'query-size');
    if (yush_sensitive_path_probe()) yush_block(404, 'sensitive-path');

    $ip = yush_ip();
    $dyn = yush_dynamic_block_ips();
    if (in_array($ip, $cfg['block_ips'] ?? [], true) || isset($dyn[$ip])) {
        $why = isset($dyn[$ip]['reason']) && $dyn[$ip]['reason'] !== ''
            ? (string)$dyn[$ip]['reason']
            : 'manual block';
        $msg = 'Your IP has been blocked by the owner due to "' . $why . '".';
        yush_block(403, 'ip-block', 60, $msg);
    }
    if (in_array($ip, $cfg['allow_ips'] ?? [], true)) return;

    // api/bot/*.php is only ever called server-to-server by bot.py, never
    // by a browser — that's why it looks "scripted" to the UA heuristics
    // below. It's already gated by its own secret check in _auth.php
    // (yush_bot_require_secret), so skip the browser-impersonation checks
    // here. Path-traversal, attack-payload, and rate-limit checks still
    // apply further down.
    $isBotApi = strpos(yush_normalized_path(), '/api/bot/') === 0;
    // The chunked dump-upload endpoint is expected, by design, to be hit
    // rapidly and repeatedly in a row (one POST per 1MB chunk of a
    // potentially large .cs dump). That's normal use, not a flood — so it
    // gets its own path through the burst/crawl checks below, the same way
    // the bot API does, while still going through its own generous
    // 'chunk_upload' rate-limit bucket further down.
    $isChunkUpload = strpos(yush_normalized_path(), '/api/upload-chunk.php') !== false;

    if (!$isBotApi && yush_known_bad_bot()) yush_block(403, 'known-bad-bot');
    if (yush_attack_payload_detected()) yush_block(403, 'attack-payload');

    $method = yush_method();
    if (!in_array($method, ['GET','HEAD','POST','OPTIONS'], true)) {
        yush_block(405, 'method');
    }

    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    if ((int)($cfg['max_content_length'] ?? 0) > 0 && $len > (int)$cfg['max_content_length']) {
        yush_block(413, 'request-size', 60);
    }

    // Flood check first — a fast burst from one IP gets stopped in its
    // first couple of seconds instead of waiting for the per-minute bucket
    // to fill up.
    if (!$isBotApi && !$isChunkUpload) {
        $burst = $cfg['rate_limits']['burst'] ?? ['limit' => 25, 'window' => 5];
        if (!yush_rate('burst', (int)$burst['limit'], (int)$burst['window'])) {
            yush_block(429, 'ddos-burst', (int)$burst['window']);
        }
    }

    $bucket = yush_classify_bucket();
    $rl = $cfg['rate_limits'][$bucket] ?? $cfg['rate_limits']['default'];
    if (!yush_rate($bucket, (int)$rl['limit'], (int)$rl['window'])) {
        yush_block(429, 'rate-limit', (int)$rl['window']);
    }

    // Anti-clone / anti-dump — distinct-path walking, independent of UA.
    // Chunk uploads hammer the SAME path over and over, so they never trip
    // this anyway, but skip explicitly for clarity and one less bucket
    // write per chunk.
    if (!$isBotApi && !$isChunkUpload && yush_crawl_guard_tripped()) {
        yush_block(403, 'crawl-guard', 300);
    }

    if ($method === 'OPTIONS') {
        // No public API is currently exposed by this project.
        yush_block(405, 'options');
    }

    if (!$isBotApi && !empty($cfg['bot_detection']['enabled'])) {
        $score = yush_bot_score();
        $ua = strtolower((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $weakHeaders = empty($_SERVER['HTTP_ACCEPT']) || empty($_SERVER['HTTP_ACCEPT_LANGUAGE']);
        $scripted = (bool)preg_match('~(scrapy|python-requests|python-urllib|curl/|wget/|aiohttp|go-http-client|libwww-perl|selenium|playwright|puppeteer|phantomjs|sqlmap|nikto)~i', $ua);
        if (!empty($cfg['bot_detection']['block_scripted_without_browser_headers']) && $scripted && $weakHeaders) {
            yush_block(403, 'scripted-client');
        }
        if ($score >= (int)$cfg['bot_detection']['score_block'] && $weakHeaders) {
            yush_block(403, 'bot-score');
        }
    }
}
