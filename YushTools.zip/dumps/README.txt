YUSH TOOLS — permanent dump storage
===================================
Saved dumps are stored OUTSIDE public_html when possible so they survive
website re-uploads:

  Prefer:  {parent of site}/yush_data/dumps/{old|new}/
  Fallback: public_html/dumps/{old|new}/

When you redeploy the site ZIP, do NOT delete the yush_data folder.
Dumps only disappear if you click Delete in Dump List.

If old dumps lived under public_html/dumps/, they are auto-migrated once
into the permanent location the next time the dump list loads.
