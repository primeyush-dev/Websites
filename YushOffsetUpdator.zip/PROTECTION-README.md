# YUSH Offset Updator — protection

## What is included

`protection/bootstrap.php` is the main PHP entry point. It loads:

- the bundled CleanTalk Anti-DDoS helper;
- `protection/anti-scraper.php` for server-side request filtering;
- conservative request-rate limiting;
- obvious scripted-client detection;
- common HTTP security headers.

The package also includes `robots.txt` and an Apache `.htaccess` that disables directory listing, makes `index.php` the default entry point, redirects `index.html`, and denies direct access to the protection directory.

## Usage

At the top of each PHP page that must be protected:

```php
<?php
require_once __DIR__ . '/protection/bootstrap.php';
```

`index.php` is already wired this way.

## Important limitations

No PHP/JavaScript package can honestly guarantee 100% protection against scraping, crawling, source copying, or DDoS. Browser-visible content can always be copied by a sufficiently capable client.

For stronger protection, put the site behind a CDN/WAF such as Cloudflare. Their current bot controls include Bot Fight Mode, Super Bot Fight Mode, rate limiting, and dedicated scraping detections. Rate limiting can specifically be used to reduce automated content scraping.

## Deployment notes

- Change `anti_ddos_salt` in `protection/anti-ddos-lite.php` to a unique random value before production use.
- Keep PHP pages behind `bootstrap.php`.
- The included `.htaccess` rules require Apache with `mod_rewrite` enabled.
- If the host uses Nginx, equivalent server rules must be configured there because `.htaccess` is ignored.


## Cloudflare Turnstile

The registration flow now shows a Cloudflare Turnstile security check **after the email verification code is entered** and before the account is created.

1. Create a Turnstile widget in Cloudflare.
2. Put its Site Key in `js/auth.js` as `TURNSTILE_SITEKEY`.
3. Put its Secret Key in `protection/turnstile-config.php`, or preferably set the server environment variable `TURNSTILE_SECRET_KEY`.
4. Keep the secret key out of JavaScript and source control.

The backend endpoint `protection/verify-turnstile.php` performs Cloudflare Siteverify validation before registration continues.


## Netlify deployment (recommended for yushupdator.netlify.app)

This package includes a Netlify Function at `netlify/functions/verify-turnstile.js`.
Because Netlify does not execute PHP files as normal server pages, the browser uses
`/.netlify/functions/verify-turnstile` on Netlify instead of the PHP verifier.

In Netlify, add an environment variable:

- `TURNSTILE_SECRET_KEY` = your Cloudflare Turnstile **Secret Key**

Keep the Secret Key only in Netlify environment variables. Do not put it in
`js/auth.js`, HTML, or any public file.

The public Site Key belongs in `js/auth.js` as `TURNSTILE_SITEKEY`.

Registration flow:
1. User requests the email code.
2. User pastes/types the 6-digit code.
3. Once the code is valid, Turnstile appears automatically.
4. A checked Turnstile widget is accepted when **Create account** is clicked.
5. If Turnstile is not checked, account creation is blocked with an error.
