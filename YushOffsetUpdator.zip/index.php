<?php
require_once __DIR__ . '/protection/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>YUSH UPDATOR — Offset Synchronization Engine</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app">

  <header class="topbar">
    <div class="brand">
      <div class="logo-mark" aria-hidden="true">
        <svg viewBox="0 0 48 48" width="30" height="30">
          <defs>
            <linearGradient id="lg1" x1="4" y1="4" x2="44" y2="20"><stop offset="0" stop-color="#d8ccff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient>
            <linearGradient id="lg2" x1="4" y1="16" x2="24" y2="44"><stop offset="0" stop-color="#a855f7"/><stop offset="1" stop-color="#5b21b6"/></linearGradient>
            <linearGradient id="lg3" x1="44" y1="16" x2="24" y2="44"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#4c1d95"/></linearGradient>
          </defs>
          <path d="M24 4 L44 16 L34 22 L24 16 L14 22 L4 16 Z" fill="url(#lg1)"/>
          <path d="M4 16 L14 22 L14 34 L24 44 L24 26 Z" fill="url(#lg2)"/>
          <path d="M44 16 L34 22 L34 34 L24 44 L24 26 Z" fill="url(#lg3)"/>
        </svg>
      </div>
      <div class="brand-text">
        <h1>YUSH <span>UPDATOR</span></h1>
        <p>Offset Synchronization Engine</p>
      </div>
    </div>
    <div class="topbar-right">
      <span class="version-tag">v4.0</span>
      <div class="topbar-controls">
        <div class="status-pod" id="statusPod" data-state="empty">
          <span class="status-dot" id="statusDot"></span>
          <div class="status-text">
            <div class="status-title" id="statusTitle">Engine Ready</div>
            <div class="status-sub" id="statusSub">Waiting for files</div>
          </div>
        </div>
        <button class="icon-btn" type="button" title="Settings" onclick="openPanel('settings')">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
        </button>
        <button class="icon-btn round" type="button" title="About YUSH UPDATOR" onclick="openPanel('about')">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="11"/><circle cx="12" cy="8" r="0.7" fill="currentColor" stroke="none"/></svg>
        </button>
      </div>
    </div>
  </header>

  <main class="scroll-body">

    <section class="step-card">
      <div class="step-header">
        <div class="step-num">1</div>
        <div class="step-info"><h3>Old Dump (Reference)</h3><p>Previous dump used as the baseline for comparison.</p></div>
      </div>

      <div class="file-preview" id="fp-old">
        <div class="file-preview-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </div>
        <div class="file-preview-info">
          <div class="file-preview-name" id="fpn-old">—</div>
          <div class="file-preview-meta" id="fpm-old">—</div>
        </div>
        <div class="file-preview-check">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#07130d" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
      </div>

      <div class="file-row">
        <div class="file-display" id="fd-old">
          <svg class="folder-ic" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
          <span id="fd-old-txt">No file selected</span>
        </div>
        <button class="browse-btn" type="button" onclick="pick('old')">Choose File</button>
      </div>
      <p class="step-hint">Load old/previous dump.cs — establishes the RVA / field offset baseline.</p>
      <input type="file" id="f-old" accept="*" onchange="onFile('old',this)">
    </section>

    <section class="step-card">
      <div class="step-header">
        <div class="step-num">2</div>
        <div class="step-info"><h3>New Dump (Updated)</h3><p>Latest dump containing the updated offset references.</p></div>
      </div>

      <div class="file-preview" id="fp-new">
        <div class="file-preview-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </div>
        <div class="file-preview-info">
          <div class="file-preview-name" id="fpn-new">—</div>
          <div class="file-preview-meta" id="fpm-new">—</div>
        </div>
        <div class="file-preview-check">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#07130d" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
      </div>

      <div class="file-row">
        <div class="file-display" id="fd-new">
          <svg class="folder-ic" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
          <span id="fd-new-txt">No file selected</span>
        </div>
        <button class="browse-btn" type="button" onclick="pick('new')">Choose File</button>
      </div>
      <p class="step-hint">Load new/updated dump.cs — source of truth for replacement.</p>
      <input type="file" id="f-new" accept="*" onchange="onFile('new',this)">
    </section>

    <section class="step-card">
      <div class="step-header">
        <div class="step-num">3</div>
        <div class="step-info"><h3>Target File</h3><p>Source file where matching offsets will be updated.</p></div>
      </div>

      <div class="file-preview" id="fp-tgt">
        <div class="file-preview-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </div>
        <div class="file-preview-info">
          <div class="file-preview-name" id="fpn-tgt">—</div>
          <div class="file-preview-meta" id="fpm-tgt">—</div>
        </div>
        <div class="file-preview-check">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#07130d" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
      </div>

      <div class="file-row">
        <div class="file-display" id="fd-tgt">
          <svg class="folder-ic" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
          <span id="fd-tgt-txt">No file selected (.cpp / .lua / .h / .cs)</span>
        </div>
        <button class="browse-btn" type="button" onclick="pick('tgt')">Choose File</button>
      </div>
      <p class="step-hint">Any plain-text file containing 0x hex offsets.</p>
      <input type="file" id="f-tgt" accept="*" onchange="onFile('tgt',this)">
    </section>

    <button class="btn-execute" id="btnExec" type="button" onclick="runPipeline()" disabled>
      <span class="btn-execute-icon">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>
      </span>
      <span class="btn-execute-text">
        <span class="btn-execute-title" id="btnLabel">Start Update</span>
        <span class="btn-execute-sub">Compare and synchronize offsets</span>
      </span>
    </button>

    <div class="progress-wrap" id="progressWrap">
      <div class="progress-bar-bg"><div class="progress-bar-fill" id="progressFill"></div></div>
    </div>

    <section class="summary-card">
      <div class="summary-header">
        <div class="summary-title">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="4" y1="20" x2="4" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="20" y1="20" x2="20" y2="14"/></svg>
          Update Summary
        </div>
        <div class="summary-pills" id="summaryPills">
          <span class="pill" data-pill="ready"><i></i>Ready</span>
          <span class="pill" data-pill="processing"><i></i>Processing</span>
          <span class="pill" data-pill="completed"><i></i>Completed</span>
          <span class="pill" data-pill="error"><i></i>Error</span>
        </div>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon si-same"><svg viewBox="0 0 24 24" width="15" height="15" fill="#fff" stroke="none"><polygon points="12 2 15 9 22 9.5 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9.5 9 9"/></svg></div>
          <div class="stat-body"><div class="stat-lbl">Already Latest</div><div class="stat-val sv-same" id="ssame">0</div><div class="stat-desc">Offsets already up to date</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-ok"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
          <div class="stat-body"><div class="stat-lbl">Updated</div><div class="stat-val sv-ok" id="sok">0</div><div class="stat-desc">Offsets successfully updated</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-fail"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#fff" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div>
          <div class="stat-body"><div class="stat-lbl">Failed</div><div class="stat-val sv-fail" id="sfail">0</div><div class="stat-desc">Offsets that could not be updated</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-ign"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#fff" stroke-width="2.4"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.4" fill="#fff" stroke="none"/></svg></div>
          <div class="stat-body"><div class="stat-lbl">Ignored</div><div class="stat-val sv-ign" id="sign">0</div><div class="stat-desc">Offsets skipped during processing</div></div>
        </div>
      </div>

      <div class="same-bar static" id="totalBar">
        <div class="same-icon"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg></div>
        <div class="same-body">
          <div class="same-title">Total</div>
          <div class="same-val" id="st">0</div>
        </div>
        <div class="same-desc">Total offsets detected in the target file.</div>
      </div>
    </section>

    <div class="dl-wrap" id="dlWrap">
      <button class="btn-dl" onclick="doDownload()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Download Updated File
      </button>
    </div>

    <div class="results-wrap" id="resultsWrap">
      <div id="sec-updated" style="display:none;">
        <div class="section-header">
          <div class="section-title" style="color:var(--green);">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>Updated
          </div>
          <div class="section-header-line"></div>
          <span id="sc-updated" class="section-count"></span>
        </div>
        <div id="cards-updated"></div>
      </div>
      <div id="sec-failed" style="display:none;">
        <div class="section-header">
          <div class="section-title" style="color:var(--red);">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Failed
          </div>
          <div class="section-header-line"></div>
          <span id="sc-failed" class="section-count"></span>
        </div>
        <div id="cards-failed"></div>
      </div>
      <div id="sec-ignored" style="display:none;">
        <div class="section-header">
          <div class="section-title" style="color:var(--orange);">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="9"/><line x1="9" y1="9" x2="15" y2="15"/></svg>Ignored
          </div>
          <div class="section-header-line"></div>
          <span id="sc-ignored" class="section-count"></span>
        </div>
        <div id="cards-ignored"></div>
      </div>
      <div id="sec-same" style="display:none;">
        <div class="section-header">
          <div class="section-title" style="color:var(--txt2);">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="9" x2="19" y2="9"/><line x1="5" y1="15" x2="19" y2="15"/></svg>Already Latest
          </div>
          <div class="section-header-line"></div>
          <span id="sc-same" class="section-count"></span>
        </div>
        <div id="cards-same"></div>
      </div>
    </div>

  </main>


</div>

<!-- ============================== Settings panel ============================== -->
<div class="panel-overlay" id="settingsPanel">
  <div class="panel-inner">
    <div class="panel-header">
      <button class="panel-exit" type="button" onclick="closePanel('settings')">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Exit
      </button>
      <div class="panel-title">Settings</div>
    </div>

    <div class="panel-body">

      <div class="settings-note">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;margin-top:1px;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="11"/><circle cx="12" cy="8" r="0.7" fill="currentColor" stroke="none"/></svg>
        <div>Your theme and preferences are saved on this device — they'll still be here the next time you open <b>YUSH UPDATOR</b>.</div>
      </div>

      <section class="settings-section">
        <div class="settings-section-title">Theme</div>
        <div class="theme-grid">
          <button type="button" class="theme-pill" data-theme-btn="purple" onclick="setTheme('purple')">
            <span class="theme-pill-check">
              <svg viewBox="0 0 24 24" width="8" height="8" fill="none" stroke="#fff" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
            </span>
            <span class="theme-pill-swatch swatch-purple"></span>
            <span class="theme-pill-label">Purple</span>
          </button>
          <button type="button" class="theme-pill" data-theme-btn="dark" onclick="setTheme('dark')">
            <span class="theme-pill-check">
              <svg viewBox="0 0 24 24" width="8" height="8" fill="none" stroke="#fff" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
            </span>
            <span class="theme-pill-swatch swatch-dark"></span>
            <span class="theme-pill-label">Dark</span>
          </button>
          <button type="button" class="theme-pill" data-theme-btn="white" onclick="setTheme('white')">
            <span class="theme-pill-check">
              <svg viewBox="0 0 24 24" width="8" height="8" fill="none" stroke="#fff" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
            </span>
            <span class="theme-pill-swatch swatch-white"></span>
            <span class="theme-pill-label">White</span>
          </button>
          <button type="button" class="theme-pill" data-theme-btn="green" onclick="setTheme('green')">
            <span class="theme-pill-check">
              <svg viewBox="0 0 24 24" width="8" height="8" fill="none" stroke="#fff" stroke-width="3.4"><polyline points="20 6 9 17 4 12"/></svg>
            </span>
            <span class="theme-pill-swatch swatch-green"></span>
            <span class="theme-pill-label">Green</span>
          </button>
        </div>
      </section>

      <section class="settings-section">
        <div class="settings-section-title">Files</div>
        <div class="toggle-list">
          <div class="toggle-row">
            <div><div class="toggle-name">Auto-download Result</div><div class="toggle-desc">Automatically save the updated file</div></div>
            <label class="switch">
              <input type="checkbox" id="toggleAutoDownload" onchange="setAutoDownload(this.checked)">
              <span class="switch-track"><span class="switch-thumb"></span></span>
            </label>
          </div>
          <div class="toggle-row file-name-row">
            <div><div class="toggle-name">Output Filename</div><div class="toggle-desc">Customize the generated filename</div></div>
            <div class="filename-input-wrap">
              <input type="text" id="outputFilename" class="filename-input" value="updated_file" spellcheck="false" oninput="setOutputFilename(this.value)">
              <span class="filename-ext" id="outputExt">.txt</span>
            </div>
          </div>
        </div>
      </section>

      <section class="settings-section">
        <div class="settings-section-title">Results</div>
        <div class="toggle-list">
          <div class="toggle-row">
            <div><div class="toggle-name">Tap-to-copy offsets</div><div class="toggle-desc">Tap any hex value in Update Summary to copy it</div></div>
            <label class="switch">
              <input type="checkbox" id="toggleCopy" onchange="setCopyEnabled(this.checked)">
              <span class="switch-track"><span class="switch-thumb"></span></span>
            </label>
          </div>
          <div class="toggle-row">
            <div><div class="toggle-name">Show class names</div><div class="toggle-desc">Prefix each result with its detected class</div></div>
            <label class="switch">
              <input type="checkbox" id="toggleClassNames" onchange="setShowClassNames(this.checked)">
              <span class="switch-track"><span class="switch-thumb"></span></span>
            </label>
          </div>
        </div>
      </section>

      <section class="settings-section">
        <div class="settings-section-title">Engine</div>
        <div class="toggle-list">
          <div class="toggle-row">
            <div><div class="toggle-name">Anti-spam guard</div><div class="toggle-desc">Throttle rapid repeated Start Update presses</div></div>
            <label class="switch">
              <input type="checkbox" id="toggleGuard" checked onchange="setGuardEnabled(this.checked)">
              <span class="switch-track"><span class="switch-thumb"></span></span>
            </label>
          </div>
        </div>
      </section>

      <button class="settings-reset" type="button" onclick="resetSettings()">Reset to Default</button>

    </div>
  </div>
</div>

<!-- ============================== About panel ============================== -->
<div class="panel-overlay" id="aboutPanel">
  <div class="panel-inner">
    <div class="panel-header">
      <button class="panel-exit" type="button" onclick="closePanel('about')">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Exit
      </button>
      <div class="panel-title">About</div>
    </div>

    <div class="panel-body">

      <div class="dev-card">
        <div class="dev-avatar"><img src="assets/banner.png" alt="YUSH UPDATOR" class="dev-avatar-img"></div>
        <div class="dev-role">Developer of YUSH UPDATOR</div>
        <div class="dev-handle">
          <svg width="17" height="17" viewBox="0 0 240 240" fill="currentColor"><circle cx="120" cy="120" r="120" fill="#29a9eb"/><path d="M180 72l-19 92c-1.4 6.4-5.2 8-10.6 5l-29-21.4-14 13.5c-1.6 1.6-2.9 2.9-5.9 2.9l2.1-30 55-49.7c2.4-2.1-.5-3.3-3.7-1.2l-68 42.8-29.3-9.2c-6.4-2-6.5-6.4 1.3-9.5l114.6-44.2c5.3-2 10 1.3 8.5 9z" fill="#fff"/></svg>
          <span>@PrimeYush</span>
        </div>
      </div>

      <div class="settings-section-title">Partners</div>
      <div class="partner-list">
        <div class="partner-row">
          <span class="partner-avatar"><img src="assets/zhack.png" alt="@zh4cks" class="partner-avatar-img"></span>
          <div class="partner-info">
            <div class="partner-label">Partner</div>
            <div class="partner-handle">@zh4cks</div>
          </div>
        </div>
        <div class="partner-row">
          <span class="partner-avatar"><img src="assets/hynn.png" alt="@NullHynn" class="partner-avatar-img"></span>
          <div class="partner-info">
            <div class="partner-label">Partner</div>
            <div class="partner-handle">@NullHynn</div>
          </div>
        </div>
      </div>

      <div class="settings-section-title">Find me here</div>
      <div class="link-list">
        <a class="link-row" href="https://t.me/NocturneTeamChannel" target="_blank" rel="noopener">
          <span class="link-ic ic-tg">
            <svg width="16" height="16" viewBox="0 0 240 240" fill="#fff"><path d="M180 72l-19 92c-1.4 6.4-5.2 8-10.6 5l-29-21.4-14 13.5c-1.6 1.6-2.9 2.9-5.9 2.9l2.1-30 55-49.7c2.4-2.1-.5-3.3-3.7-1.2l-68 42.8-29.3-9.2c-6.4-2-6.5-6.4 1.3-9.5l114.6-44.2c5.3-2 10 1.3 8.5 9z"/></svg>
          </span>
          <div><div class="link-title">Telegram Channel</div><div class="link-sub">NocturneTeamChannel</div></div>
          <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
        </a>
        <a class="link-row" href="https://www.tiktok.com/@primeyush?_r=1&_t=ZS-99bYfMu8lu5" target="_blank" rel="noopener">
          <span class="link-ic ic-tt">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="#fff"><path d="M16.6 5.82a4.28 4.28 0 01-3.15-1.42A4.31 4.31 0 0112.3 2h-3.1v13.86a2.6 2.6 0 11-1.84-2.49V10.2a5.72 5.72 0 105.7 5.72V9.4a7.16 7.16 0 004.06 1.26V7.53a4.29 4.29 0 01-.52-.02 4.25 4.25 0 01.02-1.69z"/></svg>
          </span>
          <div><div class="link-title">TikTok</div><div class="link-sub">@primeyush</div></div>
          <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
        </a>
        <a class="link-row" href="https://www.youtube.com/@PrimeYush" target="_blank" rel="noopener">
          <span class="link-ic ic-yt">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M10 15.5l6-3.5-6-3.5v7z"/><path d="M21.6 7.2a2.7 2.7 0 00-1.9-1.9C18 4.8 12 4.8 12 4.8s-6 0-7.7.5a2.7 2.7 0 00-1.9 1.9A28.3 28.3 0 002 12a28.3 28.3 0 00.4 4.8 2.7 2.7 0 001.9 1.9c1.7.5 7.7.5 7.7.5s6 0 7.7-.5a2.7 2.7 0 001.9-1.9A28.3 28.3 0 0022 12a28.3 28.3 0 00-.4-4.8z"/></svg>
          </span>
          <div><div class="link-title">YouTube</div><div class="link-sub">@PrimeYush</div></div>
          <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
        </a>
      </div>

      <div class="settings-note">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;margin-top:1px;"><path d="M12 2l3 7h7l-5.5 4.5L18.5 21 12 16.5 5.5 21l2-7.5L2 9h7z"/></svg>
        <div>Follow the channels above for update drops, new tool releases, and support — that's also the fastest way to reach <b>@PrimeYush</b> directly.</div>
      </div>

      <div class="settings-section-title">Legal</div>
      <div class="link-list">
        <button class="link-row legal-row" type="button" onclick="openLegal('terms')">
          <span class="link-ic ic-legal">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="13" y2="17"/></svg>
          </span>
          <div><div class="link-title">Terms of Service</div><div class="link-sub">Usage terms for YUSH UPDATOR</div></div>
          <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
        <button class="link-row legal-row" type="button" onclick="openLegal('privacy')">
          <span class="link-ic ic-legal">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          </span>
          <div><div class="link-title">Privacy Policy</div><div class="link-sub">How your files and data are handled</div></div>
          <svg class="link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>

    </div>
  </div>
</div>

<!-- ============================== Legal panel (Terms / Privacy) ============================== -->
<div class="panel-overlay" id="legalPanel">
  <div class="panel-inner">
    <div class="panel-header">
      <button class="panel-exit" type="button" onclick="closePanel('legal')">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Exit
      </button>
      <div class="panel-title" id="legalTitle">Legal</div>
    </div>
    <div class="panel-body">
      <div class="legal-text" id="legalText"></div>
    </div>
  </div>
</div>

<script src="js/protection.js"></script>
<script src="js/auth.js"></script>
<script src="js/main.js"></script>
</body>
</html>