exports.handler = async function (event) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  };

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ success: false, error: 'Method not allowed' })
    };
  }

  const secret = process.env.TURNSTILE_SECRET_KEY || '';
  if (!secret || secret.startsWith('PASTE_')) {
    return {
      statusCode: 503,
      headers,
      body: JSON.stringify({ success: false, error: 'Turnstile secret is not configured' })
    };
  }

  let body = {};
  try {
    body = JSON.parse(event.body || '{}');
  } catch (_) {}

  const token = typeof body.token === 'string' ? body.token.trim() : '';
  if (!token || token.length > 2048) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: 'Invalid token' })
    };
  }

  const form = new URLSearchParams();
  form.set('secret', secret);
  form.set('response', token);

  const ip =
    (event.headers && (event.headers['x-forwarded-for'] || event.headers['client-ip'])) || '';
  if (ip) form.set('remoteip', ip.split(',')[0].trim());

  try {
    const response = await fetch(
      'https://challenges.cloudflare.com/turnstile/v0/siteverify',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: form.toString()
      }
    );

    const result = await response.json().catch(() => ({}));
    const success = response.ok && result && result.success === true;

    return {
      statusCode: success ? 200 : 403,
      headers,
      body: JSON.stringify({ success })
    };
  } catch (error) {
    console.error('Turnstile Siteverify request failed:', error);
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ success: false })
    };
  }
};
