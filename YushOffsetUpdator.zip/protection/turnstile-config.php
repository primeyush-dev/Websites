<?php
/**
 * Cloudflare Turnstile configuration.
 *
 * IMPORTANT:
 * - Site key is public and is also configured in js/auth.js.
 * - Secret key MUST stay server-side. Never put it in JavaScript.
 * - For production, prefer setting TURNSTILE_SECRET_KEY as an environment variable.
 */
return [
    'sitekey' => getenv('TURNSTILE_SITE_KEY') ?: '0x4AAAAAAEvFlouUrYi5Y6Tj',
    'secret'  => getenv('TURNSTILE_SECRET_KEY') ?: '0x4AAAAAAEvFluoGp6r2DOPURT_HXCziTRk',
];
