<?php

namespace Cleantalk\CleantalkAntiDdosLite;

class CleantalkAntiDdosLite
{
    public static function init()
    {
        require_once __DIR__ . '/anti-ddos-lite.php';
    }
}