<?php
/**
 * YUSH server-side anti-scraper / crawler guard.
 * No third-party dependency required.
 *
 * IMPORTANT: This is a mitigation layer, not an absolute way to make
 * browser-visible content impossible to copy.
 */

if (!defined('YUSH_ANTISCRAPER_LOADED')) {
    define('YUSH_ANTISCRAPER_LOADED', true);

    function yush_client_ip(): string
    {
        // Do not trust X-Forwarded-For unless your reverse proxy is explicitly trusted.
        return isset($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)
            ? $_SERVER['REMOTE_ADDR']
            : '0.0.0.0';
    }

    function yush_request_path(): string
    {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '/';
        $path = parse_url($uri, PHP_URL_PATH);
        return is_string($path) && $path !== '' ? $path : '/';
    }

    function yush_bot_score(): int
    {
        $score = 0;
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? trim((string) $_SERVER['HTTP_USER_AGENT']) : '';

        if ($ua === '') {
            $score += 5;
        }

        $botMarkers = [
            'scrapy', 'python-requests', 'python-urllib', 'curl/', 'wget/',
            'go-http-client', 'libwww-perl', 'aiohttp', 'httpclient',
            'okhttp', 'java/', 'php/', 'node-fetch', 'axios/', 'got/',
            'headlesschrome', 'phantomjs', 'selenium', 'playwright',
            'puppeteer', 'mechanize', 'nikto', 'sqlmap', 'masscan',
            'crawler', 'spider', 'scraper', 'bot'
        ];
        $uaLower = strtolower($ua);
        foreach ($botMarkers as $marker) {
            if (strpos($uaLower, $marker) !== false) {
                $score += 7;
                break;
            }
        }

        if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            $score += 1;
        }

        // Normal browser requests usually send Accept and Accept-Language.
        if (empty($_SERVER['HTTP_ACCEPT'])) {
            $score += 2;
        }
        if (empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $score += 2;
        }

        if (!empty($_SERVER['HTTP_DNT']) && $_SERVER['HTTP_DNT'] === '1') {
            $score += 0; // DNT alone is not suspicious.
        }

        if (isset($_SERVER['HTTP_SEC_FETCH_SITE']) === false &&
            stripos($ua, 'mozilla/') === 0) {
            $score += 1;
        }

        if (!empty($_SERVER['HTTP_X_PHP_OB_LEVEL'])) {
            $score += 2;
        }

        return min(100, $score);
    }

    function yush_rate_file(string $bucket): string
    {
        $dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'yush_guard';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $safe = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $bucket);
        return $dir . DIRECTORY_SEPARATOR . $safe . '.json';
    }

    function yush_rate_limit(int $limit = 60, int $window = 60): bool
    {
        $ip = yush_client_ip();
        $file = yush_rate_file(hash('sha256', $ip));
        $now = time();
        $data = ['start' => $now, 'count' => 0];

        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $decoded = json_decode((string) $raw, true);
            if (is_array($decoded) && isset($decoded['start'], $decoded['count'])) {
                $data = $decoded;
            }
        }

        if (($now - (int) $data['start']) >= $window) {
            $data = ['start' => $now, 'count' => 0];
        }

        $data['count']++;
        @file_put_contents($file, json_encode($data), LOCK_EX);

        return $data['count'] <= $limit;
    }

    function yush_security_headers(): void
    {
        if (headers_sent()) {
            return;
        }
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header('Cache-Control: private, no-store, max-age=0');
    }

    function yush_block(int $status, string $reason): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: text/plain; charset=utf-8');
            header('Retry-After: 60');
            header('Cache-Control: no-store');
        }
        error_log('YUSH guard blocked ' . yush_client_ip() . ' ' . yush_request_path() . ' reason=' . $reason);
        exit("Request blocked.\n");
    }

    function yush_run_anti_scraper(): void
    {
        yush_security_headers();

        // Reject methods the application does not need.
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
        if (!in_array($method, ['GET', 'HEAD', 'POST', 'OPTIONS'], true)) {
            yush_block(405, 'method');
        }

        // Basic request-rate protection. This is intentionally conservative.
        if (!yush_rate_limit(90, 60)) {
            yush_block(429, 'rate-limit');
        }

        $score = yush_bot_score();
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower((string) $_SERVER['HTTP_USER_AGENT']) : '';

        // Hard-block clearly scripted fetch clients only when they also have weak browser headers.
        $scripted = preg_match('/(scrapy|python-requests|python-urllib|curl\/|wget\/|aiohttp|go-http-client|libwww-perl|selenium|playwright|puppeteer|phantomjs|sqlmap|nikto)/i', $ua);
        $weakHeaders = empty($_SERVER['HTTP_ACCEPT']) || empty($_SERVER['HTTP_ACCEPT_LANGUAGE']);
        if ($scripted && $weakHeaders) {
            yush_block(403, 'scripted-client');
        }

        // Treat obvious bot scores as suspicious, but do not blindly block normal browsers.
        if ($score >= 14 && $weakHeaders) {
            yush_block(403, 'bot-score');
        }
    }
}
