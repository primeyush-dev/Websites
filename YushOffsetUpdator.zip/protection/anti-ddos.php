<?php
/**
 * Compatibility entry point for the bundled Anti-DDoS helper functions.
 * The actual protection entry point is anti-ddos-lite.php.
 */
require_once __DIR__ . '/src/anti-ddos-lib.php';
