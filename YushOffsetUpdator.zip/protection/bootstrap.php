<?php
/**
 * YUSH protection bootstrap.
 *
 * Put:
 *   require_once __DIR__ . '/protection/bootstrap.php';
 * at the very top of any PHP page you want protected.
 */
if (!defined('YUSH_PROTECTION_BOOTSTRAPPED')) {
    define('YUSH_PROTECTION_BOOTSTRAPPED', true);
    require_once __DIR__ . '/anti-ddos-lite.php';
}
