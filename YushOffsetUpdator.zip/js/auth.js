(function () {
  'use strict';
  
  var EMAILJS_PUBLIC_KEY  = 'ZAhhQvlMpNMCivJhn';
  var EMAILJS_SERVICE_ID  = 'service_1sf8dfm';
  var EMAILJS_TEMPLATE_ID = 'template_68iwuwd';

  var STAY_DAYS     = 2;
  var DB_KEY        = '__yush_users__';
  var SESSION_KEY   = '__yush_session__';
  var CODE_TTL_MS   = 5 * 60 * 1000;
  var CODE_COOLDOWN = 60;
  // Cloudflare Turnstile configuration.
  // Set the matching site key in protection/turnstile-config.php.
  var TURNSTILE_SITEKEY = '0x4AAAAAAEvFlouUrYi5Y6Tj';
  var _turnstileReady = false;
  var _turnstileWidgetId = null;
  var _turnstileToken = '';

  function loadTurnstile(callback, onError) {
    if (window.turnstile) {
      _turnstileReady = true;
      callback();
      return;
    }
    var existing = document.querySelector('script[data-yush-turnstile]');
    if (existing) {
      existing.addEventListener('load', function() {
        _turnstileReady = !!window.turnstile;
        _turnstileReady ? callback() : (onError && onError(new Error('Turnstile unavailable')));
      });
      existing.addEventListener('error', function(e) { onError && onError(e); });
      return;
    }
    var script = document.createElement('script');
    script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    script.async = true;
    script.defer = true;
    script.setAttribute('data-yush-turnstile', '1');
    script.onload = function() {
      _turnstileReady = !!window.turnstile;
      _turnstileReady ? callback() : (onError && onError(new Error('Turnstile unavailable')));
    };
    script.onerror = function(e) { onError && onError(e); };
    document.head.appendChild(script);
  }

  function resetTurnstile() {
    _turnstileToken = '';
    if (_turnstileWidgetId !== null && window.turnstile) {
      try { window.turnstile.reset(_turnstileWidgetId); } catch (e) {}
    }
  }

  function destroyTurnstile() {
    _turnstileToken = '';
    if (_turnstileWidgetId !== null && window.turnstile) {
      try {
        if (typeof window.turnstile.remove === 'function') {
          window.turnstile.remove(_turnstileWidgetId);
        }
      } catch (e) {}
    }
    _turnstileWidgetId = null;
  }

  function getTurnstileToken() {
    if (_turnstileToken) return _turnstileToken;
    if (_turnstileWidgetId !== null && window.turnstile &&
        typeof window.turnstile.getResponse === 'function') {
      try {
        var response = window.turnstile.getResponse(_turnstileWidgetId);
        if (response) {
          _turnstileToken = response;
          return response;
        }
      } catch (e) {}
    }
    return '';
  }

  function renderTurnstile() {
    var box = document.getElementById('turnstileBox');
    if (!box) return;
    if (TURNSTILE_SITEKEY.indexOf('PASTE_') === 0) {
      box.innerHTML = '<div class="turnstile-setup">Cloudflare Turnstile is not configured yet. Add your Site Key in <code>js/auth.js</code> and your Secret Key in <code>protection/turnstile-config.php</code>.</div>';
      return;
    }
    loadTurnstile(function() {
      if (_turnstileWidgetId !== null) return;
      try {
        _turnstileWidgetId = window.turnstile.render(box, {
          sitekey: TURNSTILE_SITEKEY,
          theme: 'auto',
          callback: function(token) {
            _turnstileToken = token || '';
            var status = document.getElementById('turnstileStatus');
            if (status) status.textContent = _turnstileToken ? 'Human verification complete.' : '';
          },
          'expired-callback': function() {
            _turnstileToken = '';
            var status = document.getElementById('turnstileStatus');
            if (status) status.textContent = 'Verification expired. Please verify again.';
          },
          'error-callback': function() {
            _turnstileToken = '';
            var status = document.getElementById('turnstileStatus');
            if (status) status.textContent = 'Verification could not be completed. Try again.';
          }
        });
      } catch (e) {
        box.innerHTML = '<div class="turnstile-setup">Turnstile could not be loaded.</div>';
        console.error('Turnstile render failed:', e);
      }
    }, function(e) {
      box.innerHTML = '<div class="turnstile-setup">Cloudflare verification could not be loaded.</div>';
      console.error('Turnstile load failed:', e);
    });
  }

  function showTurnstileStep() {
    var el = document.getElementById('turnstileStep');
    if (!el) return;
    var wasHidden = el.style.display === 'none' || !el.style.display;
    el.style.display = 'block';
    renderTurnstile();
    if (wasHidden) {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  function hideTurnstileStep() {
    var el = document.getElementById('turnstileStep');
    if (el) el.style.display = 'none';
    resetTurnstile();
  }

  async function verifyTurnstileOnServer(token) {
    var endpoint = (window.location.hostname.indexOf('netlify.app') !== -1 ||
                    window.location.hostname.indexOf('netlify.com') !== -1)
      ? '/.netlify/functions/verify-turnstile'
      : 'protection/verify-turnstile.php';

    var response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ token: token })
    });
    var result = await response.json();
    return !!(response.ok && result && result.success === true);
  }


  function dbLoad() {
    try { return JSON.parse(localStorage.getItem(DB_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function dbSave(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); }
  function sessionLoad() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
    catch (e) { return null; }
  }
  function sessionSave(data) { localStorage.setItem(SESSION_KEY, JSON.stringify(data)); }
  function sessionClear() { localStorage.removeItem(SESSION_KEY); }

  function checkSession() {
    var sess = sessionLoad();
    if (!sess) return false;
    if (sess.staySignedIn && sess.expiresAt && Date.now() < sess.expiresAt) return true;
    sessionClear();
    return false;
  }

  var _emailjsReady = false;
  function loadEmailJS(callback, onError) {
    if (_emailjsReady && window.emailjs) { callback(); return; }
    if (window.emailjs) {
      try { window.emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY }); } catch (e) {}
      _emailjsReady = true;
      callback();
      return;
    }
    var script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
    script.onload = function() {
      try {
        window.emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
        _emailjsReady = true;
        callback();
      } catch (e) {
        onError && onError(e);
      }
    };
    script.onerror = function(e) { onError && onError(e); };
    document.head.appendChild(script);
  }

  function sendVerificationEmail(email, code, onSuccess, onError) {
    loadEmailJS(function() {
      window.emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
        to_email: email,
        code: code
      }).then(onSuccess, onError);
    }, onError);
  }

  var AUTH_CSS = `
  #authOverlay {
    position: fixed; inset: 0; z-index: 99999;
    background:
      radial-gradient(560px 320px at 12% -6%, var(--bgrad-1), transparent 60%),
      radial-gradient(480px 320px at 105% 8%, var(--bgrad-2), transparent 60%),
      linear-gradient(160deg, var(--bg-0) 0%, var(--bg-1) 45%, var(--bg-2) 100%);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    overflow-y: auto; overflow-x: hidden;
    font-family: var(--sans, 'Inter', sans-serif);
    padding: 24px 0;
  }
  #authOverlay.hidden { display: none; }

  .auth-card { width: calc(100% - 32px); max-width: 420px; margin: 0 auto; }
  .turnstile-step { margin-top: 14px; margin-bottom: 16px; padding: 13px; border: 1px solid var(--border); border-radius: 12px; background: rgba(255,255,255,.025); }
  .turnstile-title { font-size: 12px; font-weight: 700; color: var(--txt); margin-bottom: 8px; }
  #turnstileBox { display: flex; justify-content: center; min-height: 65px; border-radius: 8px; overflow: hidden; }
  .turnstile-status { font-size: 11px; color: var(--txt3); margin-top: 7px; min-height: 14px; text-align: center; }
  .turnstile-setup { font-size: 11px; line-height: 1.5; color: var(--txt3); }
  .turnstile-setup code { font-family: var(--mono, monospace); }


  /* ── Brand header, matches .topbar .brand ── */
  .auth-brand { display: flex; align-items: center; gap: 11px; justify-content: center; margin-bottom: 22px; }
  .auth-logo-mark {
    width: 46px; height: 46px; border-radius: 13px; flex-shrink: 0;
    background: linear-gradient(155deg, rgba(139,92,246,0.22), rgba(124,58,237,0.06));
    border: 1px solid var(--border);
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 0 24px rgba(139,92,246,0.18);
  }
  .auth-brand-text { text-align: left; }
  .auth-brand-text h1 { font-size: 18px; font-weight: 800; letter-spacing: -.2px; color: var(--txt); line-height: 1.15; }
  .auth-brand-text h1 span {
    background: linear-gradient(90deg, var(--v3), var(--v1));
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .auth-brand-text p { font-size: 10.5px; color: var(--txt3); margin-top: 2px; font-weight: 500; }

  /* ── Alert (matches .settings-note, with error/success variants) ── */
  .auth-alert {
    display: flex; gap: 9px; align-items: flex-start;
    background: rgba(139,92,246,0.08); border: 1px solid var(--border);
    border-radius: var(--r-md); padding: 12px 13px; margin-bottom: 16px;
    font-size: 11.5px; color: var(--txt2); font-weight: 500; line-height: 1.5;
  }
  .auth-alert.error-alert   { background: rgba(248,113,113,0.08); border-color: rgba(248,113,113,0.3);  color: var(--red); }
  .auth-alert.success-alert { background: rgba(52,211,153,0.08);  border-color: rgba(52,211,153,0.3);   color: var(--green); }

  /* ── Panel, matches .step-card ── */
  .auth-panel {
    position: relative; overflow: hidden;
    background: var(--glass); border: 1px solid var(--border);
    border-radius: var(--r-lg); padding: 26px 20px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.28);
  }
  .auth-panel::before {
    content: ''; position: absolute; top: -40%; right: -25%; width: 55%; padding-bottom: 55%;
    background: radial-gradient(circle, rgba(139,92,246,0.14), transparent 70%);
    pointer-events: none;
  }
  .auth-panel > * { position: relative; }

  .auth-title    { font-size: 21px; font-weight: 800; color: var(--txt); margin-bottom: 5px; letter-spacing: -0.1px; }
  .auth-subtitle { font-size: 12.5px; color: var(--txt3); margin-bottom: 24px; line-height: 1.4; }

  .auth-field { margin-bottom: 15px; }
  .auth-field-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
  .auth-label      { font-size: 10.5px; font-weight: 700; color: var(--txt3); text-transform: uppercase; letter-spacing: .5px; }
  .auth-label-note { font-size: 10.5px; color: var(--txt3); font-weight: 500; }

  /* ── Input, matches .file-display / .filename-input-wrap ── */
  .auth-input-wrap {
    display: flex; align-items: center;
    background: rgba(0,0,0,0.22); border: 1px solid var(--border-soft);
    border-radius: var(--r-sm); padding: 0 13px; transition: border-color .2s, background .2s;
  }
  .auth-input-wrap:focus-within { border-color: var(--border); background: rgba(139,92,246,0.06); }
  .auth-input-wrap svg   { color: var(--txt3); flex-shrink: 0; }
  .auth-input-wrap input {
    flex: 1; background: none; border: none; outline: none;
    color: var(--txt); font-size: 13.5px; font-family: var(--sans, 'Inter', sans-serif);
    padding: 12px 10px; font-weight: 500; min-width: 0;
  }
  .auth-input-wrap input::placeholder { color: var(--txt3); font-weight: 400; }
  .auth-eye-btn {
    background: none; border: none; cursor: pointer; padding: 4px; border-radius: 6px;
    color: var(--txt3); display: flex; align-items: center; transition: color .2s;
  }
  .auth-eye-btn:hover { color: var(--v-soft); }

  .auth-code-divider { width: 1px; height: 18px; background: var(--border-soft); margin: 0 1px; flex-shrink: 0; }

  /* ── Send-code pill, matches .panel-exit ── */
  .auth-sendcode-btn {
    display: flex; align-items: center; gap: 0;
    background: none; border: none; cursor: pointer; white-space: nowrap;
    color: var(--v3); font-size: 11.5px; font-weight: 700;
    font-family: var(--sans, 'Inter', sans-serif); padding: 6px 2px 6px 10px;
    transition: color .2s, opacity .2s;
  }
  .auth-sendcode-btn:hover:not(:disabled) { color: var(--v-soft); }
  .auth-sendcode-btn:disabled { color: var(--txt3); cursor: not-allowed; }

  .auth-stay-row   { display: flex; align-items: center; justify-content: space-between; margin: 6px 0 22px; }
  .auth-stay-left  { display: flex; align-items: center; gap: 10px; }
  .auth-stay-label { font-size: 12.5px; color: var(--txt2); font-weight: 600; cursor: pointer; }
  .auth-enc-badge  { display: flex; align-items: center; gap: 5px; font-size: 10px; color: var(--txt3); font-weight: 600; }

  /* ── Checkbox, matches the accent-colored checkbox style used elsewhere ── */
  .auth-stay-cb {
    width: 17px; height: 17px; border-radius: 5px; cursor: pointer;
    accent-color: var(--v1); flex-shrink: 0;
  }

  /* ── Primary button, matches .browse-btn / .btn-execute gradient ── */
  .auth-btn {
    width: 100%; padding: 14px;
    background: linear-gradient(135deg, var(--v1), var(--v2) 55%, #6d28d9);
    border: 1px solid rgba(196,181,253,0.45); border-radius: var(--r-md); cursor: pointer;
    color: #fff; font-size: 13.5px; font-weight: 700;
    font-family: var(--sans, 'Inter', sans-serif);
    display: flex; align-items: center; justify-content: center; gap: 8px;
    box-shadow: 0 6px 24px rgba(124,58,237,0.32);
    transition: filter .2s, transform .1s; position: relative;
  }
  .auth-btn:hover:not(:disabled)  { filter: brightness(1.06); transform: translateY(-1px); }
  .auth-btn:active:not(:disabled) { transform: translateY(0); }
  .auth-btn:disabled { opacity: .45; cursor: not-allowed; }

  .auth-btn-spinner {
    width: 16px; height: 16px;
    border: 2.5px solid rgba(255,255,255,0.35); border-top-color: #fff;
    border-radius: 50%; animation: authSpin .7s linear infinite; display: none;
  }
  .auth-btn.loading .auth-btn-spinner { display: block; }
  .auth-btn.loading .auth-btn-text   { display: none; }
  @keyframes authSpin { to { transform: rotate(360deg); } }

  /* ── Divider, matches .section-header ── */
  .auth-divider {
    display: flex; align-items: center; gap: 10px;
    margin: 20px 0 16px; color: var(--txt3); font-size: 10px; font-weight: 700;
    letter-spacing: .5px; text-transform: uppercase;
  }
  .auth-divider::before, .auth-divider::after {
    content: ''; flex: 1; height: 1px; background: var(--border-soft);
  }
  .auth-footer      { text-align: center; font-size: 12.5px; color: var(--txt3); }
  .auth-footer-link { color: var(--v3); font-weight: 700; cursor: pointer; text-decoration: none; transition: color .2s; }
  .auth-footer-link:hover { color: var(--v-soft); }

  .auth-input-wrap.field-error  { border-color: rgba(248,113,113,0.5) !important; background: rgba(248,113,113,0.05) !important; }
  .auth-field-error-msg         { font-size: 11px; color: var(--red); margin-top: 6px; display: none; }
  .auth-field-error-msg.show    { display: block; }

  .auth-code-status              { font-size: 11px; margin-top: 6px; display: none; }
  .auth-code-status.show         { display: flex; align-items: center; gap: 6px; }
  .auth-code-status.ok           { color: var(--green); }
  .auth-code-status.fail         { color: var(--red); }
  .auth-code-status.checking     { color: var(--txt3); }
  .auth-code-pulse {
    width: 8px; height: 8px; border-radius: 50%;
    border: 1.5px solid currentColor; border-top-color: transparent;
    animation: authSpin .6s linear infinite; flex-shrink: 0;
  }

  @media (max-width: 380px) {
    .auth-panel { padding: 22px 16px; }
  }
  `;

  var styleEl = document.createElement('style');
  styleEl.textContent = AUTH_CSS;
  document.head.appendChild(styleEl);

  function brandHTML() {
    return `
      <div class="auth-brand">
        <div class="auth-logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="28" height="28">
            <defs>
              <linearGradient id="authLg1" x1="4" y1="4" x2="44" y2="20"><stop offset="0" stop-color="#d8ccff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient>
              <linearGradient id="authLg2" x1="4" y1="16" x2="24" y2="44"><stop offset="0" stop-color="#a855f7"/><stop offset="1" stop-color="#5b21b6"/></linearGradient>
              <linearGradient id="authLg3" x1="44" y1="16" x2="24" y2="44"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#4c1d95"/></linearGradient>
            </defs>
            <path d="M24 4 L44 16 L34 22 L24 16 L14 22 L4 16 Z" fill="url(#authLg1)"/>
            <path d="M4 16 L14 22 L14 34 L24 44 L24 26 Z" fill="url(#authLg2)"/>
            <path d="M44 16 L34 22 L34 34 L24 44 L24 26 Z" fill="url(#authLg3)"/>
          </svg>
        </div>
        <div class="auth-brand-text">
          <h1>YUSH <span>UPDATOR</span></h1>
          <p>Offset Synchronization Engine</p>
        </div>
      </div>
    `;
  }
  
  function buildLoginHTML() {
    return `
      <div class="auth-card">
        ${brandHTML()}
        <div id="authAlertBox" class="auth-alert" style="display:none;"></div>
        <div class="auth-panel">
          <div class="auth-title">Welcome back</div>
          <div class="auth-subtitle">Sign in to continue to your workspace.</div>

          <div class="auth-field">
            <div class="auth-field-header"><label class="auth-label">Email</label></div>
            <div class="auth-input-wrap" id="wrapLoginEmail">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 7L2 7"/></svg>
              <input type="email" id="loginEmail" placeholder="Enter your email" autocomplete="email" spellcheck="false">
            </div>
            <div class="auth-field-error-msg" id="errLoginEmail"></div>
          </div>

          <div class="auth-field">
            <div class="auth-field-header">
              <label class="auth-label">Password</label>
              <span class="auth-label-note">Keep it private</span>
            </div>
            <div class="auth-input-wrap" id="wrapLoginPass">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <input type="password" id="loginPassword" placeholder="Enter your password" autocomplete="current-password">
              <button type="button" class="auth-eye-btn" onclick="togglePwd('loginPassword',this)">
                <svg id="eyeIcon_loginPassword" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
            <div class="auth-field-error-msg" id="errLoginPass"></div>
          </div>

          <div class="auth-stay-row">
            <div class="auth-stay-left">
              <input type="checkbox" class="auth-stay-cb" id="staySignedIn" checked>
              <label class="auth-stay-label" for="staySignedIn">Stay signed in</label>
            </div>
            <div class="auth-enc-badge">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              Encrypted
            </div>
          </div>

          <button type="button" class="auth-btn" id="loginBtn" onclick="doLogin()">
            <div class="auth-btn-spinner"></div>
            <span class="auth-btn-text">Enter workspace&nbsp;
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" style="display:inline-block;vertical-align:middle"><polyline points="15 3 21 3 21 9"/><path d="M10 14L21 3"/><path d="M21 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h6"/></svg>
            </span>
          </button>

          <div class="auth-divider">New here?</div>
          <div class="auth-footer">
            Don't have an account?
            <a class="auth-footer-link" onclick="showRegister()">Create one</a>
          </div>
        </div>
      </div>
    `;
  }

  function buildRegisterHTML() {
    return `
      <div class="auth-card">
        ${brandHTML()}
        <div id="authAlertBox" class="auth-alert" style="display:none;"></div>
        <div class="auth-panel">
          <div class="auth-title">Create account</div>
          <div class="auth-subtitle">Register with your email.</div>

          <div class="auth-field">
            <div class="auth-field-header"><label class="auth-label">Email</label></div>
            <div class="auth-input-wrap" id="wrapRegEmail">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 7L2 7"/></svg>
              <input type="email" id="regEmail" placeholder="Enter your email" autocomplete="email" spellcheck="false">
            </div>
            <div class="auth-field-error-msg" id="errRegEmail"></div>
          </div>

          <div class="auth-field">
            <div class="auth-field-header"><label class="auth-label">Password</label></div>
            <div class="auth-input-wrap" id="wrapRegPass">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <input type="password" id="regPassword" placeholder="Create a password" autocomplete="new-password">
              <button type="button" class="auth-eye-btn" onclick="togglePwd('regPassword',this)">
                <svg id="eyeIcon_regPassword" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
            <div class="auth-field-error-msg" id="errRegPass"></div>
          </div>

          <div class="auth-field">
            <div class="auth-field-header"><label class="auth-label">Confirm Password</label></div>
            <div class="auth-input-wrap" id="wrapRegConfirm">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              <input type="password" id="regConfirm" placeholder="Confirm password" autocomplete="new-password">
              <button type="button" class="auth-eye-btn" onclick="togglePwd('regConfirm',this)">
                <svg id="eyeIcon_regConfirm" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
            <div class="auth-field-error-msg" id="errRegConfirm"></div>
          </div>

          <div class="auth-field">
            <div class="auth-field-header"><label class="auth-label">Verification Code</label></div>
            <div class="auth-input-wrap" id="wrapRegCode">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="15" r="4"/><path d="M10.5 12.5L21 2M21 2v5M21 2h-5"/></svg>
              <input type="text" id="regCode" placeholder="Paste 6-digit code" autocomplete="one-time-code" spellcheck="false" inputmode="numeric" maxlength="6" oninput="handleRegCodeInput(this)" onpaste="var el=this; setTimeout(function(){ handleRegCodeInput(el); }, 0);">
              <div class="auth-code-divider"></div>
              <button type="button" class="auth-sendcode-btn" id="sendCodeBtn" onclick="doSendCode()">Send code</button>
            </div>
            <div class="auth-code-status" id="codeStatus"></div>
            <div class="auth-field-error-msg" id="errRegCode"></div>
          </div>

          <div class="turnstile-step" id="turnstileStep" style="display:none;">
            <div class="turnstile-title">Security verification</div>
            <div id="turnstileBox"></div>
            <div class="turnstile-status" id="turnstileStatus"></div>
          </div>

          <button type="button" class="auth-btn" id="regBtn" onclick="doRegister()">
            <div class="auth-btn-spinner"></div>
            <span class="auth-btn-text">Create account</span>
          </button>

          <div class="auth-divider">Or</div>
          <div class="auth-footer">
            Already have an account?
            <a class="auth-footer-link" onclick="showLogin()">Login here</a>
          </div>
        </div>
      </div>
    `;
  }

  var overlay = document.createElement('div');
  overlay.id = 'authOverlay';
  document.body.appendChild(overlay);

  var _pendingCode = null;       // { email, code, expiresAt }
  var _codeCooldownTimer = null;

  window.showLogin = function() {
    destroyTurnstile();
    overlay.innerHTML = buildLoginHTML();
    overlay.classList.remove('hidden');
  };
  window.showRegister = function() {
    destroyTurnstile();
    overlay.innerHTML = buildRegisterHTML();
    overlay.classList.remove('hidden');
  };
  function hideAuth() { overlay.classList.add('hidden'); }

  function showAlert(msg, type) {
    var el = document.getElementById('authAlertBox');
    if (!el) return;
    el.className = 'auth-alert ' + (type === 'error' ? 'error-alert' : type === 'success' ? 'success-alert' : '');
    el.textContent = msg;
    el.style.display = 'flex';
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function setFieldError(wrapId, errId, msg) {
    var w = document.getElementById(wrapId), e = document.getElementById(errId);
    if (w) w.classList.add('field-error');
    if (e) { e.textContent = msg; e.classList.add('show'); }
  }
  function clearFieldError(wrapId, errId) {
    var w = document.getElementById(wrapId), e = document.getElementById(errId);
    if (w) w.classList.remove('field-error');
    if (e) { e.textContent = ''; e.classList.remove('show'); }
  }

  window.togglePwd = function(inputId, btn) {
    var inp = document.getElementById(inputId);
    if (!inp) return;
    var show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    var icon = document.getElementById('eyeIcon_' + inputId);
    if (icon) icon.innerHTML = show
      ? '<path d="M17.94 17.94A10.07 10.07 0 0112 20C5 20 1 12 1 12s1.86-3.5 5.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>'
      : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  };

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  window.handleRegCodeInput = function(input) {
    if (!input) return;
    var cleaned = (input.value || '').replace(/\D/g, '').slice(0, 6);
    if (input.value !== cleaned) input.value = cleaned;

    var emailEl = document.getElementById('regEmail');
    var email = emailEl ? (emailEl.value || '').trim().toLowerCase() : '';
    var statusEl = document.getElementById('codeStatus');

    // Any edit invalidates a previous Turnstile token until the 6-digit
    // email code is valid again.
    if (cleaned.length < 6) {
      hideTurnstileStep();
      if (statusEl && _pendingCode) {
        statusEl.className = 'auth-code-status ok show';
        statusEl.innerHTML = '<span>Paste the 6-digit code from your inbox.</span>';
      }
      return;
    }

    var codeIsValid = !!(
      _pendingCode &&
      _pendingCode.email === email &&
      _pendingCode.code === cleaned &&
      Date.now() <= _pendingCode.expiresAt
    );

    if (codeIsValid) {
      clearFieldError('wrapRegCode', 'errRegCode');
      if (statusEl) {
        statusEl.className = 'auth-code-status ok show';
        statusEl.innerHTML = '<span>Code verified — complete the security check below.</span>';
      }
      showTurnstileStep();
    } else {
      hideTurnstileStep();
      if (statusEl) {
        statusEl.className = 'auth-code-status fail show';
        statusEl.innerHTML = '<span>That code is invalid or expired.</span>';
      }
    }
  };

  window.doSendCode = function() {
    var email = (document.getElementById('regEmail').value || '').trim().toLowerCase();
    clearFieldError('wrapRegEmail', 'errRegEmail');
    if (!email || !EMAIL_RE.test(email)) {
      setFieldError('wrapRegEmail', 'errRegEmail', 'Enter a valid email first.');
      return;
    }

    destroyTurnstile();
    var step = document.getElementById('turnstileStep');
    if (step) step.style.display = 'none';

    var btn = document.getElementById('sendCodeBtn');
    var statusEl = document.getElementById('codeStatus');
    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
    if (statusEl) {
      statusEl.className = 'auth-code-status checking show';
      statusEl.innerHTML = '<div class="auth-code-pulse"></div><span>Sending code…</span>';
    }

    var code = String(Math.floor(100000 + Math.random() * 900000));

    sendVerificationEmail(email, code, function() {
      _pendingCode = { email: email, code: code, expiresAt: Date.now() + CODE_TTL_MS };
      if (statusEl) {
        statusEl.className = 'auth-code-status ok show';
        statusEl.innerHTML = '<span>Code sent — check your inbox.</span>';
      }
      startCodeCooldown();
    }, function(err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Send code'; }
      if (statusEl) {
        statusEl.className = 'auth-code-status fail show';
        statusEl.innerHTML = '<span>Couldn\'t send the email. Try again.</span>';
      }
      console.error('EmailJS send failed:', err);
    });
  };

  function startCodeCooldown() {
    var btn = document.getElementById('sendCodeBtn');
    if (!btn) return;
    var secs = CODE_COOLDOWN;
    btn.disabled = true;
    btn.textContent = 'Resend (' + secs + 's)';
    clearInterval(_codeCooldownTimer);
    _codeCooldownTimer = setInterval(function() {
      secs--;
      if (secs <= 0) {
        clearInterval(_codeCooldownTimer);
        btn.disabled = false;
        btn.textContent = 'Send code';
      } else {
        btn.textContent = 'Resend (' + secs + 's)';
      }
    }, 1000);
  }
  
  function setBtnLoading(id, on) {
    var b = document.getElementById(id);
    if (!b) return;
    b.disabled = on;
    b.classList.toggle('loading', on);
  }

  function simpleHash(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) { h = ((h << 5) - h) + str.charCodeAt(i); h = h & h; }
    return 'h' + Math.abs(h).toString(36);
  }

  window.doLogin = function() {
    var email    = (document.getElementById('loginEmail').value || '').trim().toLowerCase();
    var password = document.getElementById('loginPassword').value || '';
    var stay     = document.getElementById('staySignedIn').checked;

    clearFieldError('wrapLoginEmail', 'errLoginEmail');
    clearFieldError('wrapLoginPass', 'errLoginPass');
    var valid = true;
    if (!email)    { setFieldError('wrapLoginEmail', 'errLoginEmail', 'Email is required.'); valid = false; }
    if (!password) { setFieldError('wrapLoginPass', 'errLoginPass', 'Password is required.');  valid = false; }
    if (!valid) return;

    setBtnLoading('loginBtn', true);
    var db   = dbLoad();
    var user = db[email];

    if (!user) {
      setBtnLoading('loginBtn', false);
      showAlert('No account found with that email.', 'error');
      setFieldError('wrapLoginEmail', 'errLoginEmail', 'Email not registered.');
      return;
    }
    if (user.passwordHash !== simpleHash(password)) {
      setBtnLoading('loginBtn', false);
      showAlert('Incorrect password. Please try again.', 'error');
      setFieldError('wrapLoginPass', 'errLoginPass', 'Incorrect password.');
      return;
    }

    user.loginCount  = (user.loginCount || 0) + 1;
    user.lastLoginAt = Date.now();
    db[email] = user;
    dbSave(db);

    sessionSave({ username: email, staySignedIn: stay, expiresAt: stay ? (Date.now() + STAY_DAYS * 86400000) : null, loggedInAt: Date.now() });

    setBtnLoading('loginBtn', false);
    showAlert('Login successful! Loading workspace…', 'success');
    setTimeout(function() { hideAuth(); }, 900);
  };

  window.doRegister = function() {
    var regBtnEl = document.getElementById('regBtn');
    if (regBtnEl && regBtnEl.disabled) return; // ignore double-tap while a request is in-flight

    var email    = (document.getElementById('regEmail').value || '').trim().toLowerCase();
    var password = document.getElementById('regPassword').value || '';
    var confirm  = document.getElementById('regConfirm').value || '';
    var code     = (document.getElementById('regCode').value || '').trim();

    clearFieldError('wrapRegEmail',   'errRegEmail');
    clearFieldError('wrapRegPass',    'errRegPass');
    clearFieldError('wrapRegConfirm', 'errRegConfirm');
    clearFieldError('wrapRegCode',    'errRegCode');
    var valid = true;

    if (!email || !EMAIL_RE.test(email)) { setFieldError('wrapRegEmail', 'errRegEmail', 'Enter a valid email.'); valid = false; }
    if (!password) { setFieldError('wrapRegPass', 'errRegPass', 'Password is required.'); valid = false; }
    else if (password.length < 6) { setFieldError('wrapRegPass', 'errRegPass', 'Password must be at least 6 characters.'); valid = false; }
    if (password && confirm !== password) { setFieldError('wrapRegConfirm', 'errRegConfirm', 'Passwords do not match.'); valid = false; }

    if (!code) {
      setFieldError('wrapRegCode', 'errRegCode', 'Enter the verification code.'); valid = false;
    } else if (!_pendingCode || _pendingCode.email !== email || _pendingCode.code !== code) {
      setFieldError('wrapRegCode', 'errRegCode', 'Invalid verification code.'); valid = false;
    } else if (Date.now() > _pendingCode.expiresAt) {
      setFieldError('wrapRegCode', 'errRegCode', 'Code expired. Please resend.'); valid = false;
    }
    if (!valid) return;

    // The email code is correct. Read the token directly from Turnstile too;
    // this prevents a valid checked widget from looking "unchecked" if its
    // callback fired before the page state updated.
    var turnstileToken = getTurnstileToken();
    if (!turnstileToken) {
      showTurnstileStep();
      showAlert('Please complete the security verification first.', 'error');
      return;
    }

    setBtnLoading('regBtn', true);

    // Verify the Turnstile token server-side. The secret key never reaches
    // this browser.
    verifyTurnstileOnServer(turnstileToken).then(function(ok) {
      if (!ok) {
        setBtnLoading('regBtn', false);
        // A failed server check means the old token is dead (used/expired).
        // Fully destroy + re-render (not just reset) so the checkbox
        // reliably reappears instead of leaving an empty box.
        destroyTurnstile();
        showTurnstileStep();
        showAlert('Security verification failed or expired. Please verify again.', 'error');
        return;
      }

      var db = dbLoad();
      if (db[email]) {
        setBtnLoading('regBtn', false);
        showAlert('Email already registered. Please login.', 'error');
        setFieldError('wrapRegEmail', 'errRegEmail', 'This email is already registered.');
        return;
      }

      db[email] = {
        email: email,
        passwordHash: simpleHash(password),
        registeredAt: Date.now(),
        lastLoginAt:  null,
        loginCount:   0
      };
      dbSave(db);
      _pendingCode = null;
      _turnstileToken = '';

      setBtnLoading('regBtn', false);
      showAlert('Account created! Redirecting to login…', 'success');
      setTimeout(function() { showLogin(); }, 1200);
    }).catch(function(err) {
      setBtnLoading('regBtn', false);
      resetTurnstile();
      showAlert('Could not verify the security check. Please try again.', 'error');
      console.error('Turnstile verification failed:', err);
    });
    return;
  };

  function init() {
    if (checkSession()) return;
    showLogin();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
