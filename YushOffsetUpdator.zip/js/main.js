var S = { old: null, 'new': null, tgt: null };
var R = { all: [], updated: [], failed: [], ignored: [], same: [] };
var _updatedText = '';
var _worker = null;
var _lastRunAt = 0;
var RUN_COOLDOWN_MS = 1200;

var EXT_LABEL = {
  cs: 'C# Source', cpp: 'C++ Source', cxx: 'C++ Source', cc: 'C++ Source',
  h: 'C++ Header', hpp: 'C++ Header', lua: 'Lua Script',
  txt: 'Text File', json: 'JSON File', java: 'Java Source', js: 'JS Source'
};

function pick(id) { document.getElementById('f-' + id).click(); }

function fmtSz(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(2) + ' MB';
}

function fileType(name) {
  var dot = name.lastIndexOf('.');
  var ext = dot > -1 ? name.slice(dot + 1).toLowerCase() : '';
  return EXT_LABEL[ext] || 'Source File';
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, function(c) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]);
  });
}

/* -------------------------------- status pod / pills -------------------------------- */

function setStatus(state, title, sub) {
  var pod = document.getElementById('statusPod');
  pod.setAttribute('data-state', state);
  document.getElementById('statusTitle').textContent = title;
  document.getElementById('statusSub').textContent = sub;

  var pillMap = { empty: 'ready', ready: 'ready', processing: 'processing', completed: 'completed', error: 'error' };
  var active = pillMap[state] || 'ready';
  document.querySelectorAll('.pill').forEach(function(p) {
    p.classList.toggle('active', p.getAttribute('data-pill') === active);
  });
}

/* -------------------------------- file selection -------------------------------- */

function onFile(id, inp) {
  var f = inp.files[0];
  if (!f) return;

  S[id] = f;

  var fd = document.getElementById('fd-' + id);
  document.getElementById('fd-' + id + '-txt').textContent = f.name;
  fd.classList.add('has-file');

  var fp = document.getElementById('fp-' + id);
  document.getElementById('fpn-' + id).textContent = f.name;
  document.getElementById('fpm-' + id).textContent = fmtSz(f.size) + ' \u2022 ' + fileType(f.name);
  fp.classList.add('show');

  if (id === 'tgt') updateOutputExt();

  checkReady();
}

/* keeps the ".ext" label next to the Output Filename box in sync with the target file */
function updateOutputExt() {
  var el = document.getElementById('outputExt');
  if (!el) return;
  var name = S.tgt ? S.tgt.name : '';
  var dot = name.lastIndexOf('.');
  el.textContent = dot > -1 ? name.slice(dot) : '.txt';
}

function checkReady() {
  var ready = !!(S.old && S['new'] && S.tgt);
  document.getElementById('btnExec').disabled = !ready;
  if (ready) setStatus('ready', 'Engine Ready', 'All files loaded');
  else setStatus('empty', 'Engine Ready', 'Waiting for files');
}

function setProgress(pct) {
  document.getElementById('progressFill').style.width = Math.max(0, Math.min(100, pct)) + '%';
}

/* Read a File as raw bytes (ArrayBuffer). Using bytes instead of decoded
   text lets us hand the data to the Worker as a zero-copy Transferable,
   instead of cloning a giant decoded string across threads. */
function readAB(f) {
  if (f.arrayBuffer) return f.arrayBuffer();
  return new Promise(function(res, rej) {
    var r = new FileReader();
    r.onload = function(e) { res(e.target.result); };
    r.onerror = function() { rej(r.error); };
    r.readAsArrayBuffer(f);
  });
}

/* -------------------------------- stats / results -------------------------------- */

function updateStats() {
  document.getElementById('st').textContent = R.all.length;
  document.getElementById('sok').textContent = R.updated.length;
  document.getElementById('sfail').textContent = R.failed.length;
  document.getElementById('sign').textContent = R.ignored.length;
  document.getElementById('ssame').textContent = R.same.length;
}

/* RVA entries are method offsets, so the output badge reads METHOD.
   FIELD entries stay labeled FIELD. */
function makeCard(r) {
  var tl = r.entryType === 'field' ? 'FIELD' : (r.entryType === 'rva' ? 'METHOD' : 'OFFSET');
  var bt = r.status === 'updated' ? 'Updated' : r.status === 'failed' ? 'Failed' : r.status === 'ignored' ? 'Ignored' : 'Already Latest';
  var showCls = SETTINGS.showClassNames && r.cls;
  var ci = showCls ? ('<span style="color:var(--v3);">' + esc(r.cls) + '</span><span style="color:var(--txt3);">::</span>') : '';
  var copyAttr = SETTINGS.copyEnabled ? ' onclick="copyHex(this)"' : '';
  var copyCls = SETTINGS.copyEnabled ? ' copy-hex' : '';
  var oh = '';
  if (r.status === 'updated') {
    oh = '<div class="r-offsets">' +
      '<div class="r-hex-box left"><div class="r-hex-label">Old</div><div class="r-hex-val old' + copyCls + '" data-hex="' + esc(r.oldVal) + '"' + copyAttr + '>' + esc(r.oldVal) + '</div></div>' +
      '<div class="r-arrow-mid"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--v3)" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></div>' +
      '<div class="r-hex-box right"><div class="r-hex-label">New</div><div class="r-hex-val new' + copyCls + '" data-hex="' + esc(r.newVal) + '"' + copyAttr + '>' + esc(r.newVal) + '</div></div>' +
    '</div>';
  } else {
    var neutralCls = r.status === 'same' ? 'neutral' : 'old';
    oh = '<div class="r-offsets"><div class="r-hex-box single"><div class="r-hex-label">Offset</div><div class="r-hex-val ' + neutralCls + copyCls + '" data-hex="' + esc(r.oldVal) + '"' + copyAttr + '>' + esc(r.oldVal) + '</div></div></div>';
  }
  return '<div class="r-card c-' + r.status + '"><div class="r-card-top"><span class="r-badge b-' + r.status + '">' + bt + '</span><span class="r-type-badge">' + tl + '</span></div><div class="r-name">' + ci + esc(r.name) + '</div>' + oh + '</div>';
}

/* Tap any hex value in the results to copy it to the clipboard. */
function copyHex(el) {
  var val = el.getAttribute('data-hex') || el.textContent;
  var mark = function () {
    el.classList.add('copied');
    setTimeout(function () { el.classList.remove('copied'); }, 900);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(val).then(mark, function () { fallbackCopy(val, mark); });
  } else {
    fallbackCopy(val, mark);
  }
}

function fallbackCopy(text, cb) {
  var ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try { document.execCommand('copy'); } catch (e) { /* ignore */ }
  document.body.removeChild(ta);
  if (cb) cb();
}

function renderResults() {
  ['updated', 'failed', 'ignored', 'same'].forEach(function(k) {
    var sec = document.getElementById('sec-' + k);
    var cont = document.getElementById('cards-' + k);
    var ctr = document.getElementById('sc-' + k);
    if (!R[k].length) { sec.style.display = 'none'; return; }
    ctr.textContent = R[k].length + ' offset' + (R[k].length !== 1 ? 's' : '');
    var html = '';
    R[k].forEach(function(r) { html += makeCard(r); });
    cont.innerHTML = html;
    sec.style.display = 'block';
  });
  document.getElementById('resultsWrap').classList.add('show');
}

/* -------------------------------- pipeline -------------------------------- */

async function runPipeline() {
  if (!S.old || !S['new'] || !S.tgt) return;

  var now = Date.now();
  if (now - _lastRunAt < RUN_COOLDOWN_MS) return; // basic anti-spam / anti-abuse throttle
  if (window.__yushGuardAction && !window.__yushGuardAction()) return; // rate-limit guard
  _lastRunAt = now;

  document.getElementById('btnExec').disabled = true;
  document.getElementById('btnLabel').textContent = 'Processing...';
  document.getElementById('dlWrap').classList.remove('show');
  document.getElementById('resultsWrap').classList.remove('show');
  document.getElementById('progressWrap').classList.add('show');
  setStatus('processing', 'Processing', 'Comparing offsets\u2026');

  R = { all: [], updated: [], failed: [], ignored: [], same: [] };
  _updatedText = '';
  updateStats();
  setProgress(0);

  var oldBuf, newBuf, tgtBuf;
  try {
    oldBuf = await readAB(S.old);
    newBuf = await readAB(S['new']);
    tgtBuf = await readAB(S.tgt);
  } catch (err) {
    document.getElementById('btnExec').disabled = false;
    document.getElementById('btnLabel').textContent = 'Start Update';
    setStatus('error', 'Error', 'Could not read files');
    alert('Failed to read one of the files: ' + (err && err.message ? err.message : err));
    return;
  }

  if (_worker) { _worker.terminate(); _worker = null; }
  _worker = new Worker('js/worker.js');

  _worker.onmessage = function(e) {
    var msg = e.data;
    if (msg.type === 'progress') {
      setProgress(msg.pct);
    } else if (msg.type === 'error') {
      document.getElementById('btnExec').disabled = false;
      document.getElementById('btnLabel').textContent = 'Start Update';
      setStatus('error', 'Error', msg.message || 'Processing failed');
      alert('Processing error: ' + msg.message);
      _worker.terminate();
      _worker = null;
    } else if (msg.type === 'done') {
      R.updated = msg.results.updated;
      R.failed = msg.results.failed;
      R.ignored = msg.results.ignored;
      R.same = msg.results.same;
      R.all = R.updated.concat(R.failed, R.ignored, R.same);
      _updatedText = msg.updatedText;

      setProgress(100);
      updateStats();

      document.getElementById('btnExec').disabled = false;
      document.getElementById('btnLabel').textContent = 'Start Update';
      _worker.terminate();
      _worker = null;

      if (!R.all.length) {
        document.getElementById('resultsWrap').classList.remove('show');
        setStatus('error', 'Error', 'No offset detected');
        alert('No offset detected in the target file.');
        return;
      }

      renderResults();
      if (R.updated.length) {
        document.getElementById('dlWrap').classList.add('show');
        if (SETTINGS.autoDownload) doDownload();
      }
      setStatus('completed', 'Completed', R.updated.length + ' of ' + R.all.length + ' offsets updated');
    }
  };

  _worker.onerror = function(err) {
    document.getElementById('btnExec').disabled = false;
    document.getElementById('btnLabel').textContent = 'Start Update';
    setStatus('error', 'Error', err.message || 'Processing failed');
    alert('Processing error: ' + err.message);
  };

  // Transfer the raw buffers instead of cloning decoded strings — this is
  // a zero-copy handoff and is what keeps large files from crashing the tab.
  _worker.postMessage({ oldBuf: oldBuf, newBuf: newBuf, tgtBuf: tgtBuf }, [oldBuf, newBuf, tgtBuf]);
}

function doDownload() {
  if (!_updatedText || !S.tgt) return;
  var blob = new Blob([_updatedText], { type: 'text/plain' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  var fn = S.tgt.name, dot = fn.lastIndexOf('.');
  var ext = dot > -1 ? fn.slice(dot) : '';
  var base = (SETTINGS.outputFilename || '').trim();
  a.download = base ? (base + ext) : ((dot > -1 ? fn.slice(0, dot) : fn) + '_updated' + ext);
  a.click();
  setTimeout(function() { URL.revokeObjectURL(a.href); }, 10000);
}

/* -------------------------------- settings & panels -------------------------------- */

var SETTINGS_KEY = 'yushUpdatorSettings';
var DEFAULT_SETTINGS = {
  theme: 'purple',
  copyEnabled: false,
  showClassNames: false,
  guardEnabled: true,
  autoDownload: false,
  outputFilename: 'updated_file'
};
var SETTINGS = Object.assign({}, DEFAULT_SETTINGS);

var LEGAL_CONTENT = {
  terms: {
    title: 'Terms of Service',
    html:
      '<h4>Using YUSH UPDATOR</h4>' +
      '<p>YUSH UPDATOR is an offset synchronization tool provided as-is by @PrimeYush / Nocturne Team. By using it you agree to use it responsibly and at your own risk.</p>' +
      '<h4>No Warranty</h4>' +
      '<p>The tool is provided without warranties of any kind. The developer is not liable for any damage, data loss, or misuse resulting from the use of this tool.</p>' +
      '<h4>Acceptable Use</h4>' +
      '<p>You are responsible for the files you process and how the output is used. Do not use this tool for activity that violates applicable laws or third-party terms.</p>'
  },
  privacy: {
    title: 'Privacy Policy',
    html:
      '<h4>Local Processing</h4>' +
      '<p>All files you load (Old Dump, New Dump, Target File) are processed entirely on your device. Nothing is uploaded to any server.</p>' +
      '<h4>Saved Preferences</h4>' +
      '<p>Only your theme and app settings are stored locally on this device (via browser storage) so they persist between sessions. No file contents or personal data are collected.</p>' +
      '<h4>Third-Party Links</h4>' +
      '<p>Links to Telegram, TikTok and YouTube in the About panel lead to external platforms with their own privacy policies.</p>'
  }
};

function openLegal(kind) {
  var c = LEGAL_CONTENT[kind];
  if (!c) return;
  document.getElementById('legalTitle').textContent = c.title;
  document.getElementById('legalText').innerHTML = c.html;
  openPanel('legal');
}

function loadSettings() {
  try {
    var raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) SETTINGS = Object.assign({}, DEFAULT_SETTINGS, JSON.parse(raw));
  } catch (e) { /* ignore, fall back to defaults */ }
}

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) { /* ignore */ }
}

function openPanel(name) {
  var el = document.getElementById(name + 'Panel');
  if (el) el.classList.add('show');
}

function closePanel(name) {
  var el = document.getElementById(name + 'Panel');
  if (el) el.classList.remove('show');
}

function setTheme(name) {
  SETTINGS.theme = name;
  if (name === 'purple') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', name);
  syncThemeSwitches();
  saveSettings();
}

function syncThemeSwitches() {
  document.querySelectorAll('[data-theme-btn]').forEach(function (btn) {
    btn.classList.toggle('selected', btn.getAttribute('data-theme-btn') === SETTINGS.theme);
  });
}

function setCopyEnabled(v) { SETTINGS.copyEnabled = !!v; saveSettings(); renderResults(); }
function setShowClassNames(v) { SETTINGS.showClassNames = !!v; saveSettings(); renderResults(); }
function setGuardEnabled(v) {
  SETTINGS.guardEnabled = !!v;
  saveSettings();
  window.__yushGuardAction = SETTINGS.guardEnabled
    ? window.__yushGuardActionOriginal
    : function () { return true; };
}
function setAutoDownload(v) { SETTINGS.autoDownload = !!v; saveSettings(); }
function setOutputFilename(v) {
  SETTINGS.outputFilename = (v || '').replace(/[\\/:*?"<>|]/g, '').trim();
  saveSettings();
}

function syncToggleInputs() {
  var c = document.getElementById('toggleCopy');
  var cn = document.getElementById('toggleClassNames');
  var g = document.getElementById('toggleGuard');
  var ad = document.getElementById('toggleAutoDownload');
  var of = document.getElementById('outputFilename');
  if (c) c.checked = SETTINGS.copyEnabled;
  if (cn) cn.checked = SETTINGS.showClassNames;
  if (g) g.checked = SETTINGS.guardEnabled;
  if (ad) ad.checked = SETTINGS.autoDownload;
  if (of) of.value = SETTINGS.outputFilename || '';
  updateOutputExt();
}

function resetSettings() {
  SETTINGS = Object.assign({}, DEFAULT_SETTINGS);
  saveSettings();
  setTheme(SETTINGS.theme);
  syncToggleInputs();
  if (window.__yushGuardActionOriginal) window.__yushGuardAction = window.__yushGuardActionOriginal;
  renderResults();
}

function initSettings() {
  loadSettings();
  if (window.__yushGuardAction) window.__yushGuardActionOriginal = window.__yushGuardAction;
  if (SETTINGS.theme !== 'purple') document.documentElement.setAttribute('data-theme', SETTINGS.theme);
  syncThemeSwitches();
  syncToggleInputs();
  if (!SETTINGS.guardEnabled && window.__yushGuardActionOriginal) {
    window.__yushGuardAction = function () { return true; };
  }
}

checkReady();
initSettings();