/*
 * protection.js — lightweight client-side hardening for YUSH UPDATOR.
 *
 * IMPORTANT HONESTY NOTE (leave this comment in):
 * This tool runs 100% in the browser with no server backend, so there is
 * no request endpoint for a real DDoS attack to target, and there is no
 * way to make front-end HTML/JS truly un-viewable/un-copyable — anyone can
 * read page source, use browser devtools, or save the page. What this file
 * DOES do is:
 *   1. Throttle/limit local resource abuse (rapid re-triggering, huge
 *      pasted/dropped input) so the page itself can't be hung or crashed.
 *   2. Add mild deterrents against casual copy/scraping (right-click,
 *      selection, common "view/save" shortcuts) — a determined user can
 *      still bypass all of this, it just raises the bar for casual reuse.
 *   3. Detect obvious automated/headless clients and slow them down.
 */
(function () {
  'use strict';

  /* ---- 1. Casual anti-scrape / anti-copy deterrents ---- */

  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
  });

  document.addEventListener('keydown', function (e) {
    var k = (e.key || '').toLowerCase();
    var blockCombo =
      (e.ctrlKey || e.metaKey) && (k === 'u' || k === 's') || // view-source / save-page
      k === 'f12' ||
      ((e.ctrlKey || e.metaKey) && e.shiftKey && (k === 'i' || k === 'c' || k === 'j'));
    if (blockCombo) e.preventDefault();
  });

  // Allow text selection inside inputs/results normally, but discourage
  // bulk-selecting/dragging the whole app chrome for scraping.
  document.addEventListener('dragstart', function (e) { e.preventDefault(); });

  /* ---- 2. Basic bot / headless-client heuristic ---- */

  function looksAutomated() {
    try {
      if (navigator.webdriver) return true;
      if (/HeadlessChrome/i.test(navigator.userAgent)) return true;
    } catch (err) { /* ignore */ }
    return false;
  }

  if (looksAutomated()) {
    // Don't hard-block (some legit users run accessibility/automation tools),
    // just visibly flag it so the operator knows the session is scripted.
    var tag = document.createElement('div');
    tag.textContent = 'Automated client detected';
    tag.style.cssText = 'position:fixed;bottom:8px;left:8px;z-index:99999;' +
      'background:rgba(248,113,113,0.15);color:#f87171;font:600 10px monospace;' +
      'padding:6px 10px;border-radius:8px;border:1px solid rgba(248,113,113,0.4);';
    document.addEventListener('DOMContentLoaded', function () {
      document.body.appendChild(tag);
    });
  }

  /* ---- 3. Local resource-abuse throttle ---- */
  /* Prevents rapid repeated triggering of expensive actions (e.g. someone
     scripting clicks on "Start Update" in a loop to hammer the Worker). */

  var _actionTimestamps = [];
  var WINDOW_MS = 5000;
  var MAX_ACTIONS_PER_WINDOW = 6;

  window.__yushGuardAction = function () {
    var now = Date.now();
    _actionTimestamps = _actionTimestamps.filter(function (t) { return now - t < WINDOW_MS; });
    _actionTimestamps.push(now);
    if (_actionTimestamps.length > MAX_ACTIONS_PER_WINDOW) {
      return false; // caller should abort/ignore this trigger
    }
    return true;
  };
})();
